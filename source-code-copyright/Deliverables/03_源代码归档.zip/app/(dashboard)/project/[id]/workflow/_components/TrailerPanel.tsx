import { useState, useEffect, useRef, useCallback } from 'react'
import useSWR from 'swr'
import { LoaderCircle, Play, RefreshCw, Film, Music, X } from 'lucide-react'
import { cn } from '@/lib/utils'
import { ASPECT_RATIO_OPTIONS } from '@/lib/models-config'
import CostBadge from '@/components/CostBadge'
import { GENERATION_COSTS } from '@/lib/points-config'

/** 合成看门狗：超过这个时间仍拿不到 combinedVideoUrl 就认为合成失败 */
const COMPOSE_WATCHDOG_MS = 8 * 60 * 1000

const fetcher = (url: string) => fetch(url).then((r) => r.json())

interface TrailerPanelProps {
  step: any
  projectId: string
  executing: string | null
  onExecute: (stepType: string, body?: any) => void
  onError?: (msg: string | null) => void
  mutate?: () => Promise<any>
  setToast?: (t: { kind: 'success' | 'error'; message: string } | null) => void
  readOnly?: boolean
  defaultAspectRatio?: string
}

function ProcessingBlock({ message }: { message: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16">
      <LoaderCircle className="h-8 w-8 animate-spin text-stone-400" />
      <p className="mt-3 text-sm text-stone-500">{message}</p>
    </div>
  )
}

interface SegmentCardProps {
  segment: any
  index: number
  highlighted: boolean
  onDoubleClick: (index: number) => void
  onGenerate: (segmentId: string, aspectRatio: string) => void
  isExecuting: boolean
  aspectRatio: string
}

function SegmentCard({
  segment,
  index,
  highlighted,
  onDoubleClick,
  onGenerate,
  isExecuting,
  aspectRatio,
}: SegmentCardProps) {
  const [expandedPrompt, setExpandedPrompt] = useState(false)
  const statusConfig: Record<string, { label: string; className: string }> = {
    completed: { label: '已完成', className: 'bg-emerald-50 text-emerald-700' },
    generating: { label: '生成中', className: 'bg-amber-50 text-amber-700' },
    failed: { label: '失败', className: 'bg-red-50 text-red-700' },
    pending: { label: '待生成', className: 'bg-stone-100 text-stone-500' },
  }
  const { label, className: badgeClass } =
    statusConfig[segment.status] || statusConfig.pending

  return (
    <div
      className={cn(
        'group flex items-stretch gap-4 overflow-hidden rounded-lg border bg-white transition hover:shadow-md',
        highlighted ? 'border-emerald-400 ring-2 ring-emerald-100' : 'border-stone-200'
      )}
      onDoubleClick={() => onDoubleClick(index)}
    >
      {/* 左侧媒体区 */}
      <div className="relative shrink-0 w-48 aspect-video overflow-hidden bg-stone-100">
        {segment.status === 'completed' && segment.videoUrl ? (
          <video
            src={segment.videoUrl}
            muted
            playsInline
            className="h-full w-full object-cover transition group-hover:scale-105"
            preload="metadata"
          />
        ) : segment.status === 'generating' ? (
          <div className="flex h-full flex-col items-center justify-center">
            <LoaderCircle className="h-6 w-6 animate-spin text-stone-400" />
            <span className="mt-2 text-xs text-stone-500">生成中...</span>
          </div>
        ) : segment.status === 'failed' ? (
          <div className="flex h-full flex-col items-center justify-center">
            <span className="text-xs text-red-500">生成失败</span>
            {segment.errorMessage && (
              <span className="mt-1 max-w-[80%] text-center text-[10px] text-red-400 line-clamp-2">
                {segment.errorMessage}
              </span>
            )}
          </div>
        ) : segment.imageUrl ? (
          <img
            src={segment.imageUrl}
            alt={segment.caption || '概念图'}
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="flex h-full flex-col items-center justify-center bg-stone-50">
            <span className="font-mono text-sm font-bold text-stone-400">
              {segment.shotId}
            </span>
            <span className="mt-1 text-xs text-stone-400">待生成</span>
          </div>
        )}

        <span className="absolute bottom-1.5 left-1.5 rounded bg-black/60 px-1.5 py-0.5 font-mono text-[10px] text-white">
          {segment.shotId}
        </span>
      </div>

      {/* 中间描述区 */}
      <div className="flex min-w-0 flex-1 flex-col justify-center py-3 pr-2">
        <p className="text-sm font-semibold text-stone-800 line-clamp-1">
          {segment.caption || '无描述'}
        </p>
        {segment.prompt && (
          <div className="mt-1">
            <button
              onClick={() => setExpandedPrompt((v) => !v)}
              className="w-full text-left"
              title={expandedPrompt ? '收起英文提示词' : '展开英文提示词'}
            >
              <p className={`text-xs text-stone-500 ${expandedPrompt ? '' : 'line-clamp-2'}`}>
                {segment.prompt}
              </p>
              <span className="mt-0.5 text-[10px] text-stone-300">
                {expandedPrompt ? '收起' : '展开全文'}
              </span>
            </button>
          </div>
        )}
      </div>

      {/* 右侧详情区 */}
      <div className="flex w-28 shrink-0 flex-col items-end justify-between border-l border-stone-100 py-3 pl-4 pr-4">
        <span
          className={cn(
            'rounded-full px-2 py-0.5 text-[10px] font-medium',
            badgeClass
          )}
        >
          {label}
        </span>
        <div className="flex flex-col items-end gap-1">
          <span className="text-xs text-stone-400">{segment.duration || 5}s</span>
          {segment.status === 'pending' && (
            <button
              onClick={() => onGenerate(segment.id, aspectRatio)}
              disabled={isExecuting}
              className="flex items-center gap-1 rounded bg-stone-800 px-2 py-1 text-[10px] text-white transition hover:bg-stone-700 disabled:opacity-50"
            >
              <Play className="h-3 w-3" />
              生成
            </button>
          )}
          {segment.status === 'failed' && (
            <button
              onClick={() => onGenerate(segment.id, aspectRatio)}
              disabled={isExecuting}
              className="flex items-center gap-1 rounded bg-red-600 px-2 py-1 text-[10px] text-white transition hover:bg-red-700 disabled:opacity-50"
            >
              <RefreshCw className="h-3 w-3" />
              重试
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

export default function TrailerPanel({
  step,
  projectId,
  executing,
  onExecute,
  readOnly,
  defaultAspectRatio,
}: TrailerPanelProps) {
  const videoRef = useRef<HTMLVideoElement>(null)

  // 从 step.outputData 读取合成结果（video-segments API 不再返回 combinedVideoUrl/bgmUrl）
  const stepOutput = (step?.outputData as any) || {}

  const [highlightedSegmentId, setHighlightedSegmentId] = useState<string | null>(null)
  const [isComposing, setIsComposing] = useState(false)
  const [composeStartedAt, setComposeStartedAt] = useState<number | null>(null)
  // 原实现所有失败只写 console.error，用户以为底层没反应就反复点
  const [localError, setLocalError] = useState<string | null>(null)
  const [isGeneratingBgm, setIsGeneratingBgm] = useState(false)
  const [selectedAspectRatio, setSelectedAspectRatio] = useState(
    stepOutput.aspectRatio || defaultAspectRatio || '16:9'
  )

  const { data: segmentData } = useSWR(
    `/api/projects/${projectId}/video-segments?stepName=TRAILER`,
    fetcher,
    { refreshInterval: 10000 }
  )

  const segments = segmentData?.segments || []
  const summary = segmentData?.summary

  const combinedVideoUrl = stepOutput.combinedVideoUrl || stepOutput.videoUrl || null
  const combinedVideoStatus = stepOutput.combinedVideoStatus || null
  const musicUrl = stepOutput.musicUrl || null
  const musicIsMock = stepOutput.musicIsMock ?? true

  const isExecuting = executing === 'TRAILER'

  const totalDuration = segments.reduce((sum: number, s: any) => sum + (s.duration || 5), 0)

  const handleGenerateBgm = useCallback(async () => {
    setIsGeneratingBgm(true)
    try {
      const res = await fetch(`/api/projects/${projectId}/steps/trailer`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'generate-bgm' }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.message || '生成失败')
      // BGM 会写入 step.outputData.musicUrl，mutate 刷新后 UI 自动更新
    } catch (e: any) {
      console.error('[BGM] 生成失败:', e)
      setLocalError('音乐生成失败：' + (e?.message || '未知错误'))
      ;(window as any).__showToast?.({ kind: 'error', message: '音乐生成失败：' + (e?.message || '未知错误') })
    } finally {
      setIsGeneratingBgm(false)
    }
  }, [projectId])

  useEffect(() => {
    const video = videoRef.current
    if (!video || segments.length === 0) return

    const handler = () => {
      const currentTime = video.currentTime
      let accumulated = 0
      for (const segment of segments) {
        const dur = segment.duration || 5
        if (currentTime >= accumulated && currentTime < accumulated + dur) {
          setHighlightedSegmentId(segment.id)
          break
        }
        accumulated += dur
      }
    }

    video.addEventListener('timeupdate', handler)
    return () => video.removeEventListener('timeupdate', handler)
  }, [segments])

  const handleDoubleClick = useCallback(
    (segmentIndex: number) => {
      const video = videoRef.current
      if (!video || !combinedVideoUrl) return
      const startTime = segments
        .slice(0, segmentIndex)
        .reduce((sum: number, s: any) => sum + (s.duration || 5), 0)
      video.currentTime = startTime
      video.play()
    },
    [segments, combinedVideoUrl]
  )

  const handleGenerateSegment = (segmentId: string, aspectRatio: string) => {
    onExecute('TRAILER', { action: 'generate-segment-video', segmentId, aspectRatio })
  }

  const handleGeneratePrompts = () => {
    onExecute('TRAILER', { action: 'generate-segment-prompts' })
  }

  const handleGenerateAll = () => {
    onExecute('TRAILER', { action: 'generate-all-segments', aspectRatio: selectedAspectRatio })
  }

  const handleCompose = () => {
    setIsComposing(true)
    setComposeStartedAt(Date.now())
    setLocalError(null)
    onExecute('TRAILER', { action: 'compose-video', aspectRatio: selectedAspectRatio })
  }

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60)
    const s = Math.floor(seconds % 60)
    return `${m}:${String(s).padStart(2, '0')}`
  }

  const hasSegments = segments.length > 0
  const allCompleted = summary?.allCompleted || false
  // isComposing 不会自身复位，合成失败时面板会永久卡在「拼接中」
  const composeStuck = isComposing && !combinedVideoUrl && composeStartedAt !== null
    && Date.now() - composeStartedAt > COMPOSE_WATCHDOG_MS
  const isProcessing = combinedVideoStatus === 'processing' || (isComposing && !composeStuck)

  useEffect(() => {
    if (combinedVideoUrl) {
      setIsComposing(false)
      setComposeStartedAt(null)
    }
  }, [combinedVideoUrl])

  useEffect(() => {
    if (!composeStuck) return
    console.warn('[TRAILER] 合成超时，解除本地锁定并提示重试')
    setIsComposing(false)
    setComposeStartedAt(null)
    setLocalError('视频合成超时或失败，请重新点击「合成视频」重试')
    ;(window as any).__showToast?.({ kind: 'error', message: '视频合成超时或失败，请重试' })
  }, [composeStuck])

  if (combinedVideoUrl) {
    return (
      <div className="flex flex-col h-[calc(100vh-8rem)]">
        {/* 上半部分：常驻播放区 */}
        <div className="shrink-0 bg-white pb-4 pt-2">
          <video
            ref={videoRef}
            src={combinedVideoUrl}
            controls
            className="w-full rounded-lg max-h-[min(35vh,20rem)]"
          />
          <div className="mt-2 flex items-center justify-between text-sm text-stone-500">
            <span>总时长: {formatTime(totalDuration)}</span>
            <span>
              {segments.length} 个片段 · 比例: {stepOutput.aspectRatio || defaultAspectRatio || '16:9'}
            </span>
          </div>
          {musicUrl && (
            <div className="mt-2 rounded-lg border border-stone-200 bg-stone-50 p-2">
              <span className="text-xs text-stone-500">
                背景音乐 {musicIsMock ? '(静音)' : ''}
              </span>
              <audio src={musicUrl} controls className="mt-1 w-full" />
            </div>
          )}
        </div>

        {/* 下半部分：独立滚动分镜区 */}
        <div className="flex-1 overflow-y-auto min-h-0 pt-2">
          <h3 className="mb-3 text-sm font-semibold text-stone-700">
            片段 ({segments.length})
          </h3>
          <div className="flex flex-col gap-3">
            {segments.map((segment: any, index: number) => (
              <SegmentCard
                key={segment.id}
                segment={segment}
                index={index}
                highlighted={highlightedSegmentId === segment.id}
                onDoubleClick={handleDoubleClick}
                onGenerate={handleGenerateSegment}
                isExecuting={isExecuting}
                aspectRatio={selectedAspectRatio}
              />
            ))}
          </div>
        </div>
      </div>
    )
  }

  const errorBanner = localError ? (
    <div className="flex items-start justify-between gap-3 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
      <span className="min-w-0 break-words">{localError}</span>
      <button
        onClick={() => setLocalError(null)}
        className="shrink-0 rounded px-1 text-red-500 hover:text-red-700"
        aria-label="关闭提示"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  ) : null

  if (isProcessing) {
    return (
      <div className="space-y-4">
        <ProcessingBlock message="视频拼接中，请稍候..." />
        <p className="text-center text-xs text-stone-500">
          合成在后台进行，可以离开本页面；完成后回来刷新即可看到结果。
        </p>
      </div>
    )
  }

  if (hasSegments) {
    return (
      <div className="flex flex-col h-[calc(100vh-8rem)]">
        {errorBanner}
        {/* 上半部分：操作区 */}
        <div className="shrink-0 flex items-center justify-between pb-4">
          <div>
            <h3 className="text-sm font-semibold text-stone-700">
              分镜片段 ({segments.length})
            </h3>
            <p className="text-xs text-stone-500">
              {summary?.completed || 0} 已完成 · {summary?.pending || 0} 待生成 ·{' '}
              {summary?.generating || 0} 生成中 · {summary?.failed || 0} 失败
            </p>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-medium text-stone-600 whitespace-nowrap">画面比例</span>
              <select
                value={selectedAspectRatio}
                onChange={(e) => setSelectedAspectRatio(e.target.value)}
                disabled={isExecuting}
                className="rounded-md border border-stone-300 bg-white px-2 py-1 text-xs text-stone-700 focus:border-amber-500 focus:outline-none focus:ring-1 focus:ring-amber-500 disabled:opacity-50"
              >
                {ASPECT_RATIO_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}（{opt.width}×{opt.height}）
                  </option>
                ))}
              </select>
            </div>
            {musicUrl ? (
              <button
                disabled
                className="flex items-center gap-1 rounded-md bg-emerald-50 px-3 py-1.5 text-xs font-medium text-emerald-700"
              >
                <Music className="h-3 w-3" />
                {musicIsMock ? '静音' : '已生成 BGM'}
              </button>
            ) : (
              <div className="relative inline-block">
                <button
                  onClick={handleGenerateBgm}
                  disabled={isExecuting || isGeneratingBgm || segments.length === 0}
                  className="flex items-center gap-1 rounded-md bg-stone-700 px-3 py-1.5 text-xs font-medium text-white transition hover:bg-stone-600 disabled:opacity-50"
                  title="先生成至少一个视频片段"
                >
                  {isGeneratingBgm ? (
                    <LoaderCircle className="h-3 w-3 animate-spin" />
                  ) : (
                    <Music className="h-3 w-3" />
                  )}
                  生成 BGM
                </button>
                <CostBadge cost={GENERATION_COSTS.BGM} />
              </div>
            )}
            {allCompleted && (
              <button
                onClick={handleCompose}
                disabled={isExecuting}
                className="flex items-center gap-1 rounded-md bg-stone-900 px-3 py-1.5 text-xs font-medium text-white transition hover:bg-stone-800 disabled:opacity-50"
              >
                {isExecuting ? (
                  <LoaderCircle className="h-3 w-3 animate-spin" />
                ) : (
                  <Film className="h-3 w-3" />
                )}
                合成视频
              </button>
            )}
          </div>
        </div>

        {/* 下半部分：独立滚动分镜区 */}
        <div className="flex-1 overflow-y-auto min-h-0">
          <div className="flex flex-col gap-3">
            {segments.map((segment: any, index: number) => (
              <SegmentCard
                key={segment.id}
                segment={segment}
                index={index}
                highlighted={false}
                onDoubleClick={() => {}}
                onGenerate={handleGenerateSegment}
                isExecuting={isExecuting}
                aspectRatio={selectedAspectRatio}
              />
            ))}
          </div>
        </div>
      </div>
    )
  }

  if (step.status === 'PENDING' || step.status === 'COMPLETED') {
    const out = (step.outputData as any) || {}
    const hasLegacyVideo = out.videoUrl || step.resultAssets?.some((a: any) => a.type === 'VIDEO')

    if (hasLegacyVideo && !readOnly) {
      return (
        <div className="space-y-4">
          <div className="rounded-lg border border-amber-200 bg-amber-50 p-3">
            <p className="text-sm text-amber-800">
              检测到旧版宣传片。新版支持概念图卡片式逐段生成，是否重新生成？
            </p>
          </div>
          <div className="flex justify-center gap-3">
            <button
              onClick={() => onExecute('TRAILER', { force: true })}
              className="flex items-center gap-2 rounded-lg border border-stone-200 bg-white px-4 py-2 text-sm font-medium text-stone-700 transition hover:bg-stone-50"
            >
              <RefreshCw className="h-4 w-4" />
              重做（旧版）
            </button>
            <button
              onClick={handleGeneratePrompts}
              disabled={isExecuting}
              className="flex items-center gap-2 rounded-lg bg-stone-900 px-4 py-2 text-sm font-medium text-white transition hover:bg-stone-800 disabled:opacity-50"
            >
              {isExecuting ? (
                <LoaderCircle className="h-4 w-4 animate-spin" />
              ) : (
                <Play className="h-4 w-4" />
              )}
              开始新版生成
            </button>
          </div>
        </div>
      )
    }

    return (
      <div className="flex justify-center py-8">
        <div className="relative inline-block">
          <button
            onClick={handleGeneratePrompts}
            disabled={isExecuting}
            className="flex items-center gap-2 rounded-lg bg-stone-900 px-6 py-3 text-sm font-medium text-white transition hover:bg-stone-800 disabled:opacity-50"
          >
            {isExecuting ? (
              <>
                <LoaderCircle className="h-4 w-4 animate-spin" />
                准备中...
              </>
            ) : (
              <>
                <Play className="h-4 w-4" />
                开始执行
              </>
            )}
          </button>
            <CostBadge cost={GENERATION_COSTS.TRAILER} />
        </div>
      </div>
    )
  }

  if (step.status === 'PROCESSING') {
    return <ProcessingBlock message="宣传片生成中，请稍后..." />
  }

  if (step.status === 'FAILED') {
    return (
      <div className="space-y-4">
        <div className="rounded-lg border border-red-200 bg-red-50 p-4">
          <p className="text-sm font-semibold text-red-800">生成失败</p>
          <p className="mt-1 break-words text-sm text-red-700">
            {step.errorMessage || '未知错误'}
          </p>
        </div>
        <div className="flex justify-center">
          <button
            onClick={handleGeneratePrompts}
            disabled={isExecuting}
            className="flex items-center gap-2 rounded-lg bg-red-600 px-6 py-3 text-sm font-medium text-white transition hover:bg-red-700 disabled:opacity-50"
          >
            {isExecuting ? (
              <>
                <LoaderCircle className="h-4 w-4 animate-spin" />
                重试中...
              </>
            ) : (
              <>
                <RefreshCw className="h-4 w-4" />
                重试
              </>
            )}
          </button>
        </div>
      </div>
    )
  }

  return null
}
