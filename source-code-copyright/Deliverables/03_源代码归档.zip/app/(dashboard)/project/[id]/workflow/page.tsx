'use client'
// force-rebuild: 2026-06-21-1732

import { useState, useCallback, useEffect, useRef, useMemo, use } from 'react';
import Link from 'next/link'
import useSWR from 'swr'
import {
  LoaderCircle,
  ArrowRight,
  Play,
  Image as ImageIcon,
  FileText,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  Check,
  RefreshCw,
  Sparkles,
  Eye,
  EyeOff,
  Film,
  Download,
  FileJson,
  FileSpreadsheet,
  Square,
  Upload,
  Clock,
  X,
} from 'lucide-react'
import TopStepper from './_components/TopStepper'
import TrailerPanel from './_components/TrailerPanel'
import VideoDirectPanel from './_components/VideoDirectPanel'
import IdeaAnchor from '@/components/workflow/IdeaAnchor'
import QueueMonitor from '@/components/generation/QueueMonitor'
import MarkdownRenderer from '@/components/ui/MarkdownRenderer'
import { VISIBLE_STEP_TYPES } from '@/lib/workflow'
import { ASPECT_RATIO_OPTIONS, IMAGE_MODELS, MODEL_SHORT_NAME, STYLE_MODEL_POOL, VIDEO_MODELS, VIDEO_MODEL_SHORT_NAME } from '@/lib/models-config'
import { PROJECT_TAG_OPTIONS, PROJECT_TAG_PROMPTS } from '@/lib/project-tags'
import HoverImageBadge from '@/components/generation/HoverImageBadge'
import { ClickToEdit } from '@/components/ui/ClickToEdit'
import CostBadge from '@/components/CostBadge'
import { DEFAULT_GENERATE_COST, GENERATION_COSTS, calculateBatchCost, getImageGenerationCost } from '@/lib/points-config'
import { getStepDisplayState, prismaTypeToStepId } from '@/lib/workflow-state'
import { exportFrameworkToWord } from '@/lib/framework-export'
import FrameworkImportModal from '@/components/framework/FrameworkImportModal'
import IdeationDeepenPanel from '@/components/workflow/IdeationDeepenPanel'
import ReferenceBar from '@/components/workflow/ReferenceBar'
import FloatingGenerationPanel from '@/components/workflow/FloatingGenerationPanel'
import WorkflowInspectorDrawer from '@/components/workflow/WorkflowInspectorDrawer'
import SuggestionBar from '@/components/workflow/SuggestionBar'
import { exportStoryboardExcel } from '@/lib/storyboard-excel-export'
import { proxiedMediaUrl } from '@/lib/media-url'
import { ApiError } from '@/lib/api-client'

const fetcher = async (url: string) => {
  const response = await fetch(url)
  if (!response.ok) {
    const text = await response.text().catch(() => '')
    let payload: { message?: string; error?: string } | null = null
    try { payload = text ? JSON.parse(text) as { message?: string; error?: string } : null } catch {}
    const message = payload?.message || payload?.error || text || `HTTP ${response.status}`

    // This fetcher runs every three seconds. A single auth refresh race must not
    // navigate away from an open project; middleware still protects real page
    // loads, and SWR retains the last valid project while polling recovers.
    throw new ApiError(message, response.status, payload)
  }
  return response.json()
}

const STEP_LABELS: Record<string, string> = {
  IDEATION: '创意扩散',
  FRAMEWORK: '框架搭建',
  STYLE: '风格统一',
  CHARACTER: '人物设计',
  CONCEPT: '概念图',
  TRAILER: '宣传片',
  STORYBOARD: '分镜设计',
  KEYFRAMES: '生成尾帧',
  VIDEO_DIRECT: '直生视频',
  VIDEO_RENDER: 'AI渲染',
  CAMERA: '电脑运镜',
  REVIEW: '评测优化',
}

const API_STEP_MAP: Record<string, string> = {
  IDEATION: 'ideation',
  FRAMEWORK: 'framework',
  STYLE: 'style',
  CHARACTER: 'character',
  CONCEPT: 'concept',
  TRAILER: 'trailer',
  STORYBOARD: 'storyboard',
  KEYFRAMES: 'keyframes',
  VIDEO_DIRECT: 'video-direct',
  VIDEO_RENDER: 'video-render',
  CAMERA: 'camera',
  REVIEW: 'review',
}

const SHOW_STORYBOARD_BATCH_CONTROLS = false

function normalizeOptionalInt(value: unknown, fallback = 0): number {
  const parsed = typeof value === 'number' ? value : Number(value)
  return Number.isInteger(parsed) ? parsed : fallback
}

function formatFrameworkText(value: unknown): string {
  if (value == null) return ''
  if (typeof value === 'string') return value
  if (typeof value === 'number' || typeof value === 'boolean') return String(value)
  if (Array.isArray(value)) {
    return value.map(formatFrameworkText).filter(Boolean).join('、')
  }
  if (typeof value === 'object') {
    const labels: Record<string, string> = {
      spaceLayout: '空间布局',
      buildingStyle: '建筑风格',
      structuralDetails: '结构细节',
      architecturalFeatures: '建筑特征',
      lighting: '光影',
      colorPalette: '色彩',
      props: '道具',
      atmosphere: '氛围',
      culture: '人文',
      distinctive: '辨识度',
      storyFunction: '叙事功能',
    }

    return Object.entries(value as Record<string, unknown>)
      .map(([key, item]) => {
        const text = formatFrameworkText(item)
        return text ? `${labels[key] || key}：${text}` : ''
      })
      .filter(Boolean)
      .join('\n')
  }
  return String(value)
}

/**
 * 简单 fetch 重试：对 5xx / 网络错误做指数退避重试，最多 2 次。
 * 用于处理供应商 API 偶发的 503/504 等临时性故障。
 *
 * 每次尝试都带独立的超时：原先所有 fetch 都没有 signal，
 * 上游挂住时前端既不放弃也不提示，只能等浏览器/反代断开，
 * 用户看到的是一个永远转圈的按钮，于是反复点击。
 */
async function fetchWithRetry(
  url: string,
  init: RequestInit,
  maxRetries = 2,
  timeoutMs = 300_000
): Promise<Response> {
  let lastErr: any = null
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(new Error('请求超时')), timeoutMs)
    try {
      const res = await fetch(url, { ...init, signal: controller.signal })
      // 2xx 直接返回
      if (res.ok) return res
      // 5xx 重试（除了 501 Not Implemented）
      if (res.status >= 500 && res.status !== 501 && attempt < maxRetries) {
        console.warn(`[fetchWithRetry] ${url} → HTTP ${res.status}, attempt ${attempt + 1}/${maxRetries + 1}, retrying...`)
        await new Promise(r => setTimeout(r, 1500 * Math.pow(2, attempt)))
        continue
      }
      return res
    } catch (err: any) {
      lastErr = err
      const aborted = err?.name === 'AbortError' || controller.signal.aborted
      if (aborted) {
        // 超时不重试：整体预算已经耗尽，再重试只会让用户多等
        throw new Error(`请求超时（${Math.round(timeoutMs / 1000)}s），请稍后重试`)
      }
      if (attempt < maxRetries) {
        console.warn(`[fetchWithRetry] ${url} → network error, attempt ${attempt + 1}/${maxRetries + 1}, retrying...`, err?.message)
        await new Promise(r => setTimeout(r, 1500 * Math.pow(2, attempt)))
        continue
      }
      throw err
    } finally {
      // 定时器必须清理，否则每次请求都会留下一个悬挂的 5 分钟定时器
      clearTimeout(timer)
    }
  }
  throw lastErr ?? new Error('fetch failed after retries')
}

export default function WorkflowPage(props: { params: Promise<{ id: string }> }) {
  const params = use(props.params);
  const { data, error, mutate, isLoading } = useSWR(`/api/projects/${params.id}`, fetcher, {
    refreshInterval: (latest: { project?: { steps?: Array<{ status?: string }> } } | undefined) =>
      latest?.project?.steps?.some((step) => step.status === 'PROCESSING') ? 3000 : 15000,
    keepPreviousData: true,
    refreshWhenHidden: false,
  })

  const [activeStepType, setActiveStepType] = useState<string | null>(null)
  const [executing, setExecuting] = useState<string | null>(null)
  const [lastError, setLastError] = useState<string | null>(null)
  const [toast, setToast] = useState<{ kind: 'success' | 'error'; message: string } | null>(null)
  const [showImportModal, setShowImportModal] = useState(false)
  // [WORKFLOW-FIX] 分镜模式选择（工作流看板层级）
  const [storyboardMode, setStoryboardMode] = useState<'reference' | 'keyframe'>('keyframe')
  // 工作指令.txt（2026-06-02 卡死修复）：跟踪 PROCESSING 步骤的超时检测
  const processingStartRef = useRef<Record<string, number>>({})
  // CONCEPT 重试：子组件挂载后注册到 window 供 StepHeader 调用
  // 使用 window 而非 ref/closure 避免 production minifier 消除问题
  const [timeoutError, setTimeoutError] = useState<string | null>(null)
  // 提升到 WorkflowPage 级别，供 executeStep 和 StepContent 共享
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null)

  const project = data?.project
  const steps = project?.steps || []

  // 调试日志：确认数据流向
  if (data) console.log('[workflow] steps:', steps.length, 'project:', !!project)

  // 自动设置激活步骤
  // 工作指令.txt（2026-06-02）：IDEATION 完成后不要自动跳到 FRAMEWORK，
  // 让用户在创意扩散步骤手动选择方向后再进入下一步
  const ideationStep = steps.find((s: any) => s.stepType === 'IDEATION')
  const frameworkStep = steps.find((s: any) => s.stepType === 'FRAMEWORK')
  const shouldStayOnIdeation =
    ideationStep?.status === 'COMPLETED' && frameworkStep?.status === 'PENDING'

  const currentActive =
    activeStepType ||
    steps.find((s: any) => s.status === 'PROCESSING')?.stepType ||
    (shouldStayOnIdeation ? 'IDEATION' : undefined) ||
    steps.find((s: any) => s.status === 'PENDING')?.stepType ||
    steps[steps.length - 1]?.stepType

  const currentStep = steps.find((s: any) => s.stepType === currentActive)

  const executeStep = useCallback(
    async (stepType: string, body?: any) => {
      const apiPath = API_STEP_MAP[stepType]
      if (!apiPath) return
      setExecuting(stepType)
      setLastError(null)

      // 防御：FRAMEWORK 必须有有效的 directionIndex（首次生成时）
      const isRegenerate = body?.regenerate === true
      if (stepType === 'FRAMEWORK' && !isRegenerate) {
        const idx = body?.directionIndex ?? selectedIdx
        if (idx === undefined || idx === null) {
          setLastError('请先选择一个创意方向')
          setExecuting(null)
          return
        }
        body = { directionIndex: idx }
      }

      // 防御：未解锁步骤不允许执行，避免后端返回 WORKFLOW_002
      const stepId = prismaTypeToStepId(stepType)
      const stepRecord = steps.find((s: any) => s.stepType === stepType)
      if (stepId && project && stepRecord) {
        const displayState = getStepDisplayState(stepId, project)
        const isDone = displayState.isDone || stepRecord.status === 'COMPLETED'
        const isFailed = stepRecord.status === 'FAILED'
        const isProcessing = stepRecord.status === 'PROCESSING'

        // 兼容旧项目/状态未同步：实际分镜已有首帧时也视为可用
        let isAvailable = displayState.isAvailable
        if ((stepType === 'KEYFRAMES' || stepType === 'VIDEO_DIRECT') && !isAvailable) {
          const storyboardStep = steps.find((s: any) => s.stepType === 'STORYBOARD')
          const shots = storyboardStep?.outputData?.shots || []
          isAvailable = shots.some((shot: any) => Boolean(shot?.firstFrameUrl || shot?.referenceImageUrl))
        }

        // 兼容：若 STYLE 步骤已有 selectedStyleId / selectedRef 但 stepStyleDone 未被写入（旧数据/迁移遗漏），也视为可用
        if (stepType === 'CHARACTER' && !isAvailable) {
          const styleStep = steps.find((s: any) => s.stepType === 'STYLE')
          const styleOutput = (styleStep?.outputData as any) || {}
          if (
            styleOutput.selectedStyleId ||
            styleOutput.selectedRef ||
            styleOutput.styleRefUrl ||
            styleOutput.selectedStyleImage ||
            styleOutput.selectedStyle?.url ||
            project?.selectedStyleId
          ) {
            isAvailable = true
          }
        }

        const canRun = isDone || isFailed || isProcessing || isAvailable
        if (!canRun) {
          const stepLabel = STEP_LABELS[stepType] || stepType
          const reason = !displayState.isUnlocked
            ? '前置步骤尚未完成'
            : '该步骤当前不可用'
          setLastError(`「${stepLabel}」未解锁：${reason}，请先完成必要的前置步骤`)
          setExecuting(null)
          return
        }
      }

      // 调试日志
      console.log(`[executeStep] starting ${stepType}`, { body, bodyJson: JSON.stringify(body), isExecuting: executing })

      try {
        const url = isRegenerate
          ? `/api/projects/${params.id}/steps/${apiPath}/regenerate`
          : `/api/projects/${params.id}/steps/${apiPath}`
        const res = await fetch(url, {
          method: 'POST',
          headers: body ? { 'Content-Type': 'application/json' } : undefined,
          body: body ? JSON.stringify(body) : undefined,
        })

        // 调试日志：响应状态
        console.log(`[executeStep] ${stepType} response status:`, res.status)

        // 生成是长请求，期间的并发会话刷新可能瞬时返回 401。
        // 不在 mutation 中导航，避免已登录用户被登录页送回仪表盘。
        if (res.status === 401) {
          setLastError('会话校验暂时失败，请留在当前页刷新后重试')
          return
        }

        // 防御：超时或服务器崩溃可能导致响应为空/非 JSON
        let result: any
        try {
          result = await res.json()
        } catch (parseErr) {
          const text = await res.text().catch(() => '')
          console.error(`[executeStep] ${stepType} non-JSON response:`, text.slice(0, 500))
          const isTimeout = res.status === 504 || res.status === 502 || /timeout|timed out/gi.test(text)
          throw new Error(
            isTimeout
              ? '服务器响应超时，请稍后重试（框架生成可能需要 30–120 秒）'
              : `服务器返回无效响应 (HTTP ${res.status})`
          )
        }
        console.log(`[executeStep] ${stepType} response:`, JSON.stringify(result).slice(0, 500))

        if (!result.success) {
          if (result.error === 'POINTS_001') {
            setLastError('点数不足，请联系管理员充值')
            return
          }
          // 裸错误码对用户无意义，补上映射
          const errorLabel: Record<string, string> = {
            WORKFLOW_002: '前置步骤尚未完成',
            WORKFLOW_003: '请先完成分镜设计',
            WORKFLOW_004: '步骤尚未初始化',
            WORKFLOW_005: '步骤未在执行中',
            VALIDATION_001: '参数不完整',
            VALIDATION_002: '参数无效',
            AUTH_001: '登录状态已失效，请刷新页面',
            AUTH_002: '没有访问权限',
            STORAGE_001: '未找到可用的风格参考图',
            ALREADY_RUNNING: '该任务已在进行中',
          }
          const code = String(result.error || '未知错误')
          const friendly = errorLabel[code] || code
          const errorMsg = `执行失败：${friendly}${result.message ? ' — ' + result.message.slice(0, 100) : ''}`
          setLastError(errorMsg)
          setToast({ kind: 'error', message: friendly + (result.message ? `：${result.message.slice(0, 80)}` : '') })
          return
        }

        // 抢占被拒：服务端返回 success + alreadyRunning。
        // 不做提示的话前端会判成功，用户看到「点了完全没反应」。
        if (result.alreadyRunning) {
          setToast({ kind: 'error', message: result.message || '该任务已在进行中，请等待完成' })
          await mutate()
          return
        }

        // 调试日志：成功
        console.log(`[executeStep] ${stepType} completed successfully`)
        if (result.message) {
          setToast({ kind: 'success', message: String(result.message).slice(0, 120) })
        }
        await mutate()
      } catch (e: any) {
        console.error(`[executeStep] ${stepType} error:`, e)
        setLastError('网络错误：' + e.message)
      } finally {
        setExecuting(null)
      }
    },
    [params.id, mutate, executing, selectedIdx]
  )

  // 中断步骤
  const handleCancel = useCallback(
    async (stepType: string) => {
      try {
        const res = await fetch(`/api/projects/${params.id}/steps/cancel`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ stepType }),
        })
        const result = await res.json()
        if (!res.ok || !result.success) {
          setToast({ kind: 'error', message: `中断失败：${result.error || '未知错误'}` })
          return
        }
        setToast({ kind: 'success', message: '已中断' })
        await mutate()
      } catch (e: any) {
        setToast({ kind: 'error', message: '中断失败：' + e.message })
      }
    },
    [params.id, mutate]
  )

  // 暴露 executeStep 到 window,让副工作台"确认生成"按钮可调用
  useEffect(() => {
    ;(window as any).__executeStep = executeStep
    // 暴露 mutate 给 retry 副工作台用
    ;(window as any).__refreshProject = () => { mutate() }
    // 暴露 toast
    ;(window as any).__showToast = (t: { kind: 'success' | 'error'; message: string } | null) => setToast(t)
    return () => {
      delete (window as any).__executeStep
      delete (window as any).__refreshProject
      delete (window as any).__showToast
    }
  }, [executeStep, mutate])

  const selectStyle = useCallback(
    async (styleId: string, styleRefUrl?: string) => {
      // 【强制日志5】确认前端传的值
      console.log('[SELECT-STYLE-FRONT] 点击 styleId:', styleId)
      console.log('[SELECT-STYLE-FRONT] 点击 styleRefUrl:', styleRefUrl)
      console.log('[SELECT-STYLE-FRONT] styleRefUrl 类型:', typeof styleRefUrl)
      console.log('[SELECT-STYLE-FRONT] styleRefUrl 是否http:', styleRefUrl?.startsWith?.('http'))
      // 工作指令.txt（修复一）：放宽校验。图片已能显示说明 URL 浏览器认为有效；
      // 不再要求 http(s) 前缀（data: URL / 签名 URL 都允许）。
      if (!styleRefUrl || typeof styleRefUrl !== 'string' || styleRefUrl.trim() === '') {
        setToast({ kind: 'error', message: '该风格图尚未生成完成，无法选择' })
        return
      }
      try {
        const res = await fetch(`/api/projects/${params.id}/steps/style`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ selectedStyleId: styleId, styleRefUrl }),
        })
        // 工作指令.txt（Round 5 修复 #1）：res.text() 容错解析。
        // Next.js 在路由错误 / 中间件异常时可能返回空 body / HTML 错误页，
        // 直接 res.json() 会抛 "Unexpected end of JSON input"。
        const responseText = await res.text()
        console.log('[SELECT-STYLE-FRONT] PATCH 状态:', res.status, '原始响应前200字符:', responseText.slice(0, 200))
        let result: any = {}
        if (responseText.trim()) {
          try {
            result = JSON.parse(responseText)
          } catch {
            console.warn('[SELECT-STYLE-FRONT] 响应非 JSON，按 res.ok 判断成败')
          }
        }
        if (!res.ok) throw new Error(result.error || result.message || `HTTP ${res.status}`)

        // Phase 4: 同步更新 framework 中的 selectedStyleImage
        try {
          await fetch(`/api/projects/${params.id}/steps/framework`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ selectedStyleImage: styleRefUrl }),
          })
          console.log('[SELECT-STYLE-FRONT] 已同步到 framework.selectedStyleImage')
        } catch (fwErr: any) {
          console.warn('[SELECT-STYLE-FRONT] 同步到 framework 失败:', fwErr.message)
        }

        await mutate()
        setToast({ kind: 'success', message: '已保存为统一视觉基准 — 将影响人物设计、概念图、尾帧和直生视频' })
      } catch (e: any) {
        setToast({ kind: 'error', message: '选择风格失败：' + e.message })
      }
    },
    [params.id, mutate]
  )

  useEffect(() => {
    if (!toast) return
    const timer = setTimeout(() => setToast(null), 3000)
    return () => clearTimeout(timer)
  }, [toast])

  // 工作指令.txt（2026-06-02 卡死修复）：检测 PROCESSING 步骤是否超时（超过10分钟）
  useEffect(() => {
    const processingSteps = steps.filter((s: any) => s.status === 'PROCESSING')
    const now = Date.now()
    const TIMEOUT_MS = 10 * 60 * 1000 // 10分钟

    let anyTimeout = false

    for (const step of processingSteps) {
      const stepId = step.id
      const startedAt = step.startedAt ? new Date(step.startedAt).getTime() : null

      if (startedAt) {
        const stored = processingStartRef.current[stepId]
        // 如果还没记录，或数据库的 startedAt 明显更新（超过1秒差异），说明重新生成了，更新记录
        if (!stored || Math.abs(startedAt - stored) > 1000) {
          processingStartRef.current[stepId] = startedAt
        }
      }

      const startTime = processingStartRef.current[stepId] || startedAt || now
      const elapsed = now - startTime

      if (elapsed > TIMEOUT_MS) {
        anyTimeout = true
      }
    }

    // 设置或清除超时错误
    if (anyTimeout && !timeoutError) {
      const firstTimeoutStep = processingSteps.find((step: any) => {
        const stepId = step.id
        const startedAt = step.startedAt ? new Date(step.startedAt).getTime() : null
        const startTime = processingStartRef.current[stepId] || startedAt || now
        return (now - startTime) > TIMEOUT_MS
      })
      if (firstTimeoutStep) {
        setTimeoutError(
          `步骤「${STEP_LABELS[firstTimeoutStep.stepType] || firstTimeoutStep.stepType}」生成超时（已超过10分钟），请检查网络或稍后重试`
        )
      }
    } else if (!anyTimeout && timeoutError) {
      setTimeoutError(null)
    }

    // 清理已完成的步骤记录
    const completedIds = new Set(
      steps.filter((s: any) => s.status !== 'PROCESSING').map((s: any) => s.id)
    )
    for (const id of Object.keys(processingStartRef.current)) {
      if (completedIds.has(id)) {
        delete processingStartRef.current[id]
      }
    }
  }, [steps, timeoutError])

  function goToNextStep() {
    if (!currentStep) return
    const next = steps.find((s: any) => s.order === currentStep.order + 1)
    if (next) setActiveStepType(next.stepType)
  }

  if (isLoading) return <LoadingBlock />
  if (error && !project) return <ErrorBlock message={error.message} />
  if (!project) {
    const apiError = data?.error
    if (apiError === 'AUTH_001' || apiError === 'AUTH_002') {
      return <ErrorBlock message="会话已过期或无权访问此项目，正在跳转…" />
    }
    return <ErrorBlock message={data?.message || '项目未找到，请从仪表盘重新进入'} />
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      {/* Toast：风格选中等成功/失败的瞬时反馈 */}
      {toast && (
        <div
          className={`fixed bottom-8 left-1/2 z-50 -translate-x-1/2 rounded-xl px-5 py-2.5 text-sm font-medium shadow-lg transition-all duration-300 ease-out ${
            toast.kind === 'success'
              ? 'bg-stone-900 text-white translate-y-0 opacity-100'
              : 'bg-red-500 text-white translate-y-0 opacity-100'
          } animate-bounce-in`}
          role="status"
        >
          {toast.kind === 'success' ? '✓ ' : '⚠ '}
          {toast.message}
        </div>
      )}
      {/* 头部 */}
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Link
            href={`/project/${params.id}`}
            className="text-sm text-stone-500 transition hover:text-stone-800"
          >
            ← 返回总览
          </Link>
        </div>
      </div>

      <div className="mb-2">
        <h1 className="text-2xl font-bold text-stone-800">{project.title}</h1>
        <p className="mt-1 text-sm text-stone-500">工作流看板 — 共 {VISIBLE_STEP_TYPES.length} 步</p>
      </div>

      {/* 建议动作 */}
      {project && steps.length > 0 && (
        <SuggestionBar steps={steps} project={project} activeStep={currentActive} onLocate={(t) => setActiveStepType(t)} />
      )}

      {/* ReferenceBar */}
      <ReferenceBar
        projectId={params.id}
        defaultExpanded={currentActive === 'IDEATION'}
      />

      {/* TopStepper */}
      <TopStepper
        steps={steps}
        project={project}
        activeStepType={currentActive}
        onStepClick={(type) => setActiveStepType(type)}
      />

      {/* 步骤内容区 */}
      {currentStep && (
        <div className="rounded-lg border border-stone-200 bg-white p-6 shadow-sm">
          <StepHeader
            step={currentStep}
            project={project}
            executing={executing}
            onExecute={() => executeStep(currentStep.stepType)}
            onRetry={() => {
              if (currentStep.stepType === 'FRAMEWORK') {
                executeStep('FRAMEWORK', { regenerate: true })
              } else if (currentStep.stepType === 'CONCEPT') {
                // CONCEPT：走新的异步生成路径（202 + 轮询），避免 504 超时
                const hasPrompts = (currentStep.outputData?.prompts?.length || 0) > 0
                if (hasPrompts) {
                  const defaultRatio = currentStep.outputData?.aspectRatio || project.selectedAspectRatio || '16:9'
                  const defaultModel = currentStep.outputData?.imageModel || IMAGE_MODELS.primary
                  ;(window as any).__conceptRetry?.(currentStep.outputData.prompts.length, defaultRatio, defaultModel)
                } else {
                  executeStep('CONCEPT', { action: 'generate-prompts' })
                }
              } else if (['STYLE', 'CHARACTER', 'STORYBOARD', 'KEYFRAMES'].includes(currentStep.stepType)) {
                // 工作指令.txt（2026-06-07）：重试必须走完整流程，不能跳过提示词生成
                const hasPrompts = currentStep.outputData?.prompts?.length > 0
                if (hasPrompts) {
                  const defaultRatio = currentStep.outputData?.aspectRatio || project.selectedAspectRatio || '16:9'
                  const defaultModel = currentStep.outputData?.imageModel || IMAGE_MODELS.primary
                  executeStep(currentStep.stepType, { action: 'generate-images', force: true, aspectRatio: defaultRatio, imageModel: defaultModel })
                } else {
                  executeStep(currentStep.stepType, { action: 'generate-prompts' })
                }
              } else {
                executeStep(currentStep.stepType)
              }
            }}
            onCancel={() => handleCancel(currentStep.stepType)}
            onNext={goToNextStep}
            onImport={currentStep.stepType === 'FRAMEWORK' ? () => setShowImportModal(true) : undefined}
            onExportDoc={
              currentStep.stepType === 'FRAMEWORK'
                ? () => {
                    const fw = currentStep.outputData || project?.framework || {}
                    exportFrameworkToWord({
                      projectTitle: project?.title || '未命名项目',
                      inspiration: fw.inspiration,
                      inspirationSource: fw.inspirationSource,
                      background: fw.background,
                      visualStyle: fw.visualStyle || fw.styleGuide,
                      selectedStyleImage: fw.selectedStyleImage,
                      characters: fw.characters,
                      synopsis: fw.synopsis,
                      deepenedSynopsis: fw.deepenedSynopsis,
                      acts: fw.acts,
                      environments: fw.environments,
                      overallPacing: fw.overallPacing,
                      storyLength: fw.storyLength,
                      totalDuration: fw.totalDuration,
                    })
                  }
                : undefined
            }
          />

          {lastError && (
            <ErrorBanner message={lastError} onDismiss={() => setLastError(null)} />
          )}
          {timeoutError && (
            <ErrorBanner message={timeoutError} onDismiss={() => setTimeoutError(null)} />
          )}

          <div className="mt-6">
            <StepContent
              step={currentStep}
              project={project}
              executing={executing}
              onExecute={(stepType, body) => {
                // 先打开副工作台,显示生成前确认
                if ((window as any).__buildConfirmFromCurrentStep) {
                  ;(window as any).__buildConfirmFromCurrentStep(body)
                } else {
                  // 兜底:直接执行
                  executeStep(stepType, body)
                }
              }}
              onSelectStyle={selectStyle}
              onError={setLastError}
              mutate={mutate}
              setToast={setToast}
              storyboardMode={storyboardMode}
              setStoryboardMode={setStoryboardMode}
              readOnly={(() => {
                const stepId = prismaTypeToStepId(currentStep.stepType)
                const displayState = stepId ? getStepDisplayState(stepId, project) : null
                return displayState?.isHidden ?? false
              })()}
              selectedIdx={selectedIdx}
              setSelectedIdx={setSelectedIdx}
            />
          </div>

          {/* 决策提示栏：已选视觉基准时显示 */}
          {currentStep.stepType === 'STYLE' && project.selectedStyleId && (
            <div className="mt-5 flex items-center justify-between gap-4 rounded-2xl border border-amber-200 bg-gradient-to-r from-amber-50 to-orange-50/60 px-5 py-3.5">
              <div>
                <span className="text-sm font-semibold text-amber-800">已选视觉基准：</span>
                <span className="text-sm text-amber-700">该资产将用于人物设计、概念图、分镜尾帧和视频片段生成。切换基准时会提示是否影响已生成资产。</span>
              </div>
              <button
                onClick={() => { (window as any).__openInspector?.('task-queue') }}
                className="shrink-0 rounded-lg border border-amber-300 bg-white px-3.5 py-2 text-xs font-medium text-stone-600 transition hover:bg-amber-50"
              >
                展开副工作台
              </button>
            </div>
          )}

          {/* 底部导航 */}
          {currentStep.status === 'COMPLETED' && (
            () => {
              const stepId = prismaTypeToStepId(currentStep.stepType)
              const displayState = stepId ? getStepDisplayState(stepId, project) : null
              const isHidden = displayState?.isHidden ?? false
              if (isHidden) return null
              return (
                <div className="mt-6 border-t border-stone-100 pt-4">
                  {currentStep.stepType === 'STYLE' && !project.selectedStyleId ? (
                    <button
                      disabled
                      className="flex cursor-not-allowed items-center gap-2 rounded-lg bg-stone-300 px-5 py-2.5 text-sm font-medium text-white"
                    >
                      请先选择一张风格图作为基准
                      <ArrowRight className="h-4 w-4" />
                    </button>
                  ) : (
                    <button
                      onClick={goToNextStep}
                      className="flex items-center gap-2 rounded-lg bg-stone-800 px-5 py-2.5 text-sm font-medium text-white transition hover:bg-stone-700"
                    >
                      下一步
                      <ArrowRight className="h-4 w-4" />
                    </button>
                  )}
                </div>
              )
            }
          )()}
        </div>
      )}

      {/* 队列监控（固定右下角） */}
      <QueueMonitor projectId={params.id} steps={steps} />

      {/* 框架导入弹窗 */}
      {showImportModal && (
        <FrameworkImportModal
          projectId={params.id}
          onClose={() => setShowImportModal(false)}
          onImported={() => {
            mutate()
            setShowImportModal(false)
          }}
        />
      )}

      {/* 浮动生成任务面板 */}
      <FloatingGenerationPanel
        steps={steps}
        projectId={params.id}
        onViewDetails={(s) => {
          if ((window as any).__buildFeedbackFromStep) {
            ;(window as any).__buildFeedbackFromStep(s)
          } else if ((window as any).__openInspector) {
            ;(window as any).__openInspector('result')
          }
        }}
        onViewResult={(s) => { setActiveStepType(s.stepType); mutate() }}
        onOpenAssetLibrary={(s) => { window.location.href = `/project/${params.id}/assets` }}
        onLocateStep={(t) => {
          setActiveStepType(t)
          if ((window as any).__buildConfirmFromCurrentStep) {
            ;(window as any).__buildConfirmFromCurrentStep()
          }
        }}
      />
      <WorkflowInspectorDrawerWrapper
        steps={steps}
        projectId={params.id}
        currentStep={currentStep}
        project={project}
        setActiveStepType={setActiveStepType}
      />
    </div>
  )
}

function WorkflowInspectorDrawerWrapper({
  steps,
  projectId,
  currentStep,
  project,
  setActiveStepType,
}: {
  steps: any[]
  projectId: string
  currentStep: any
  project: any
  setActiveStepType: (t: string) => void
}) {
  const [isOpen, setIsOpen] = useState(false)
  const [confirmData, setConfirmData] = useState<any>(null)
  const [feedbackData, setFeedbackData] = useState<any>(null)
  const [retryEditData, setRetryEditData] = useState<any>(null)
  const retryActionsRef = useRef(new Set<string>())
  const [activeView, setActiveView] = useState<'task-queue' | 'generation-confirm' | 'result-feedback' | 'retry-edit'>('task-queue')

  const openInspector = useCallback((view: 'task-queue' | 'generation-confirm' | 'result-feedback' | 'retry-edit') => {
    setActiveView(view)
    setIsOpen(true)
  }, [])

  // 点击"生成/重新生成"时打开副工作台 + 构建实际参数
  const [pendingBody, setPendingBody] = useState<any>(null)

  const buildConfirmFromCurrentStep = useCallback((body?: any, overrideStepType?: string) => {
    if (!currentStep) return
    setPendingBody(body || null)
    // 兼容：IDEATION 步骤点击"进入下一步"时 body.directionIndex 存在但 stepType 实际是 FRAMEWORK
    const targetStepType =
      overrideStepType
      || (body?.directionIndex !== undefined && currentStep.stepType === 'IDEATION' ? 'FRAMEWORK' : currentStep.stepType)
    const out = currentStep.outputData || {}
    const prompt = out.prompts?.[0]?.englishPrompt
      || out.prompts?.[0]?.chineseDesc
      || out.englishPrompt
      || out.chineseDesc
      || ''
    setConfirmData({
      stepType: targetStepType,
      inputDeps: getInputDeps(targetStepType, project),
      model: out.imageModel || out.modelId || 'gpt-image-1',
      aspectRatio: out.aspectRatio || project.selectedAspectRatio || '16:9',
      prompt,
      pointCost: 5,
    })
    openInspector('generation-confirm')
  }, [currentStep, project, openInspector])

  // 任务完成时显示结果反馈
  const buildFeedbackFromStep = useCallback((step: any) => {
    if (!step) return
    setFeedbackData({
      step,
      stages: step.status === 'FAILED' ? [{ name: '生成', status: 'failed', error: step.errorMessage }] : [],
      previewUrl: step.outputData?.styleRefUrl || step.outputData?.imageUrl || step.outputData?.url,
      partialSuccess: false,
      failedReason: step.status === 'FAILED' ? step.errorMessage : undefined,
      preservedAssets: [],
    })
    openInspector('result-feedback')
  }, [openInspector])

  // 打开分镜重试副工作台（StoryboardPanel 通过 window 调用）
  const openRetryEditForStoryboard = useCallback((payload: {
    shotId: string
    actNumber?: number
    targetLabel: string
    basePrompt: string
    baseRefs: Array<{ url: string; label: string; type: 'character' | 'style' | 'previous-shot' | 'user-upload' | 'user-dragged'; removable: boolean }>
    originalImageUrl: string | null
    currentModel: string
    aspectRatio: string
  }) => {
    setRetryEditData({
      stepType: 'storyboard',
      targetId: payload.shotId,
      actNumber: payload.actNumber,
      targetLabel: payload.targetLabel,
      basePrompt: payload.basePrompt,
      baseRefs: payload.baseRefs,
      originalImageUrl: payload.originalImageUrl,
      currentModel: payload.currentModel,
      aspectRatio: payload.aspectRatio,
      pointCost: 5,
    })
    openInspector('retry-edit')
  }, [openInspector])

  /**
   * 生成一个稳定的 clientActionId。
   *
   * 幂等键是 storyboard-retry:<user>:<project>:<act>:<shot>:<clientActionId>，
   * 所以 id 必须「一次用户意图一个」：如果每次点击都新生成 UUID，
   * 用户等不了再点一次就会绕过幂等，真实调用供应商并重复扣点。
   * 另外 crypto.randomUUID 只在 secure context 可用，
   * 非 https / 非 localhost 会抛 TypeError —— 抛在 try 之外会让
   * retryActionsRef 的 key 永远不解锁，此后该镜头点多少次都没反应。
   */
  const retryActionIdsRef = useRef<Record<string, string>>({})
  const nextRetryActionId = useCallback((key: string) => {
    const existing = retryActionIdsRef.current[key]
    if (existing) return existing
    let id: string
    try {
      id = crypto.randomUUID()
    } catch {
      id = `fallback-${Date.now()}-${Math.random().toString(36).slice(2, 12)}`
    }
    retryActionIdsRef.current[key] = id
    return id
  }, [])
  const clearRetryActionId = useCallback((key: string) => {
    delete retryActionIdsRef.current[key]
  }, [])

  // 重试副工作台的"重新生成"按钮实际执行
  const executeRetryRegenerate = useCallback(async (data: any, options: { promptOverride: string; refs: string[] }) => {
    const targetKey = `${data.actNumber ?? 0}_${data.targetId}`
    if (retryActionsRef.current.has(targetKey)) {
      // 原实现是静默 return：请求进行中（最长 180s+）再点一次，看到的就是「点了完全没反应」
      ;(window as any).__showToast?.({ kind: 'error', message: '该镜头正在重新生成中，请等待当前任务完成' })
      return
    }
    retryActionsRef.current.add(targetKey)
    const clientActionId = nextRetryActionId(targetKey)
    window.dispatchEvent(new CustomEvent('storyboard-generation-state', { detail: {
      key: targetKey,
      state: { status: 'processing', shotId: data.targetId, actNumber: data.actNumber, startedAt: new Date().toISOString(), message: '请求已受理，正在准备生成' },
    } }))
    try {
      const res = await fetchWithRetry(`/api/projects/${projectId}/steps/storyboard/regenerate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          shotId: data.targetId,
          actNumber: data.actNumber,
          aspectRatio: data.aspectRatio,
          imageModel: data.currentModel,
          mode: 'regenerate',
          promptOverride: options.promptOverride,
          refImages: options.refs,
          clientActionId,
        }),
      })
      const result = await res.json()
      // 服务端对重复的 clientActionId 返回 409 { success:false, duplicate:true }，
      // 必须在 !res.ok 之前先处理，否则正确的去重会被报成"重新生成失败"
      if (result?.duplicate && result.operationStatus !== 'SUCCEEDED') {
        if ((window as any).__refreshProject) (window as any).__refreshProject()
        ;(window as any).__showToast?.({ kind: 'success', message: result.message || '任务已受理，正在处理中' })
        return
      }
      if (!res.ok || !result?.success) throw new Error(result?.message || `HTTP ${res.status}`)
      // 触发项目数据刷新（主页面 useSWR）
      if ((window as any).__refreshProject) (window as any).__refreshProject()
      window.dispatchEvent(new CustomEvent('storyboard-generation-state', { detail: { key: targetKey, state: { status: 'completed' } } }))
      if (result.isMock) {
        ;(window as any).__showToast?.({ kind: 'error', message: result.warning || '当前模型不可用，返回了占位图，点数未扣除，请切换模型重试' })
      } else {
        ;(window as any).__showToast?.({ kind: 'success', message: '分镜草图已重新生成' })
      }
    } catch (e: any) {
      window.dispatchEvent(new CustomEvent('storyboard-generation-state', { detail: {
        key: targetKey,
        state: { status: 'failed', message: e?.message || '重新生成失败' },
      } }))
      ;(window as any).__showToast?.({ kind: 'error', message: '重新生成失败：' + e?.message })
    } finally {
      retryActionsRef.current.delete(targetKey)
      clearRetryActionId(targetKey)
      // 请求真正结束后才关抽屉：提前关闭会销毁 RetryEditView 的 submitting 状态，
      // 用户点下去看不到任何“生成中”反馈，就会反复点击
      setIsOpen(false)
    }
  }, [projectId, nextRetryActionId, clearRetryActionId])

  // 重试副工作台的"修改原图"按钮实际执行
  const executeRetryEditOriginal = useCallback(async (data: any, options: { editInstruction: string; refs: string[] }) => {
    const targetKey = `${data.actNumber ?? 0}_${data.targetId}`
    if (retryActionsRef.current.has(targetKey)) {
      // 原实现是静默 return：请求进行中（最长 180s+）再点一次，看到的就是「点了完全没反应」
      ;(window as any).__showToast?.({ kind: 'error', message: '该镜头正在重新生成中，请等待当前任务完成' })
      return
    }
    retryActionsRef.current.add(targetKey)
    const clientActionId = nextRetryActionId(targetKey)
    window.dispatchEvent(new CustomEvent('storyboard-generation-state', { detail: {
      key: targetKey,
      state: { status: 'processing', shotId: data.targetId, actNumber: data.actNumber, startedAt: new Date().toISOString(), message: '请求已受理，正在修改原图' },
    } }))
    try {
      const res = await fetchWithRetry(`/api/projects/${projectId}/steps/storyboard/regenerate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          shotId: data.targetId,
          actNumber: data.actNumber,
          aspectRatio: data.aspectRatio,
          imageModel: data.currentModel,
          mode: 'edit-original',
          editInstruction: options.editInstruction,
          refImages: options.refs,
          clientActionId,
        }),
      })
      const result = await res.json()
      // 先处理 duplicate（服务端返回 409 + success:false），再判失败
      if (result?.duplicate && result.operationStatus !== 'SUCCEEDED') {
        if ((window as any).__refreshProject) (window as any).__refreshProject()
        ;(window as any).__showToast?.({ kind: 'success', message: result.message || '任务已受理，正在处理中' })
        return
      }
      if (!res.ok || !result?.success) throw new Error(result?.message || `HTTP ${res.status}`)
      if ((window as any).__refreshProject) (window as any).__refreshProject()
      window.dispatchEvent(new CustomEvent('storyboard-generation-state', { detail: { key: targetKey, state: { status: 'completed' } } }))
      if (result.isMock) {
        ;(window as any).__showToast?.({ kind: 'error', message: result.warning || '当前模型不可用，返回了占位图，点数未扣除，请切换模型重试' })
      } else {
        ;(window as any).__showToast?.({ kind: 'success', message: '修改完成' })
      }
    } catch (e: any) {
      window.dispatchEvent(new CustomEvent('storyboard-generation-state', { detail: {
        key: targetKey,
        state: { status: 'failed', message: e?.message || '修改失败' },
      } }))
      ;(window as any).__showToast?.({ kind: 'error', message: '修改失败：' + e?.message })
    } finally {
      retryActionsRef.current.delete(targetKey)
      clearRetryActionId(targetKey)
      // 请求真正结束后才关抽屉：提前关闭会销毁 RetryEditView 的 submitting 状态，
      // 用户点下去看不到任何“生成中”反馈，就会反复点击
      setIsOpen(false)
    }
  }, [projectId, nextRetryActionId, clearRetryActionId])

  useEffect(() => {
    ;(window as any).__openInspector = openInspector
    ;(window as any).__buildConfirmFromCurrentStep = buildConfirmFromCurrentStep
    ;(window as any).__buildFeedbackFromStep = buildFeedbackFromStep
    ;(window as any).__openRetryEditForStoryboard = openRetryEditForStoryboard
    return () => {
      delete (window as any).__openInspector
      delete (window as any).__buildConfirmFromCurrentStep
      delete (window as any).__buildFeedbackFromStep
      delete (window as any).__openRetryEditForStoryboard
    }
  }, [openInspector, buildConfirmFromCurrentStep, buildFeedbackFromStep, openRetryEditForStoryboard])

  useEffect(() => {
    if (!currentStep) return
    if (currentStep.status !== 'PROCESSING' && confirmData) {
      setConfirmData(null)
    }
  }, [currentStep?.status])

  return (
    <>
      {/* 副工作台入口按钮 — 始终可见
          对比度：amber-600(#d97706) on white/90 只有约 3.1:1，低于 WCAG AA 的 4.5:1，
          加上竖排文字后在亮屏上会"发白看不清"。改用 amber-800 + 不透明底 + 深色边框。 */}
      <button
        onClick={() => openInspector('task-queue')}
        className="fixed right-0 top-1/3 z-40 rounded-l-xl border border-r-0 border-amber-300 bg-white px-3 py-4 text-xs font-bold text-amber-800 shadow-md transition hover:bg-amber-50 hover:pr-4 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
        style={{ writingMode: 'vertical-rl' }}
        title="打开副工作台"
      >
        副工作台
      </button>
      <WorkflowInspectorDrawer
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        projectId={projectId}
        steps={steps}
        activeView={activeView}
        onViewChange={setActiveView}
        confirmData={confirmData}
        feedbackData={feedbackData}
        retryEditData={retryEditData}
        onRetryRegenerate={executeRetryRegenerate}
        onRetryEditOriginal={executeRetryEditOriginal}
        onLocateStep={(t) => { setActiveStepType(t); setIsOpen(false) }}
        onLocateTaskStep={(t) => { setActiveStepType(t); setIsOpen(false) }}
        onConfirmGenerate={async () => {
          // 必须在请求真正发出之后再关抽屉。
          // 原实现第一行就 setIsOpen(false) 且不 await：
          // 抽屉里 GenerationConfirmView 的 `confirming` 状态只存在 1 帧就随卸载销毁，
          // 用户点下去完全看不到"生成中"，于是反复点击。
          if (!confirmData) {
            setIsOpen(false)
            return
          }
          if (!(window as any).__executeStep) {
            setIsOpen(false)
            ;(window as any).__showToast?.({ kind: 'error', message: '执行入口未就绪，请刷新页面后重试' })
            return
          }
          try {
            await (window as any).__executeStep(confirmData.stepType, pendingBody || undefined)
          } finally {
            // executeStep 内部已经维护 executing / toast / lastError，
            // 这里只在它结束后收起抽屉
            setIsOpen(false)
          }
        }}
      />
    </>
  )
}

function getInputDeps(stepType: string, project: any): string[] {
  const map: Record<string, string[]> = {
    IDEATION: [],
    FRAMEWORK: ['原始元构思'],
    STYLE: ['框架 (synopsis + visualStyle)', '可选用户参考图'],
    CHARACTER: ['风格基准', '角色列表', '可选用户参考图'],
    CONCEPT: ['风格基准', '角色图', '剧本框架', '可选用户参考图'],
    TRAILER: ['概念图 (≥1)', '已生成片段', 'BGM 策略'],
    STORYBOARD: ['风格基准', '概念图', '角色图', '分幕', '可选用户参考图'],
    KEYFRAMES: ['起始帧 (from storyboard)', '风格基准', '角色图', '可选用户参考图'],
    VIDEO_DIRECT: ['起始帧 + 尾帧 (from keyframes)', '风格基准'],
  }
  return map[stepType] || []
}

function buildStages(step: any): Array<{ name: string; status: 'completed' | 'processing' | 'failed' | 'pending'; progress?: number; error?: string }> {
  const out = step.outputData || {}
  const isFailed = step.status === 'FAILED'
  const isCompleted = step.status === 'COMPLETED'
  const isProcessing = step.status === 'PROCESSING'

  return [
    { name: '参数计算', status: 'completed' },
    { name: '提示词生成', status: isFailed && !out.prompts ? 'failed' : isCompleted || out.prompts ? 'completed' : 'processing' },
    { name: '模型调用', status: isFailed ? 'failed' : isProcessing ? 'processing' : isCompleted ? 'completed' : 'pending' },
    { name: '资产写入', status: isFailed ? 'failed' : isCompleted ? 'completed' : isProcessing ? 'processing' : 'pending' },
  ]
}

/* ============================================================
   子组件
   ============================================================ */

function LoadingBlock() {
  return (
    <div className="flex items-center justify-center p-20">
      <LoaderCircle className="h-8 w-8 animate-spin text-stone-400" />
      <span className="ml-3 text-stone-500">加载中...</span>
    </div>
  )
}

function ErrorBlock({ message }: { message: string }) {
  return (
    <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-center">
      <p className="text-sm font-medium text-red-700">{message}</p>
    </div>
  )
}

function ErrorBanner({
  message,
  onDismiss,
}: {
  message: string
  onDismiss: () => void
}) {
  return (
    <div className="rounded-lg border border-red-200 bg-red-50 p-4">
      <div className="flex items-start gap-3">
        <p className="flex-1 text-sm font-medium text-red-700">{message}</p>
        <button
          onClick={onDismiss}
          className="shrink-0 text-red-400 transition hover:text-red-600"
        >
          ✕
        </button>
      </div>
    </div>
  )
}

function StepHeader({
  step,
  project,
  executing,
  onExecute,
  onRetry,
  onCancel,
  onNext,
  onImport,
  onExportDoc,
}: {
  step: any
  project: any
  executing: string | null
  onExecute: () => void
  onRetry: () => void
  onCancel: () => void
  onNext: () => void
  onImport?: () => void
  onExportDoc?: () => void
}) {
  const isExecuting = executing === step.stepType
  const isCancelled = step.status === 'FAILED' && step.errorMessage?.startsWith('[CANCELLED]')

  // DAG 状态机计算
  const stepId = prismaTypeToStepId(step.stepType)
  const displayState = stepId ? getStepDisplayState(stepId, project) : null
  const isHidden = displayState?.isHidden ?? false
  const isDone = displayState?.isDone ?? step.status === 'COMPLETED'
  const isAvailable = displayState?.isAvailable ?? true

  const statusConfig: Record<
    string,
    { label: string; className: string }
  > = {
    PENDING: { label: isAvailable ? '待开始' : '未解锁', className: 'bg-stone-100 text-stone-500' },
    PROCESSING: { label: '进行中', className: 'bg-blue-50 text-blue-600' },
    COMPLETED: { label: isHidden ? '已完成 · 已归档' : '已完成', className: isHidden ? 'bg-stone-100 text-stone-500' : 'bg-green-50 text-green-600' },
    FAILED: { label: isCancelled ? '已中断' : '失败', className: isCancelled ? 'bg-stone-100 text-stone-500' : 'bg-red-50 text-red-600' },
  }

  const config = statusConfig[step.status] || statusConfig.PENDING

  return (
    <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <h2 className="text-xl font-semibold tracking-tight text-stone-800">
          {STEP_LABELS[step.stepType]}
        </h2>
        <span
          className={`mt-1 inline-block rounded-full px-3 py-0.5 text-xs font-medium ${config.className}`}
        >
          {config.label}
        </span>
      </div>

      <div className="flex items-center gap-2">
        {/* 未解锁步骤 */}
        {!isHidden && !isAvailable && (
          <span className="rounded-lg border border-stone-200 px-4 py-2 text-xs text-stone-400">
            请先完成前置步骤
          </span>
        )}

        {/* 可执行且未完成：显示开始执行按钮 */}
        {/* STORYBOARD PENDING 状态且无 prompts 时不显示（入口是模式选择界面） */}
        {!isHidden && isAvailable && step.status === 'PENDING' && !(
          step.stepType === 'STORYBOARD' && !(step.outputData?.prompts?.length > 0)
        ) && (
          <div className="flex items-center gap-2">
            {step.stepType === 'FRAMEWORK' && onImport && (
              <button
                onClick={onImport}
                className="flex items-center gap-2 rounded-lg border border-stone-200 px-4 py-2.5 text-sm font-medium text-stone-600 transition hover:bg-stone-50"
              >
                <Upload className="h-4 w-4" />
                导入框架
              </button>
            )}
            <div className="relative inline-block">
              <button
                onClick={onExecute}
                disabled={isExecuting}
                className="flex items-center gap-2 rounded-lg bg-stone-900 px-5 py-2.5 text-sm font-medium text-white transition hover:bg-stone-800 disabled:opacity-50"
              >
                {isExecuting ? (
                  <>
                    <LoaderCircle className="h-4 w-4 animate-spin" />
                    生成中...
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4" />
                    开始执行
                  </>
                )}
              </button>
              <CostBadge cost={DEFAULT_GENERATE_COST} />
            </div>
          </div>
        )}

        {/* 处理中：显示中断按钮 */}
        {!isHidden && step.status === 'PROCESSING' && (
          <button
            onClick={onCancel}
            disabled={isExecuting && executing !== step.stepType}
            className="flex items-center gap-2 rounded-lg bg-red-50 px-5 py-2.5 text-sm font-medium text-red-600 transition hover:bg-red-100 disabled:opacity-50"
          >
            <Square className="h-4 w-4 fill-current" />
            中断
          </button>
        )}

        {/* 失败：显示重试按钮 */}
        {!isHidden && step.status === 'FAILED' && (
          <button
            onClick={onRetry}
            disabled={isExecuting}
            className="flex items-center gap-2 rounded-lg bg-red-600 px-5 py-2.5 text-sm font-medium text-white transition hover:bg-red-700 disabled:opacity-50"
          >
            {isExecuting ? (
              <>
                <LoaderCircle className="h-4 w-4 animate-spin" />
                重试中...
              </>
            ) : (
              '重试'
            )}
          </button>
        )}

        {/* 已完成：显示操作按钮 */}
        {isDone && (
          <>
            {step.stepType === 'FRAMEWORK' && onImport && !isHidden && (
              <button
                onClick={onImport}
                className="flex items-center gap-2 rounded-lg border border-stone-200 px-4 py-2 text-sm font-medium text-stone-600 transition hover:bg-stone-50"
              >
                <Upload className="h-4 w-4" />
                重新导入
              </button>
            )}
            {!isHidden && (
              <button
                onClick={onRetry}
                disabled={isExecuting}
                className="flex items-center gap-2 rounded-lg border border-stone-200 px-4 py-2 text-sm font-medium text-stone-600 transition hover:bg-stone-50 disabled:opacity-50"
              >
                <RefreshCw className="h-4 w-4" />
                重新生成
              </button>
            )}
            {step.stepType === 'FRAMEWORK' && onExportDoc && (
              <button
                onClick={onExportDoc}
                className="flex items-center gap-2 rounded-lg border border-stone-200 px-4 py-2 text-sm font-medium text-stone-600 transition hover:bg-stone-50"
              >
                <Download className="h-4 w-4" />
                导出文档
              </button>
            )}
            {!isHidden && (
              <button
                onClick={onNext}
                className="flex items-center gap-2 rounded-lg bg-stone-800 px-5 py-2.5 text-sm font-medium text-white transition hover:bg-stone-700"
              >
                下一步
                <ArrowRight className="h-4 w-4" />
              </button>
            )}
          </>
        )}
      </div>
    </div>
  )
}

function StepContent({
  step,
  project,
  executing,
  onExecute,
  onSelectStyle,
  onError,
  mutate,
  setToast,
  storyboardMode,
  setStoryboardMode,
  readOnly,
  selectedIdx,
  setSelectedIdx,
}: {
  step: any
  project: any
  executing: string | null
  onExecute: (stepType: string, body?: any) => void
  onSelectStyle: (styleId: string, styleRefUrl?: string) => void
  onError: (msg: string | null) => void
  mutate: () => Promise<any>
  setToast: (t: { kind: 'success' | 'error'; message: string } | null) => void
  storyboardMode?: 'reference' | 'keyframe'
  setStoryboardMode?: (mode: 'reference' | 'keyframe') => void
  readOnly?: boolean
  selectedIdx: number | null
  setSelectedIdx: (idx: number | null) => void
}) {
  const stepId = prismaTypeToStepId(step.stepType)
  const displayState = stepId ? getStepDisplayState(stepId, project) : null

  // 兼容旧项目/状态未同步：实际分镜已有首帧时也视为可用
  // （导入分镜的项目 stepStoryboardFirstframeDone 可能未同步，但 shots 里已有图）
  let isAvailable = displayState?.isAvailable ?? false
  if ((step.stepType === 'KEYFRAMES' || step.stepType === 'VIDEO_DIRECT') && !isAvailable) {
    const storyboardStep = project?.steps?.find((s: any) => s.stepType === 'STORYBOARD')
    const shots = storyboardStep?.outputData?.shots || []
    isAvailable = shots.some((shot: any) => Boolean(shot?.firstFrameUrl || shot?.referenceImageUrl))
  }

  switch (step.stepType) {
    case 'IDEATION':
      return (
        <IdeationPanel
          step={step}
          project={project}
          executing={executing}
          onExecute={onExecute}
          onError={onError}
          projectId={project.id}
          mutate={mutate}
          readOnly={readOnly}
          selectedIdx={selectedIdx}
          setSelectedIdx={setSelectedIdx}
        />
      )
    case 'FRAMEWORK':
      return <FrameworkPanel step={step} project={project} projectId={project.id} mutate={mutate} readOnly={readOnly} />
    case 'STYLE':
      return (
        <StylePanel
          step={step}
          project={project}
          executing={executing}
          onExecute={onExecute}
          onSelectStyle={onSelectStyle}
          onError={onError}
          mutate={mutate}
          setToast={setToast}
  readOnly={readOnly}
        />
      )
    case 'CHARACTER':
      return (
        <CharacterPanel
          step={step}
          project={project}
          projectId={project.id}
          executing={executing}
          onExecute={onExecute}
          onError={onError}
          mutate={mutate}
          setToast={setToast}
  readOnly={readOnly}
        />
      )
    case 'CONCEPT':
      return (
        <ConceptPanel
          step={step}
          project={project}
          projectId={project.id}
          executing={executing}
          onExecute={onExecute}
          onError={onError}
          mutate={mutate}
          setToast={setToast}
  readOnly={readOnly}
          onRetryReady={(fn) => { (window as any).__conceptRetry = fn }}
        />
      )
    case 'TRAILER':
      return (
        <TrailerPanel
          step={step}
          projectId={project.id}
          executing={executing}
          onExecute={onExecute}
          onError={onError}
          mutate={mutate}
          setToast={setToast}
  readOnly={readOnly}
          defaultAspectRatio={project.selectedAspectRatio}
        />
      )
    case 'STORYBOARD':
      return (
        <StoryboardPanel
          step={step}
          project={project}
          projectId={project.id}
          executing={executing}
          onExecute={onExecute}
          onError={onError}
          mutate={mutate}
          setToast={setToast}
          storyboardMode={storyboardMode}
          setStoryboardMode={setStoryboardMode}
          framework={project?.framework}
          readOnly={readOnly}
        />
      )
    case 'KEYFRAMES':
      return (
        <KeyframesPanel
          step={step}
          project={project}
          projectId={project.id}
          executing={executing}
          onExecute={onExecute}
          mutate={mutate}
          isAvailable={isAvailable}
          readOnly={readOnly}
        />
      )
    case 'VIDEO_DIRECT':
      return (
        <VideoDirectPanel
          step={step}
          projectId={project.id}
          executing={executing}
          onExecute={onExecute}
          // 必须传上面算好的 isAvailable（含 shots.some(firstFrameUrl) 兜底），
          // 直接用 displayState.isAvailable 会把兜底丢掉：
          // 导入分镜的项目会在 KEYFRAMES 已解锁、VIDEO_DIRECT 却显示锁定
          isAvailable={isAvailable}
          readOnly={readOnly}
        />
      )
    case 'VIDEO_RENDER':
    case 'CAMERA':
    case 'REVIEW':
      return <PlaceholderPanel step={step} readOnly={readOnly} />
    default:
      return <p className="text-stone-500">暂无内容</p>
  }
}

/* ============================================================
   各步骤面板
   ============================================================ */

const STORY_LENGTH_OPTIONS = [
  { key: 'sketch', label: '速写', range: '1-3分钟', acts: '1-2幕', shots: '10-20镜', desc: '极快节奏，单一场景/单一冲突' },
  { key: 'short', label: '短篇', range: '3-5分钟', acts: '2-3幕', shots: '20-40镜', desc: '紧凑叙事，一个完整人物弧线' },
  { key: 'medium', label: '中篇', range: '5-10分钟', acts: '3幕', shots: '40-80镜', desc: '标准起承转合，可展开副线' },
  { key: 'feature', label: '长片', range: '10-20分钟', acts: '3-4幕', shots: '80-150镜', desc: '复杂叙事，多场景切换' },
  { key: 'epic', label: '史诗', range: '20-30分钟', acts: '4-5幕', shots: '150-250镜', desc: '宏大格局，群像/多线' },
]

function ProjectTagSelector({
  value,
  onChange,
}: {
  value: string
  onChange: (key: string) => void
}) {
  const categories = ['用途', '风格', '调性']
  return (
    <div className="space-y-2.5">
      <div className="flex items-center gap-2">
        <span className="text-sm font-medium text-stone-700">项目标签</span>
        <span className="text-xs text-stone-400">可选，约束创意方向</span>
      </div>
      {categories.map(cat => {
        const opts = PROJECT_TAG_OPTIONS.filter(o => o.category === cat)
        return (
          <div key={cat} className="flex flex-wrap items-center gap-1.5">
            <span className="text-[11px] font-medium text-stone-400 w-8 shrink-0">{cat}</span>
            {opts.map(opt => (
              <button
                key={opt.key}
                onClick={() => onChange(value === opt.key ? '' : opt.key)}
                title={opt.desc}
                className={`rounded-full px-2.5 py-1 text-xs transition ${
                  value === opt.key
                    ? 'bg-amber-500 text-white'
                    : 'bg-stone-100 text-stone-500 hover:bg-stone-200'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        )
      })}
      {value && (
        <p className="text-[11px] text-amber-600">
          {PROJECT_TAG_OPTIONS.find(o => o.key === value)?.desc}
        </p>
      )}
    </div>
  )
}

function StoryLengthSelector({
  value,
  onChange,
}: {
  value: string
  onChange: (key: string) => void
}) {
  const [hovered, setHovered] = useState<string | null>(null)
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <span className="text-sm font-medium text-stone-700">故事分档</span>
        <span className="text-xs text-stone-400">AI 推荐，可手动调整</span>
      </div>
      <div className="flex flex-wrap gap-2">
        {STORY_LENGTH_OPTIONS.map((opt) => (
          <div key={opt.key} className="relative">
            <button
              onClick={() => onChange(opt.key)}
              onMouseEnter={() => setHovered(opt.key)}
              onMouseLeave={() => setHovered(null)}
              className={`rounded-full px-3 py-1.5 text-xs font-medium transition ${
                value === opt.key
                  ? 'bg-amber-500 text-white'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
              }`}
            >
              {opt.label} · {opt.range}
            </button>
            {hovered === opt.key && (
              <div className="absolute left-0 top-full z-20 mt-1 w-56 rounded-lg border border-stone-200 bg-white p-3 shadow-lg">
                <div className="text-xs font-medium text-stone-800">{opt.label} · {opt.range}</div>
                <div className="mt-1 text-xs text-stone-500">{opt.desc}</div>
                <div className="mt-1.5 flex gap-2 text-xs text-stone-400">
                  <span>推荐{opt.acts}</span>
                  <span>·</span>
                  <span>{opt.shots}</span>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

function IdeationPanel({
  step,
  project,
  executing,
  onExecute,
  onError,
  projectId,
  mutate,
  readOnly,
  selectedIdx,
  setSelectedIdx,
}: {
  step: any
  project: any
  executing: string | null
  onExecute: (stepType: string, body?: any) => void
  onError: (msg: string | null) => void
  projectId: string
  mutate: () => Promise<any>
  readOnly?: boolean
  selectedIdx: number | null
  setSelectedIdx: (idx: number | null) => void
}) {
  const [localDirections, setLocalDirections] = useState<any[]>(step.outputData?.directions || [])
  const [localStoryLength, setLocalStoryLength] = useState<string>(
    step.outputData?.storyLength || 'short'
  )
  const [projectTag, setProjectTag] = useState<string>(step.outputData?.projectTag || '')
  const [savingTag, setSavingTag] = useState(false)
  // 工作指令.txt（2026-06-02）：创意输入区域
  const [creativeInput, setCreativeInput] = useState<string>(project.rawIdea || '')
  const [savingInput, setSavingInput] = useState(false)
  const [deepenMode, setDeepenMode] = useState(false)
  const [iterations, setIterations] = useState<any[]>([])
  const [isLoadingIterations, setIsLoadingIterations] = useState(false)
  // 故事文件上传相关状态
  const [showUploadPanel, setShowUploadPanel] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [extracting, setExtracting] = useState(false)
  const [importing, setImporting] = useState(false)
  const [extractedFramework, setExtractedFramework] = useState<any>(null)
  const [uploadedFileName, setUploadedFileName] = useState<string>('')
  const [uploadError, setUploadError] = useState<string>('')
  const [showPreview, setShowPreview] = useState(false)
  const [contentType, setContentType] = useState<'story' | 'storyboard'>('story')
  const [storyboardShots, setStoryboardShots] = useState<any[] | null>(null)
  const [showStoryboardChoice, setShowStoryboardChoice] = useState(false)
  const [xlsxImageFiles, setXlsxImageFiles] = useState<File[]>([])
  const [xlsxImageCount, setXlsxImageCount] = useState(0)
  const [xlsxMatchedImageCount, setXlsxMatchedImageCount] = useState(0)
  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const lastSavedRef = useRef<any[]>(step.outputData?.directions || [])
  const storyLengthSaveRef = useRef<NodeJS.Timeout | null>(null)
  const tagSaveRef = useRef<NodeJS.Timeout | null>(null)
  const inputSaveRef = useRef<NodeJS.Timeout | null>(null)
  const isExecuting = executing === step.stepType
  const directions = step.outputData?.directions || []
  const errorMessage = step.errorMessage || ''

  // 获取创意迭代历史（用于 review 模式展示）
  useEffect(() => {
    if (step.status === 'COMPLETED') {
      setIsLoadingIterations(true)
      fetch(`/api/projects/${projectId}/steps/ideation/iterations`)
        .then((r) => r.json())
        .then((data) => {
          if (data.success) setIterations(data.iterations || [])
        })
        .catch((e) => console.error('[IDEATION] fetch iterations failed:', e))
        .finally(() => setIsLoadingIterations(false))
    }
  }, [step.status, projectId])

  useEffect(() => {
    const dirsJson = JSON.stringify(directions)
    const lastSavedJson = JSON.stringify(lastSavedRef.current)
    if (dirsJson !== lastSavedJson) {
      setLocalDirections(directions)
      lastSavedRef.current = directions
    }
  }, [directions])

  useEffect(() => {
    if (step.outputData?.storyLength && step.outputData.storyLength !== localStoryLength) {
      setLocalStoryLength(step.outputData.storyLength)
    }
  }, [step.outputData?.storyLength])

  useEffect(() => {
    if (step.outputData?.projectTag !== undefined && step.outputData.projectTag !== projectTag) {
      setProjectTag(step.outputData.projectTag || '')
    }
  }, [step.outputData?.projectTag])

  function handleUpdateDirection(index: number, field: 'title' | 'description', value: string) {
    const newDirections = [...localDirections]
    newDirections[index] = { ...newDirections[index], [field]: value }
    setLocalDirections(newDirections)
    if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current)
    saveTimeoutRef.current = setTimeout(() => {
      saveDirections(newDirections)
    }, 500)
  }

  async function saveDirections(newDirections: any[]) {
    try {
      const res = await fetch(`/api/projects/${projectId}/steps/ideation`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ directions: newDirections }),
      })
      if (!res.ok) throw new Error('保存失败')
      lastSavedRef.current = newDirections
      await mutate()
      console.log('[TEXT-EDIT-IDEATION] 保存 directions 成功, 数量:', newDirections.length)
    } catch (e: any) {
      console.error('[TEXT-EDIT-IDEATION] 保存失败:', e.message)
      setLocalDirections(lastSavedRef.current)
    }
  }

  function handleStoryLengthChange(key: string) {
    setLocalStoryLength(key)
    const opt = STORY_LENGTH_OPTIONS.find((o) => o.key === key)
    if (storyLengthSaveRef.current) clearTimeout(storyLengthSaveRef.current)
    storyLengthSaveRef.current = setTimeout(() => {
      saveStoryLength(key, opt)
    }, 300)
  }

  // 工作指令.txt（2026-06-02）：保存创意输入到 project.rawIdea
  async function saveCreativeInput(value: string) {
    try {
      setSavingInput(true)
      const res = await fetch(`/api/projects/${projectId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rawIdea: value.trim() }),
      })
      if (!res.ok) throw new Error('保存失败')
      await mutate()
      console.log('[IDEATION-INPUT] 保存创意输入成功')
    } catch (e: any) {
      console.error('[IDEATION-INPUT] 保存创意输入失败:', e.message)
    } finally {
      setSavingInput(false)
    }
  }

  function handleCreativeInputChange(value: string) {
    setCreativeInput(value)
    if (inputSaveRef.current) clearTimeout(inputSaveRef.current)
    inputSaveRef.current = setTimeout(() => {
      saveCreativeInput(value)
    }, 800)
  }

  // 故事文件上传处理
  async function handleFileUpload(file: File) {
    const allowedTypes = [
      'text/plain',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/pdf',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    ]
    if (!allowedTypes.includes(file.type) && !file.name.endsWith('.xlsx')) {
      setUploadError('不支持的文件格式，请上传 txt、docx、pdf 或 xlsx 文件')
      return
    }

    setUploading(true)
    setUploadError('')
    setUploadedFileName(file.name)
    setXlsxImageFiles([])

    try {
      // xlsx 文件：前端解析，避免 413（xlsx 含图片可能很大）
      if (file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.name.endsWith('.xlsx')) {
        const XLSX = await import('xlsx')
        const buffer = await file.arrayBuffer()
        const workbook = XLSX.read(buffer, { type: 'array' })
        const sheetName = workbook.SheetNames[0]
        const sheet = workbook.Sheets[sheetName]
        const data = XLSX.utils.sheet_to_json(sheet, { header: 1 }) as any[][]

        // 自动检测表头行：找包含最多关键词的行（评分法）
        const STORYBOARD_KEYWORDS = ['镜号', '镜头号', '镜头', '编号', 'shot', 'shot_id', 'id', '序号', '分镜号']
        const HEADER_BONUS_KW = ['时长', 'duration', '描述', 'description', '景别', '运镜', 'camera', '旁白', 'narration', '画面', '镜头画面', '章节']
        let headerRow = -1
        let bestHeaderScore = 0
        for (let i = 0; i < Math.min(30, data.length); i++) {
          const row = data[i]
          if (!row) continue
          let score = 0
          for (const cell of row) {
            const v = String(cell || '').toLowerCase().trim()
            if (STORYBOARD_KEYWORDS.some(k => v.includes(k))) score += 3
            if (HEADER_BONUS_KW.some(k => v.includes(k))) score += 1
          }
          if (score > bestHeaderScore) { bestHeaderScore = score; headerRow = i }
        }
        if (headerRow < 0) headerRow = 2 // 默认第3行

        // 检测 shotId 列
        const headerRowData = data[headerRow] || []
        let shotIdCol = -1
        for (let c = 0; c < headerRowData.length; c++) {
          const v = String(headerRowData[c] || '').toLowerCase().trim()
          if (STORYBOARD_KEYWORDS.some(k => v.includes(k))) { shotIdCol = c; break }
        }
        // 模式检测：如果关键词没找到，找第一列大多是数字编号的列
        if (shotIdCol < 0) {
          for (let c = 0; c < Math.min(10, (data[headerRow + 1] || []).length); c++) {
            let nums = 0
            for (let r = headerRow + 1; r < Math.min(headerRow + 11, data.length); r++) {
              if (/^\d{1,4}$/.test(String((data[r] || [])[c] || '').trim())) nums++
            }
            if (nums >= 2) { shotIdCol = c; break }
          }
        }

        // 检测其他列
        const COL_KEYWORDS: Record<string, string[]> = {
          timecode: ['起止时间', '时间码', '时间', 'timecode'],
          duration: ['时长', 'duration', '秒'],
          narration: ['旁白', '台词', '台词/旁白', 'narration', 'dialogue', '对应歌词', '对应音效'],
          cameraMove: ['运镜', '镜头运动', 'camera', '景别', '机位'],
          description: ['画面描述', '描述', '画面', 'description', '镜头画面', '镜头画面描述'],
          visualDetail: ['视觉细节', '细节', '备注', 'visual', 'detail', 'note', 'AI镜头画面'],
          transition: ['剪辑点', '转场', 'transition', 'cut', '章节'],
        }
        const colMap: Record<string, number> = {}
        for (let c = 0; c < headerRowData.length; c++) {
          const v = String(headerRowData[c] || '').toLowerCase().trim()
          for (const [field, keywords] of Object.entries(COL_KEYWORDS)) {
            if (!(field in colMap) && keywords.some(k => v.includes(k))) colMap[field] = c
          }
        }

        // 时间码解析
        function parseTc(tc: string): number {
          if (!tc) return 5
          const m = tc.match(/(\d+):(\d+(?:\.\d+)?)[^\d]*(\d+):(\d+(?:\.\d+)?)/)
          if (m) return (parseInt(m[3]) * 60 + parseFloat(m[4])) - (parseInt(m[1]) * 60 + parseFloat(m[2]))
          const n = parseFloat(tc)
          return isNaN(n) ? 5 : n
        }

        // 确定数据范围
        const dataStart = headerRow + 1
        let dataEnd = dataStart
        let emptyCount = 0
        for (let r = dataStart; r < data.length; r++) {
          const row = data[r]
          const shotVal = shotIdCol >= 0 ? String((row || [])[shotIdCol] || '').trim() : ''
          const hasContent = shotVal ? /^\d{1,4}$/.test(shotVal) : (row || []).some((c: any) => c != null && String(c).trim() !== '')
          if (hasContent) { dataEnd = r; emptyCount = 0 } else { emptyCount++; if (emptyCount >= 3) break }
        }

        // 解析分镜数据
        const shots: any[] = []
        for (let r = dataStart; r <= dataEnd; r++) {
          const row = data[r] || []
          let shotId = shotIdCol >= 0 ? String(row[shotIdCol] || '').trim() : ''
          if (shotIdCol >= 0 && (!shotId || shotId.length > 10 || shotId.includes('分镜') || shotId.includes('表'))) continue
          if (shotIdCol < 0) shotId = String(shots.length + 1).padStart(3, '0')

          const description = colMap.description != null ? String(row[colMap.description] || '').trim() : ''
          const cameraMove = colMap.cameraMove != null ? String(row[colMap.cameraMove] || '').trim() : ''
          const narration = colMap.narration != null ? String(row[colMap.narration] || '').trim() : ''
          const timecode = colMap.timecode != null ? String(row[colMap.timecode] || '').trim() : ''
          const duration = colMap.duration != null ? parseTc(String(row[colMap.duration] || '')) : 5
          const visualDetail = colMap.visualDetail != null ? String(row[colMap.visualDetail] || '').trim() : ''
          const transition = colMap.transition != null ? String(row[colMap.transition] || '').trim() : ''

          if (description || cameraMove || narration) {
            shots.push({ shotId, timecode, duration, narration, cameraMove, description: description || cameraMove || narration, visualDetail, transition })
          }
        }

        if (shots.length === 0) {
          setUploadError('未在 xlsx 中检测到分镜数据')
          return
        }

        setContentType('storyboard')
        setStoryboardShots(shots)
        setXlsxImageCount(0)
        setXlsxMatchedImageCount(0)

        // 用 fflate 解压 xlsx（本质是 zip），提取嵌入图片
        try {
          const fileSizeMB = buffer.byteLength / (1024 * 1024)
          console.log(`[XLSX-PARSE] 开始解压 xlsx，文件大小: ${fileSizeMB.toFixed(1)}MB`)
          const { unzipSync, strFromU8 } = await import('fflate')
          const zipData = unzipSync(new Uint8Array(buffer))
          console.log('[XLSX-PARSE] 解压完成，条目数:', Object.keys(zipData).length)

          // 1. 找到所有媒体文件（xl/media/image1.png 等）
          const mediaFiles = new Map<string, Uint8Array>()
          for (const [path, d] of Object.entries(zipData)) {
            if (path.startsWith('xl/media/image')) {
              mediaFiles.set(path, d)
            }
          }
          console.log('[XLSX-PARSE] 媒体文件数:', mediaFiles.size)
          setXlsxImageCount(mediaFiles.size)

          if (mediaFiles.size === 0) {
            console.log('[XLSX-PARSE] xlsx 中没有嵌入图片，跳过图片提取')
          } else {
            // 2. 找到 drawing 文件（直接在 zip 中搜索，避免相对路径解析问题）
            const drawingFiles = Object.keys(zipData).filter(k => /^xl\/drawings\/drawing\d+\.xml$/.test(k))
            console.log('[XLSX-PARSE] drawing 文件:', drawingFiles)
            const drawingPath = drawingFiles[0] || null

            if (!drawingPath) {
              console.warn('[XLSX-PARSE] 未找到 drawing 文件，可用文件:', Object.keys(zipData).filter(k => k.includes('drawing') || k.includes('sheet')))
            } else {
              // 3. 解析 drawing rels，建立 rId → 图片文件路径的映射
              const drawingRelsPath = drawingPath.replace(/drawing(\d+)\.xml$/, '_rels/drawing$1.xml.rels')
              const drawingRels = zipData[drawingRelsPath] ? strFromU8(zipData[drawingRelsPath]) : ''
              const ridToMedia = new Map<string, string>()
              // 支持 Id 在 Target 前后两种顺序
              const ridRegex = /(?:Id="([^"]+)"[^>]*Target="([^"]+)"|Target="([^"]+)"[^>]*Id="([^"]+)")/g
              let ridMatch
              while ((ridMatch = ridRegex.exec(drawingRels)) !== null) {
                const rid = ridMatch[1] || ridMatch[4]
                let target = ridMatch[2] || ridMatch[3]
                // 处理绝对路径（/xl/media/image.jpg）和相对路径（../media/image1.png）
                if (target.startsWith('/')) {
                  target = target.substring(1) // 去掉开头的 /
                } else {
                  target = 'xl/' + target.replace(/^\.\.\//, '')
                }
                ridToMedia.set(rid, target)
              }
              console.log('[XLSX-PARSE] ridToMedia 条目数:', ridToMedia.size)

              // 4. 解析 drawing XML，提取每个图片的位置和关联的 rId
              const drawingXml = strFromU8(zipData[drawingPath])
              // 支持有/无 xdr: 前缀的两种格式
              const anchorRegex = /<(?:xdr:)?(?:one|two|absolute)CellAnchor[^>]*>([\s\S]*?)<\/(?:xdr:)?(?:one|two|absolute)CellAnchor>/g
              const imagePositions: Array<{ row: number; col: number; mediaPath: string }> = []
              let anchorMatch
              while ((anchorMatch = anchorRegex.exec(drawingXml)) !== null) {
                const anchor = anchorMatch[1]

                // 提取 from row/col（支持有/无前缀）
                const fromMatch = anchor.match(/<(?:xdr:)?from>([\s\S]*?)<\/(?:xdr:)?from>/)
                let col = -1, row = -1
                if (fromMatch) {
                  const fromXml = fromMatch[1]
                  const colMatch = fromXml.match(/<(?:xdr:)?col>(\d+)<\/(?:xdr:)?col>/)
                  const rowMatch = fromXml.match(/<(?:xdr:)?row>(\d+)<\/(?:xdr:)?row>/)
                  if (colMatch) col = parseInt(colMatch[1])
                  if (rowMatch) row = parseInt(rowMatch[1])
                }
                // absoluteAnchor 用 pos 推算
                if (row < 0 || col < 0) {
                  const posMatch = anchor.match(/<(?:xdr:)?pos[^>]*x="(\d+)"[^>]*y="(\d+)"/)
                  if (posMatch) {
                    col = Math.floor(parseInt(posMatch[1]) / 576000)
                    row = Math.floor(parseInt(posMatch[2]) / 190500)
                  }
                }
                if (row < 0 || col < 0) continue

                // 提取 rId（支持有/无命名空间前缀的 blip）
                const blipMatch = anchor.match(/<a:blip[^>]*r:embed="([^"]+)"/)
                if (!blipMatch) continue
                const rid = blipMatch[1]
                const mediaPath = ridToMedia.get(rid)
                if (!mediaPath || !mediaFiles.has(mediaPath)) continue
                imagePositions.push({ row, col, mediaPath })
              }
              console.log('[XLSX-PARSE] imagePositions:', imagePositions.length)

              // 5. 匹配图片到分镜
              const imageFiles: File[] = []
              for (const pos of imagePositions) {
                const imgRow = pos.row + 1
                if (imgRow < dataStart) continue

                let matchedShotId: string | null = null
                if (shotIdCol >= 0) {
                  const cellVal = String((data[imgRow - 1] || [])[shotIdCol] || '').trim()
                  if (cellVal && /^\d{1,4}$/.test(cellVal)) matchedShotId = cellVal
                  if (!matchedShotId) {
                    for (let up = 1; up <= 5; up++) {
                      const checkRow = imgRow - up
                      if (checkRow < dataStart) break
                      const upVal = String((data[checkRow - 1] || [])[shotIdCol] || '').trim()
                      if (upVal && /^\d{1,4}$/.test(upVal)) { matchedShotId = upVal; break }
                    }
                  }
                } else {
                  const idx = imgRow - dataStart
                  if (idx >= 0 && idx < shots.length) matchedShotId = shots[idx].shotId
                }
                if (!matchedShotId) continue

                const imgData = mediaFiles.get(pos.mediaPath)
                if (!imgData) continue

                let mime = 'image/png', ext = 'png'
                if (imgData[0] === 0xFF && imgData[1] === 0xD8) { mime = 'image/jpeg'; ext = 'jpg' }
                else if (imgData[0] === 0x89 && imgData[1] === 0x50) { mime = 'image/png'; ext = 'png' }
                else if (imgData[0] === 0x47 && imgData[1] === 0x49) { mime = 'image/gif'; ext = 'gif' }

                const existingCount = imageFiles.filter(f => f.name.startsWith(`${matchedShotId}_`)).length
                const imgBlob = new Blob([imgData as unknown as BlobPart], { type: mime })
                imageFiles.push(new File([imgBlob], `${matchedShotId}_${existingCount}.${ext}`, { type: mime }))
              }

              setXlsxImageFiles(imageFiles)
              setXlsxMatchedImageCount(imageFiles.length)
              console.log(`[XLSX-PARSE] 最终结果: ${shots.length} 个分镜, ${mediaFiles.size} 张原始图片, ${imageFiles.length} 张匹配图片`)
            }
          }
        } catch (e: any) {
          console.error('[XLSX-PARSE] fflate 图片解析异常:', e?.message, e?.stack)
          setXlsxImageCount(0)
          setXlsxMatchedImageCount(0)
        }

        setShowStoryboardChoice(true)
        await mutate()
        return
      }

      // 非 xlsx 文件：走原有服务端解析流程
      const formData = new FormData()
      formData.append('file', file)

      const uploadRes = await fetch(`/api/projects/${projectId}/upload-story`, {
        method: 'POST',
        body: formData,
      })
      const uploadData = await uploadRes.json()

      if (!uploadRes.ok || uploadData.error) {
        if (uploadData.error === 'CONTENT_TOO_SHORT') {
          setUploadError(uploadData.message)
          return
        }
        throw new Error(uploadData.message || '上传失败')
      }

      // 检查是否是分镜表
      if (uploadData.contentType === 'storyboard' && uploadData.storyboardShots) {
        setContentType('storyboard')
        setStoryboardShots(uploadData.storyboardShots)
        setShowStoryboardChoice(true)
        await mutate()
        return
      }

      // 普通故事，开始提取框架
      setContentType('story')
      setExtracting(true)
      const extractRes = await fetch(`/api/projects/${projectId}/extract-framework`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      })
      const extractData = await extractRes.json()

      if (!extractRes.ok || extractData.error) {
        throw new Error(extractData.message || '提取失败')
      }

      setExtractedFramework(extractData.data)
      setShowPreview(true)
      await mutate()
    } catch (e: any) {
      setUploadError(e.message || '处理失败')
    } finally {
      setUploading(false)
      setExtracting(false)
    }
  }

  // 导入提取的框架
  async function handleImportFramework() {
    if (!extractedFramework?.framework) return

    setImporting(true)
    try {
      const res = await fetch(`/api/projects/${projectId}/import-framework`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          framework: extractedFramework.framework,
          storyLength: extractedFramework.framework.storyLength,
        }),
      })
      const data = await res.json()

      if (!res.ok || data.error) {
        throw new Error(data.message || '导入失败')
      }

      setShowPreview(false)
      setShowUploadPanel(false)
      await mutate()
    } catch (e: any) {
      setUploadError(e.message || '导入失败')
    } finally {
      setImporting(false)
    }
  }

  // 导入分镜表
  async function handleImportStoryboard(mode: 'ai_complete' | 'skip_framework') {
    if (!storyboardShots || storyboardShots.length === 0) return

    setImporting(true)
    try {
      // 先上传图片（逐张），收集 asset 引用
      const firstFrameMap: Record<string, { url: string; assetId: string }> = {}
      if (xlsxImageFiles.length > 0) {
        console.log(`[IMPORT] 开始上传 ${xlsxImageFiles.length} 张图片`)
        for (let i = 0; i < xlsxImageFiles.length; i++) {
          const imgFile = xlsxImageFiles[i]
          const fd = new FormData()
          fd.append('file', imgFile)
          // 文件名格式: shotId_index.ext
          const nameMatch = imgFile.name.match(/^(.+?)_(\d+)\.\w+$/)
          const shotId = nameMatch ? nameMatch[1] : imgFile.name
          const imageIndex = nameMatch ? nameMatch[2] : '0'
          fd.append('shotId', shotId)
          fd.append('imageIndex', imageIndex)

          const imgRes = await fetch(`/api/projects/${projectId}/upload-storyboard-image`, {
            method: 'POST',
            body: fd,
          })
          if (imgRes.ok) {
            const imgData = await imgRes.json()
            if (imgData.url && imgData.shotId && !firstFrameMap[imgData.shotId]) {
              firstFrameMap[imgData.shotId] = { url: imgData.url, assetId: imgData.assetId }
            }
          }
          console.log(`[IMPORT] 图片 ${i + 1}/${xlsxImageFiles.length} 上传${imgRes.ok ? '成功' : '失败'}`)
        }
        console.log(`[IMPORT] 图片上传完成，${Object.keys(firstFrameMap).length} 个分镜有首帧`)
      }

      // 调用原 import-storyboard API（带 firstFrameMap）
      const res = await fetch(`/api/projects/${projectId}/import-storyboard`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          shots: storyboardShots,
          mode,
          firstFrameMap: Object.keys(firstFrameMap).length > 0 ? firstFrameMap : undefined,
        }),
      })
      const data = await res.json()

      if (!res.ok || data.error) {
        throw new Error(data.message || '导入失败')
      }

      setShowStoryboardChoice(false)
      setShowUploadPanel(false)
      setXlsxImageFiles([])
      setXlsxImageCount(0)
      setXlsxMatchedImageCount(0)
      await mutate()
    } catch (e: any) {
      setUploadError(e.message || '导入失败')
    } finally {
      setImporting(false)
    }
  }

  // 文件选择处理
  function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (file) {
      handleFileUpload(file)
    }
  }

  async function saveStoryLength(key: string, opt?: typeof STORY_LENGTH_OPTIONS[0]) {
    try {
      const res = await fetch(`/api/projects/${projectId}/steps/ideation`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          storyLength: key,
          storyLengthLabel: opt ? `${opt.label} · ${opt.range}` : undefined,
        }),
      })
      if (!res.ok) throw new Error('保存失败')
      await mutate()
      console.log('[TEXT-EDIT-IDEATION] 保存 storyLength 成功:', key)
    } catch (e: any) {
      console.error('[TEXT-EDIT-IDEATION] 保存 storyLength 失败:', e.message)
    }
  }

  async function saveProjectTag(key: string) {
    try {
      setSavingTag(true)
      const res = await fetch(`/api/projects/${projectId}/steps/ideation`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectTag: key }),
      })
      if (!res.ok) throw new Error('保存失败')
      await mutate()
      console.log('[TEXT-EDIT-IDEATION] 保存 projectTag 成功:', key)
    } catch (e: any) {
      console.error('[TEXT-EDIT-IDEATION] 保存 projectTag 失败:', e.message)
      setProjectTag(step.outputData?.projectTag || '')
    } finally {
      setSavingTag(false)
    }
  }

  function handleProjectTagChange(key: string) {
    setProjectTag(key)
    if (tagSaveRef.current) clearTimeout(tagSaveRef.current)
    tagSaveRef.current = setTimeout(() => {
      saveProjectTag(key)
    }, 300)
  }

  async function handleResetIdeation() {
    if (!confirm('确定要重新进行创意扩散吗？这将清除当前的所有创意方向。')) return
    try {
      const res = await fetch(`/api/projects/${projectId}/steps/ideation`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ force: true }),
      })
      const data = await res.json()
      if (!res.ok || data.error) {
        throw new Error(data.message || '重置失败')
      }
      await mutate()
      setSelectedIdx(null)
      setIterations([])
    } catch (e: any) {
      onError(e.message || '重置失败')
    }
  }

  const displayDirections = step.status === 'COMPLETED' ? localDirections : directions

  // 提取结果预览/编辑模态框（全局渲染，不受 step.status 影响）
  const previewModal = showPreview && extractedFramework && (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="max-h-[90vh] w-full max-w-4xl overflow-y-auto rounded-xl bg-white shadow-2xl">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-stone-200 bg-white px-6 py-4">
          <div>
            <h2 className="text-lg font-semibold text-stone-800">故事框架预览</h2>
            <p className="text-sm text-stone-500">
              已从文件「{uploadedFileName}」提取框架，请检查并编辑
            </p>
          </div>
          <button
            onClick={() => setShowPreview(false)}
            className="rounded-lg p-2 text-stone-400 hover:bg-stone-100 hover:text-stone-600"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-6 p-6">
          {/* 缺失字段提示 */}
          {extractedFramework.missingFields?.length > 0 && (
            <div className="rounded-lg border border-amber-200 bg-amber-50 p-4">
              <p className="text-sm font-medium text-amber-800">以下信息在故事中缺失，已自动补充：</p>
              <ul className="mt-2 list-inside list-disc text-sm text-amber-700">
                {extractedFramework.missingFields.map((field: string, idx: number) => (
                  <li key={idx}>{field}</li>
                ))}
              </ul>
            </div>
          )}

          {/* 框架内容预览 */}
          <FrameworkPreview framework={extractedFramework.framework} />

          {/* 操作按钮 */}
          <div className="flex justify-end gap-3 border-t border-stone-200 pt-4">
            <button
              onClick={() => setShowPreview(false)}
              className="rounded-lg border border-stone-200 px-4 py-2.5 text-sm font-medium text-stone-600 hover:bg-stone-50"
            >
              取消
            </button>
            <button
              onClick={handleImportFramework}
              disabled={importing}
              className="flex items-center gap-2 rounded-lg bg-stone-900 px-6 py-2.5 text-sm font-medium text-white hover:bg-stone-800 disabled:opacity-50"
            >
              {importing ? (
                <>
                  <LoaderCircle className="h-4 w-4 animate-spin" />
                  导入中...
                </>
              ) : (
                <>
                  <Check className="h-4 w-4" />
                  确认导入
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  )

  // 分镜表导入选择模态框
  const storyboardChoiceModal = showStoryboardChoice && storyboardShots && (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-xl bg-white shadow-2xl">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-stone-200 bg-white px-6 py-4">
          <div>
            <h2 className="text-lg font-semibold text-stone-800">检测到分镜表</h2>
            <p className="text-sm text-stone-500">
              已从文件「{uploadedFileName}」中识别出 {storyboardShots.length} 个镜头
            </p>
          </div>
          <button
            onClick={() => { setShowStoryboardChoice(false); setXlsxImageCount(0); setXlsxMatchedImageCount(0) }}
            className="rounded-lg p-2 text-stone-400 hover:bg-stone-100 hover:text-stone-600"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-6 p-6">
          {/* 图片检测状态 */}
          {xlsxImageCount > 0 ? (
            <div className={`rounded-lg border px-4 py-3 ${xlsxMatchedImageCount > 0 ? 'border-green-200 bg-green-50' : 'border-amber-200 bg-amber-50'}`}>
              <p className={`text-sm ${xlsxMatchedImageCount > 0 ? 'text-green-700' : 'text-amber-700'}`}>
                {xlsxMatchedImageCount > 0
                  ? `检测到 ${xlsxImageCount} 张嵌入图片，已匹配到 ${xlsxMatchedImageCount} 个分镜作为首帧`
                  : `检测到 ${xlsxImageCount} 张嵌入图片，但未能匹配到分镜（图片可能不在数据行中）`
                }
              </p>
            </div>
          ) : (
            <div className="rounded-lg border border-stone-200 bg-stone-50 px-4 py-3">
              <p className="text-sm text-stone-500">未检测到嵌入图片，将只导入文本分镜数据</p>
            </div>
          )}

          {/* 分镜预览 */}
          <div className="rounded-lg border border-stone-200 p-4">
            <h3 className="mb-3 text-sm font-semibold text-stone-700">分镜预览</h3>
            <div className="max-h-60 overflow-y-auto space-y-2">
              {storyboardShots.slice(0, 10).map((shot: any, idx: number) => (
                <div key={idx} className="rounded-md bg-stone-50 p-2 text-xs">
                  <span className="font-medium text-stone-800">镜头 {shot.shotId}</span>
                  <span className="mx-2 text-stone-400">|</span>
                  <span className="text-stone-600">{shot.description?.slice(0, 60)}...</span>
                </div>
              ))}
              {storyboardShots.length > 10 && (
                <p className="text-xs text-stone-400">...还有 {storyboardShots.length - 10} 个镜头</p>
              )}
            </div>
          </div>

          {/* 选择按钮 */}
          <div className="space-y-3">
            <p className="text-sm font-medium text-stone-700">请选择导入方式：</p>
            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => handleImportStoryboard('ai_complete')}
                disabled={importing}
                className="flex flex-col items-center gap-2 rounded-lg border-2 border-stone-200 p-4 transition hover:border-amber-400 hover:bg-amber-50 disabled:opacity-50"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-100">
                  <Sparkles className="h-5 w-5 text-amber-600" />
                </div>
                <div className="text-center">
                  <p className="text-sm font-medium text-stone-800">AI 补完框架</p>
                  <p className="text-xs text-stone-500">AI 从分镜表提取框架、生成风格和人物提示词，你来生图</p>
                </div>
              </button>
              <button
                onClick={() => handleImportStoryboard('skip_framework')}
                disabled={importing}
                className="flex flex-col items-center gap-2 rounded-lg border-2 border-stone-200 p-4 transition hover:border-blue-400 hover:bg-blue-50 disabled:opacity-50"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-100">
                  <FileSpreadsheet className="h-5 w-5 text-blue-600" />
                </div>
                <div className="text-center">
                  <p className="text-sm font-medium text-stone-800">跳过框架，直接生图</p>
                  <p className="text-xs text-stone-500">隐藏创意扩散→宣传片，直接进入分镜生图</p>
                </div>
              </button>
            </div>
          </div>

          {importing && (
            <div className="flex items-center justify-center gap-2 py-2 text-sm text-stone-500">
              <LoaderCircle className="h-4 w-4 animate-spin" />
              导入中...
            </div>
          )}
        </div>
      </div>
    </div>
  )

  if (step.status === 'PENDING') {
    const canGenerate = creativeInput.trim().length >= 10
    const isImportedFramework = project.frameworkSource === 'imported' || project.frameworkSource === 'mixed'
    return (
      <div className="space-y-6">
        {/* 项目标题锚点 */}
        <div className="rounded-lg border border-stone-200 bg-stone-50/50 px-4 py-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-stone-400">项目标题</span>
            <span className="text-sm font-semibold text-stone-700">{project.title}</span>
          </div>
        </div>

        {/* 已有故事？上传文件！ */}
        {!isImportedFramework && (
          <div className="rounded-lg border border-dashed border-amber-300 bg-amber-50/50 px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-100">
                  <Upload className="h-5 w-5 text-amber-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-stone-800">已有故事？上传文件！</p>
                  <p className="text-xs text-stone-500">支持 txt、docx、pdf、xlsx 格式（xlsx 可导入分镜表）</p>
                </div>
              </div>
              <label className="cursor-pointer rounded-lg bg-amber-500 px-4 py-2 text-sm font-medium text-white transition hover:bg-amber-600">
                {uploading || extracting ? (
                  <span className="flex items-center gap-2">
                    <LoaderCircle className="h-4 w-4 animate-spin" />
                    {uploading ? '上传中...' : '提取中...'}
                  </span>
                ) : (
                  '选择文件'
                )}
                <input
                  type="file"
                  accept=".txt,.docx,.pdf,.xlsx"
                  onChange={handleFileSelect}
                  className="hidden"
                  disabled={uploading || extracting}
                />
              </label>
            </div>
            {uploadError && (
              <div className="mt-3 rounded-md bg-red-50 p-3 text-sm text-red-700">
                {uploadError}
                {uploadError.includes('过短') && (
                  <div className="mt-2 flex gap-2">
                    <button
                      onClick={() => {
                        setUploadError('')
                        setShowUploadPanel(false)
                      }}
                      className="rounded-md bg-stone-900 px-3 py-1.5 text-xs text-white hover:bg-stone-800"
                    >
                      继续手动输入
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* 框架导入兼容：显示导入来源 */}
        {isImportedFramework && (
          <div className="rounded-lg border border-green-200 bg-green-50 px-4 py-3">
            <div className="flex items-center gap-2">
              <Check className="h-4 w-4 text-green-600" />
              <span className="text-sm text-green-700">
                已从文件导入框架：{project.importedFileName || '未知文件'}
              </span>
            </div>
            <p className="mt-1 text-xs text-green-600">
              框架搭建步骤已完成。你可以直接开始后续步骤，或重新进行创意扩散以更换方向。
            </p>
          </div>
        )}

        {/* 创意输入区域 */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-stone-700">
            {isImportedFramework ? '更换创意方向（可选）' : '输入你的创意方向'}
          </label>
          <div className="relative">
            <textarea
              value={creativeInput}
              onChange={(e) => handleCreativeInputChange(e.target.value)}
              placeholder={isImportedFramework
                ? '如需更换方向，请输入新的创意描述...'
                : '描述你的故事核心、世界观或情绪基调，例如：一个被遗弃的机器人在雨夜城市中收集人类情感残影...'}
              maxLength={1000}
              className="min-h-[160px] w-full resize-y rounded-lg border border-stone-200 bg-white p-4 text-sm leading-relaxed text-stone-800 placeholder:text-stone-300 focus:border-amber-400 focus:outline-none focus:ring-2 focus:ring-amber-100"
            />
            <div className="absolute bottom-3 right-3 text-xs text-stone-400">
              {creativeInput.length} / 1000
              {savingInput && <span className="ml-2 text-amber-500">保存中...</span>}
            </div>
          </div>
          {creativeInput.length > 0 && creativeInput.length < 10 && (
            <p className="text-xs text-amber-600">至少需要 10 个字符才能生成</p>
          )}
        </div>

        <ProjectTagSelector value={projectTag} onChange={handleProjectTagChange} />

        <div className="flex justify-center">
          <div className="relative inline-block">
            <button
              onClick={() => onExecute('IDEATION', { creativeInput: creativeInput.trim(), projectTag: projectTag || undefined })}
              disabled={isExecuting || !canGenerate}
              className="flex items-center gap-2 rounded-lg bg-stone-900 px-6 py-3 text-sm font-medium text-white transition hover:bg-stone-800 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {isExecuting ? (
                <>
                  <LoaderCircle className="h-4 w-4 animate-spin" />
                  生成中...
                </>
              ) : (
                <>
                  <Play className="h-4 w-4" />
                  {isImportedFramework ? '重新创意扩散' : '生成创意方向'}
                </>
              )}
            </button>
            <CostBadge cost={DEFAULT_GENERATE_COST} />
          </div>
        </div>
        {previewModal}
        {storyboardChoiceModal}
      </div>
    )
  }

  if (step.status === 'PROCESSING') {
    return (
      <>
        <ProcessingBlock message="正在扩散创意方向..." />
        {previewModal}
        {storyboardChoiceModal}
      </>
    )
  }

  if (step.status === 'COMPLETED' && directions.length > 0) {
    const selectedDirection = typeof selectedIdx === 'number' ? displayDirections[selectedIdx] : null

    // 深化模式
    if (deepenMode && selectedDirection) {
      return (
        <IdeationDeepenPanel
          projectId={projectId}
          originalInput={project.rawIdea || creativeInput}
          currentCreative={selectedDirection.description || ''}
          directionTitle={selectedDirection.title || ''}
          directionDescription={selectedDirection.description || ''}
          keywords={selectedDirection.keywords || []}
          onGoToFramework={() => onExecute('FRAMEWORK', { directionIndex: selectedIdx })}
          onBack={() => setDeepenMode(false)}
        />
      )
    }

    return (
      <div className="space-y-6">
        {/* Review 模式横幅 */}
        <div className="flex items-center justify-between rounded-lg border border-stone-200 bg-stone-50/50 px-4 py-3">
          <div className="flex items-center gap-2">
            <Check className="h-4 w-4 text-green-600" />
            <span className="text-sm text-stone-600">创意扩散已完成</span>
          </div>
          <button
            onClick={handleResetIdeation}
            className="flex items-center gap-1.5 rounded-md border border-stone-200 px-3 py-1.5 text-xs font-medium text-stone-600 transition hover:bg-stone-100"
          >
            <RefreshCw className="h-3 w-3" />
            重新创意扩散
          </button>
        </div>

        <StoryLengthSelector value={localStoryLength} onChange={handleStoryLengthChange} />
        <ProjectTagSelector value={projectTag} onChange={handleProjectTagChange} />
        <p className="text-sm text-stone-600">已生成的创意方向（点击卡片选择）：</p>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          {displayDirections.map((d: any, idx: number) => (
            <div
              key={idx}
              onClick={() => setSelectedIdx(idx)}
              className={`cursor-pointer rounded-lg border-2 p-4 transition ${
                selectedIdx === idx
                  ? 'border-amber-500 bg-amber-50/50'
                  : 'border-stone-200 bg-white hover:border-stone-400'
              }`}
            >
              <h4 className="font-semibold text-stone-800">{d.title || '未命名方向'}</h4>
              <p className="mt-2 text-sm leading-relaxed text-stone-600">{d.description || ''}</p>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {d.keywords?.map((k: string) => (
                  <span
                    key={k}
                    className="rounded-md bg-stone-100 px-2 py-0.5 text-xs text-stone-600"
                  >
                    {k}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
        {selectedIdx !== null && !readOnly && (
          <div className="flex justify-center gap-3">
            <button
              onClick={() => setDeepenMode(true)}
              className="flex items-center gap-2 rounded-lg border border-stone-200 px-5 py-2.5 text-sm font-medium text-stone-600 transition hover:bg-stone-50"
            >
              <Sparkles className="h-4 w-4" />
              创意深化
            </button>
            <div className="relative inline-block">
              <button
                onClick={() => onExecute('FRAMEWORK', { directionIndex: selectedIdx })}
                disabled={isExecuting}
                className="flex items-center gap-2 rounded-lg bg-amber-600 px-6 py-3 text-sm font-medium text-white transition hover:bg-amber-700 disabled:opacity-50"
              >
                {isExecuting ? (
                  <>
                    <LoaderCircle className="h-4 w-4 animate-spin" />
                    生成中...
                  </>
                ) : (
                  <>
                    用此创意进入下一步
                    <ArrowRight className="h-4 w-4" />
                  </>
                )}
              </button>
              <CostBadge cost={DEFAULT_GENERATE_COST} />
            </div>
          </div>
        )}

        {/* 迭代历史版本 */}
        {iterations.length > 0 && (
          <div className="rounded-lg border border-stone-200 bg-stone-50/50 p-4">
            <div className="mb-3 flex items-center gap-2">
              <Clock className="h-4 w-4 text-stone-400" />
              <span className="text-sm font-medium text-stone-600">深化历史版本</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {iterations.map((iter: any) => (
                <div
                  key={iter.id}
                  className={`rounded-md px-3 py-1.5 text-xs font-medium ${
                    iter.isCurrent
                      ? 'bg-amber-100 text-amber-700 ring-1 ring-amber-300'
                      : 'bg-white text-stone-600 ring-1 ring-stone-200'
                  }`}
                >
                  版本{iter.versionNumber}
                  {typeof iter.qualityScore === 'number' && (
                    <span className="ml-1 text-[10px] opacity-70">({iter.qualityScore}分)</span>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
        {isLoadingIterations && (
          <div className="flex items-center gap-2 py-2 text-xs text-stone-400">
            <LoaderCircle className="h-3 w-3 animate-spin" />
            加载历史版本...
          </div>
        )}
        {previewModal}
        {storyboardChoiceModal}
      </div>
    )
  }

  if (step.status === 'FAILED') {
    const canGenerate = creativeInput.trim().length >= 10
    const isImportedFramework = project.frameworkSource === 'imported' || project.frameworkSource === 'mixed'
    return (
      <div className="space-y-6">
        {/* 项目标题锚点 */}
        <div className="rounded-lg border border-stone-200 bg-stone-50/50 px-4 py-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-stone-400">项目标题</span>
            <span className="text-sm font-semibold text-stone-700">{project.title}</span>
          </div>
        </div>

        {/* 框架导入兼容：显示导入来源 */}
        {isImportedFramework && (
          <div className="rounded-lg border border-green-200 bg-green-50 px-4 py-3">
            <div className="flex items-center gap-2">
              <Check className="h-4 w-4 text-green-600" />
              <span className="text-sm text-green-700">
                已从文件导入框架：{project.importedFileName || '未知文件'}
              </span>
            </div>
            <p className="mt-1 text-xs text-green-600">
              框架搭建步骤已完成。你可以直接开始后续步骤，或重新进行创意扩散以更换方向。
            </p>
          </div>
        )}

        {/* 创意输入区域 */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-stone-700">
            {isImportedFramework ? '更换创意方向（可选）' : '输入你的创意方向'}
          </label>
          <div className="relative">
            <textarea
              value={creativeInput}
              onChange={(e) => handleCreativeInputChange(e.target.value)}
              placeholder={isImportedFramework
                ? '如需更换方向，请输入新的创意描述...'
                : '描述你的故事核心、世界观或情绪基调，例如：一个被遗弃的机器人在雨夜城市中收集人类情感残影...'}
              maxLength={1000}
              className="min-h-[160px] w-full resize-y rounded-lg border border-stone-200 bg-white p-4 text-sm leading-relaxed text-stone-800 placeholder:text-stone-300 focus:border-amber-400 focus:outline-none focus:ring-2 focus:ring-amber-100"
            />
            <div className="absolute bottom-3 right-3 text-xs text-stone-400">
              {creativeInput.length} / 1000
              {savingInput && <span className="ml-2 text-amber-500">保存中...</span>}
            </div>
          </div>
          {creativeInput.length > 0 && creativeInput.length < 10 && (
            <p className="text-xs text-amber-600">至少需要 10 个字符才能生成</p>
          )}
        </div>

        <ErrorBanner
          message={`生成失败：${errorMessage || '未知错误'}，请检查 API 密钥配置后重试`}
          onDismiss={() => onError(null)}
        />
        <div className="flex justify-center">
          <button
            onClick={() => onExecute('IDEATION', { creativeInput: creativeInput.trim() })}
            disabled={isExecuting || !canGenerate}
            className="flex items-center gap-2 rounded-lg bg-red-600 px-6 py-3 text-sm font-medium text-white transition hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {isExecuting ? (
              <>
                <LoaderCircle className="h-4 w-4 animate-spin" />
                重试中...
              </>
            ) : (
              <>
                {isImportedFramework ? '重新创意扩散' : '重试'}
              </>
            )}
          </button>
        </div>
        {previewModal}
        {storyboardChoiceModal}
      </div>
    )
  }

  return (
    <>
      <ProcessingBlock message="暂无创意方向数据" />
      {previewModal}
      {storyboardChoiceModal}
    </>
  )
}

/** 框架预览组件 */
function FrameworkPreview({ framework }: { framework: any }) {
  if (!framework) return null

  return (
    <div className="space-y-6">
      {/* 灵感阐释 */}
      {framework.inspiration && (
        <div className="rounded-lg border border-stone-200 p-4">
          <h3 className="mb-2 text-sm font-semibold text-stone-700">灵感阐释</h3>
          <p className="text-sm leading-relaxed text-stone-600">{framework.inspiration}</p>
        </div>
      )}

      {/* 风格规范 */}
      {framework.styleGuide && (
        <div className="rounded-lg border border-stone-200 p-4">
          <h3 className="mb-2 text-sm font-semibold text-stone-700">风格规范</h3>
          <p className="text-sm leading-relaxed text-stone-600">{framework.styleGuide}</p>
        </div>
      )}

      {/* 背景环境 */}
      {framework.background && (
        <div className="rounded-lg border border-stone-200 p-4">
          <h3 className="mb-2 text-sm font-semibold text-stone-700">背景环境设定</h3>
          <p className="text-sm leading-relaxed text-stone-600">{framework.background}</p>
        </div>
      )}

      {/* 角色设定 */}
      {framework.characters?.length > 0 && (
        <div className="rounded-lg border border-stone-200 p-4">
          <h3 className="mb-3 text-sm font-semibold text-stone-700">角色设定</h3>
          <div className="space-y-3">
            {framework.characters.map((char: any, idx: number) => (
              <div key={idx} className="rounded-md bg-stone-50 p-3">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-stone-800">{char.name}</span>
                  <span className="rounded-full bg-stone-200 px-2 py-0.5 text-xs text-stone-600">
                    {char.role}
                  </span>
                </div>
                <p className="mt-1 text-sm text-stone-600">{char.description}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 故事梗概 */}
      {framework.synopsis && (
        <div className="rounded-lg border border-stone-200 p-4">
          <h3 className="mb-2 text-sm font-semibold text-stone-700">故事梗概</h3>
          <p className="text-sm leading-relaxed text-stone-600">{framework.synopsis}</p>
        </div>
      )}

      {/* 幕结构 */}
      {framework.acts?.length > 0 && (
        <div className="rounded-lg border border-stone-200 p-4">
          <h3 className="mb-3 text-sm font-semibold text-stone-700">
            幕结构（{framework.acts.length} 幕，预估 {framework.totalDuration || '未知'}）
          </h3>
          <div className="space-y-3">
            {framework.acts.map((act: any, idx: number) => (
              <div key={idx} className="rounded-md bg-stone-50 p-3">
                <div className="flex items-center justify-between">
                  <span className="font-medium text-stone-800">
                    第{act.actNo || idx + 1}幕：{act.title}
                  </span>
                  <div className="flex items-center gap-2 text-xs text-stone-500">
                    <span>{act.estimatedDuration}</span>
                    <span>·</span>
                    <span>{act.estimatedShots} 镜</span>
                  </div>
                </div>
                <p className="mt-1 text-sm text-stone-600">{act.content}</p>
                <div className="mt-2 flex items-center gap-2">
                  <span className="rounded-full bg-amber-100 px-2 py-0.5 text-xs text-amber-700">
                    {act.pacing}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 环境列表 */}
      {framework.environments?.length > 0 && (
        <div className="rounded-lg border border-stone-200 p-4">
          <h3 className="mb-2 text-sm font-semibold text-stone-700">环境场景</h3>
          <div className="flex flex-wrap gap-2">
            {framework.environments.map((env: string, idx: number) => (
              <span key={idx} className="rounded-full bg-blue-100 px-3 py-1 text-xs text-blue-700">
                {env}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* 整体节奏 */}
      {framework.overallPacing && (
        <div className="rounded-lg border border-stone-200 p-4">
          <h3 className="mb-2 text-sm font-semibold text-stone-700">整体节奏策略</h3>
          <p className="text-sm leading-relaxed text-stone-600">{framework.overallPacing}</p>
        </div>
      )}
    </div>
  )
}

/** 将纯文本按换行符格式化为段落，对话行自动单独成段 */
function FormattedText({ text, className }: { text: string; className?: string }) {
  if (!text) return null
  // 按双换行切分段落，同时兼容单换行形成的段落
  const paragraphs = text.split(/\n{2,}/).filter(Boolean)
  return (
    <div className={className}>
      {paragraphs.map((para, pi) => {
        // 段落内部再按单换行切分（LLM 有时用单换行分隔对话）
        const lines = para.split('\n').filter(Boolean)
        return (
          <div key={pi} className={pi > 0 ? 'mt-3' : ''}>
            {lines.map((line, li) => {
              const trimmed = line.trim()
              // 检测对话行：以引号开头，或包含 "说："/"道：" 等对话标记
              const isDialogue =
                /^[「『“‘"']/.test(trimmed) ||
                /[「『“‘"'].+[」』”’"']/.test(trimmed) ||
                /[说道喊叫问答嚷]\s*[:：]/.test(trimmed)
              return (
                <p
                  key={li}
                  className={
                    isDialogue
                      ? 'mt-1 pl-3 border-l-2 border-stone-200 italic text-stone-600'
                      : li > 0 ? 'mt-1' : ''
                  }
                >
                  {trimmed}
                </p>
              )
            })}
          </div>
        );
      })}
    </div>
  );
}

function DeepeningStatus({ deepening }: { deepening?: any }) {
  if (!deepening) return null
  const status = deepening.status
  if (status === 'completed' || status === 'idle' || !status) return null

  const isError = status === 'error'
  const progress = deepening.progress || {}

  return (
    <div className={`rounded-lg border px-4 py-3 ${isError ? 'border-red-200 bg-red-50' : 'border-amber-200 bg-amber-50'}`}>
      <div className="flex items-center gap-2">
        {isError ? (
          <RefreshCw className="h-4 w-4 text-red-500" />
        ) : (
          <LoaderCircle className="h-4 w-4 animate-spin text-amber-500" />
        )}
        <span className={`text-sm font-medium ${isError ? 'text-red-700' : 'text-amber-700'}`}>
          {progress.phase || '深化中...'}
        </span>
      </div>
      {progress.total > 0 && !isError && (
        <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-amber-200">
          <div
            className="h-full rounded-full bg-amber-500 transition-all duration-300"
            style={{ width: `${(progress.current / progress.total) * 100}%` }}
          />
        </div>
      )}
    </div>
  )
}

function ReadOrEdit({
  readOnly,
  value,
  onSave,
  className,
  placeholder,
}: {
  readOnly?: boolean
  value: string
  onSave: (val: string) => void
  className?: string
  placeholder?: string
}) {
  if (readOnly) {
    return (
      <p className={className}>
        {value || <span className="text-stone-400">{placeholder}</span>}
      </p>
    )
  }
  return (
    <ClickToEdit
      value={value}
      onSave={onSave}
      className={className}
      placeholder={placeholder}
    />
  )
}

function FrameworkPanel({
  step,
  project,
  projectId,
  mutate,
  readOnly,
}: {
  step: any
  project: any
  projectId: string
  mutate: () => Promise<any>
  readOnly?: boolean
}) {
  // 所有 Hook 必须在任何提前 return 之前调用：
  // 提前 return 后再调 Hook 会让 React 认为 Hook 顺序变了，条件渲染时直接崩状态。
  const output = step.outputData

  const [localOutput, setLocalOutput] = useState(output)
  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const lastSavedRef = useRef(output)
  const [deepeningType, setDeepeningType] = useState<string | null>(null)

  useEffect(() => {
    const outJson = JSON.stringify(output)
    const lastSavedJson = JSON.stringify(lastSavedRef.current)
    if (outJson !== lastSavedJson) {
      setLocalOutput(output)
      lastSavedRef.current = output
    }
  }, [output])

  // 从人物设计步骤获取角色生图，按 characterId 映射
  const characterImageMap = useMemo(() => {
    const map: Record<string, string> = {}
    // 优先从 project.assets 中筛选（更可靠，不依赖嵌套关系）
    const allAssets = project?.assets || []
    for (const asset of allAssets) {
      const meta = asset.metadata as any
      const cid = meta?.characterId
      if (cid && asset.url && !map[cid]) {
        map[cid] = asset.url
      }
    }
    // 兜底：从 steps.resultAssets 中补充
    const characterStep = project?.steps?.find((s: any) => s.stepType === 'CHARACTER')
    const stepAssets = characterStep?.resultAssets || []
    for (const asset of stepAssets) {
      const cid = asset.metadata?.characterId
      if (cid && asset.url && !map[cid]) {
        map[cid] = asset.url
      }
    }
    return map
  }, [project])

  // Hook 全部调用完毕之后才能提前 return
  if (!output) return <ProcessingBlock message="暂无框架数据" />

  async function handleDeepen(type: string) {
    setDeepeningType(type)
    try {
      const res = await fetch(`/api/projects/${projectId}/steps/framework/deepen`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type }),
      })
      const data = await res.json()
      if (!data.success) {
        console.error('[DEEPEN] 失败:', data.message)
      }
    } catch (e: any) {
      console.error('[DEEPEN] 请求失败:', e.message)
    } finally {
      setDeepeningType(null)
      await mutate()
    }
  }

  function updateField(field: string, value: any) {
    const next = { ...localOutput, [field]: value }
    setLocalOutput(next)
    if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current)
    saveTimeoutRef.current = setTimeout(() => {
      saveFramework(next)
    }, 500)
  }

  function updateCharacter(ci: number, patch: Record<string, any>) {
    const newChars = [...(localOutput.characters || [])]
    newChars[ci] = { ...newChars[ci], ...patch }
    updateField('characters', newChars)
  }

  function updateCharacterDeepened(ci: number, field: string, value: string) {
    const current = localOutput.characters?.[ci] || {}
    updateCharacter(ci, {
      deepened: {
        ...(current.deepened || {}),
        [field]: value,
      },
    })
  }

  function updateCharacterAttitude(ci: number, target: string, value: string) {
    const current = localOutput.characters?.[ci] || {}
    updateCharacter(ci, {
      deepened: {
        ...(current.deepened || {}),
        attitudes: {
          ...(current.deepened?.attitudes || {}),
          [target]: value,
        },
      },
    })
  }

  async function saveFramework(nextOutput: any) {
    try {
      const body: any = {}
      if (nextOutput.background !== undefined) body.background = nextOutput.background
      if (nextOutput.styleGuide !== undefined) body.styleGuide = nextOutput.styleGuide
      if (nextOutput.visualStyle !== undefined) body.visualStyle = nextOutput.visualStyle
      if (nextOutput.inspiration !== undefined) body.inspiration = nextOutput.inspiration
      if (nextOutput.synopsis !== undefined) body.synopsis = nextOutput.synopsis
      if (nextOutput.characters !== undefined) body.characters = nextOutput.characters
      if (nextOutput.acts !== undefined) body.acts = nextOutput.acts
      if (nextOutput.environments !== undefined) body.environments = nextOutput.environments
      if (nextOutput.overallPacing !== undefined) body.overallPacing = nextOutput.overallPacing
      if (nextOutput.selectedStyleImage !== undefined) body.selectedStyleImage = nextOutput.selectedStyleImage

      const res = await fetch(`/api/projects/${projectId}/steps/framework`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      })
      if (!res.ok) throw new Error('保存失败')
      lastSavedRef.current = nextOutput
      await mutate()
      console.log('[TEXT-EDIT-FRAMEWORK] 保存 framework 字段成功')
    } catch (e: any) {
      console.error('[TEXT-EDIT-FRAMEWORK] 保存失败:', e.message)
      setLocalOutput(lastSavedRef.current)
    }
  }

  const deepening = localOutput.deepening
  const isDeepening = deepening?.status && !['completed', 'idle', 'error'].includes(deepening.status)
  const hasDeepened = deepening?.status === 'completed'

  function renderDeepenButton(type: string, label: string) {
    const isThisDeepening = deepeningType === type || (isDeepening && !deepeningType)
    const hasThisDeepened = hasDeepened
    if (isThisDeepening) {
      return (
        <button
          disabled
          className="flex items-center gap-1 rounded bg-amber-100 px-2 py-1 text-xs font-medium text-amber-700 disabled:opacity-60"
        >
          <LoaderCircle className="h-3 w-3 animate-spin" />
          深化中...
        </button>
      )
    }
    if (hasThisDeepened) {
      return (
        <button
          onClick={(e) => { e.stopPropagation(); handleDeepen(type) }}
          className="flex items-center gap-1 rounded bg-green-50 px-2 py-1 text-xs font-medium text-green-700 transition hover:bg-green-100"
        >
          <Check className="h-3 w-3" />
          已深化
        </button>
      )
    }
    return (
      <button
        onClick={(e) => { e.stopPropagation(); handleDeepen(type) }}
        className="flex items-center gap-1 rounded bg-amber-50 px-2 py-1 text-xs font-medium text-amber-700 transition hover:bg-amber-100"
      >
        <Sparkles className="h-3 w-3" />
        开始深化
      </button>
    )
  }

  return (
    <div className="space-y-4">
      <DeepeningStatus deepening={deepening} />

      <CollapsibleSection title="灵感阐释" defaultOpen>
        {localOutput.inspirationSource && (
          <div className="mb-3 rounded-md border border-amber-100 bg-amber-50/50 px-3 py-2">
            <p className="text-xs font-medium text-amber-700">原始灵感来源（深化后）</p>
            <p className="mt-1 text-xs leading-relaxed text-stone-600 line-clamp-4">
              {localOutput.inspirationSource}
            </p>
          </div>
        )}
        <ReadOrEdit
          readOnly={readOnly}
          value={localOutput.inspiration || ''}
          onSave={(newVal) => updateField('inspiration', newVal)}
          className="text-sm leading-relaxed text-stone-700"
          placeholder="灵感阐释..."
        />
      </CollapsibleSection>

      <CollapsibleSection title="背景设定" defaultOpen>
        <ReadOrEdit
          readOnly={readOnly}
          value={localOutput.background || ''}
          onSave={(newVal) => updateField('background', newVal)}
          className="text-sm leading-relaxed text-stone-700"
          placeholder="背景设定..."
        />
      </CollapsibleSection>

      <CollapsibleSection title="视觉风格">
        {localOutput.selectedStyleImage ? (
          <div className="flex gap-4">
            {/* 左侧文字区域 */}
            <div className="flex-1 min-w-0 flex flex-col justify-center">
              <ReadOrEdit
                readOnly={readOnly}
                value={localOutput.visualStyle || localOutput.styleGuide || ''}
                onSave={(newVal) => updateField('visualStyle', newVal)}
                className="text-sm leading-relaxed text-stone-700"
                placeholder="视觉风格..."
              />
            </div>
            {/* 右侧风格图 */}
            <div className="shrink-0">
              <img
                src={proxiedMediaUrl(localOutput.selectedStyleImage)}
                alt="选定的视觉风格"
                className="rounded-lg border border-stone-200 object-cover"
                style={{ maxHeight: 200, maxWidth: 280, width: 'auto', height: 'auto' }}
                onError={(e) => {
                  (e.target as HTMLImageElement).style.display = 'none'
                }}
              />
              <p className="mt-1 text-center text-[10px] text-stone-400">已选定的风格基准</p>
            </div>
          </div>
        ) : (
          <ReadOrEdit
            readOnly={readOnly}
            value={localOutput.visualStyle || localOutput.styleGuide || ''}
            onSave={(newVal) => updateField('visualStyle', newVal)}
            className="text-sm leading-relaxed text-stone-700"
            placeholder="视觉风格..."
          />
        )}
      </CollapsibleSection>

      <CollapsibleSection title={`角色设定 (${localOutput.characters?.length || 0})`} headerAction={renderDeepenButton('characters', '角色')}>
        <div className="space-y-3">
          {localOutput.characters?.map((c: any, ci: number) => {
            const charImageUrl = characterImageMap[c.id]
            return (
              <div
                key={c.id}
                className="rounded-lg border border-stone-200 bg-stone-50/50 p-4"
              >
                {/* 顶部标签栏 */}
                <div className="flex items-center gap-2">
                  <span className="rounded bg-stone-800 px-2 py-0.5 text-xs font-medium text-white">
                    {c.id}
                  </span>
                  <ReadOrEdit
                    readOnly={readOnly}
                    value={c.name || ''}
                    onSave={(newVal) => updateCharacter(ci, { name: newVal })}
                    className="font-medium text-stone-800"
                    placeholder="角色姓名"
                  />
                  <ReadOrEdit
                    readOnly={readOnly}
                    value={c.role || ''}
                    onSave={(newVal) => updateCharacter(ci, { role: newVal })}
                    className="text-xs text-stone-500"
                    placeholder="角色定位"
                  />
                </div>

                {/* 左右分栏：文字 | 图片 */}
                <div className="mt-3 flex flex-col gap-4 md:flex-row">
                  {/* 左侧文字 */}
                  <div className="min-w-0 flex-1">
                    {/* 基础描述 */}
                    <div>
                      <span className="text-xs text-stone-400">基础设定</span>
                      <ReadOrEdit
                        readOnly={readOnly}
                        value={c.description || ''}
                        onSave={(newVal) => {
                          const newChars = [...localOutput.characters]
                          newChars[ci] = { ...newChars[ci], description: newVal }
                          updateField('characters', newChars)
                        }}
                        className="text-sm text-stone-600"
                        placeholder="角色描述..."
                      />
                    </div>
                    {/* 深化内容 */}
                    {c.deepened && (
                      <div className="mt-3 space-y-2 border-t border-stone-200 pt-3">
                        {/* 工作指令.txt（2026-06-07）：检测深化是否实际有内容，避免空 deepened 对象导致显示空白区域 */}
                        {(() => {
                          const hasContent = !!(
                            c.deepened.appearance ||
                            c.deepened.personality ||
                            c.deepened.catchphrase ||
                            (c.deepened.attitudes && Object.keys(c.deepened.attitudes).length > 0) ||
                            c.deepened.memoryPoints
                          )
                          if (!hasContent) {
                            return (
                              <div className="text-xs text-stone-400">
                                {c.deepened._failed
                                  ? `深化失败：${c.deepened._error || '请重试'}`
                                  : '深化内容为空'}
                              </div>
                            )
                          }
                          return null
                        })()}
                        {c.deepened.appearance && (
                          <div>
                            <span className="text-xs text-stone-400">形象外貌</span>
                            <ReadOrEdit
                              readOnly={readOnly}
                              value={formatFrameworkText(c.deepened.appearance)}
                              onSave={(newVal) => updateCharacterDeepened(ci, 'appearance', newVal)}
                              className="text-sm text-stone-600"
                              placeholder="形象外貌..."
                            />
                          </div>
                        )}
                        {c.deepened.personality && (
                          <div>
                            <span className="text-xs text-stone-400">性格深度</span>
                            <ReadOrEdit
                              readOnly={readOnly}
                              value={formatFrameworkText(c.deepened.personality)}
                              onSave={(newVal) => updateCharacterDeepened(ci, 'personality', newVal)}
                              className="text-sm text-stone-600"
                              placeholder="性格深度..."
                            />
                          </div>
                        )}
                        {c.deepened.catchphrase && (
                          <div>
                            <span className="text-xs text-stone-400">口头禅</span>
                            <ReadOrEdit
                              readOnly={readOnly}
                              value={formatFrameworkText(c.deepened.catchphrase)}
                              onSave={(newVal) => updateCharacterDeepened(ci, 'catchphrase', newVal)}
                              className="text-sm font-medium text-amber-700"
                              placeholder="口头禅..."
                            />
                          </div>
                        )}
                        {c.deepened.attitudes && Object.keys(c.deepened.attitudes).length > 0 && (
                          <div>
                            <span className="text-xs text-stone-400">人际态度</span>
                            <div className="mt-1 space-y-1">
                              {Object.entries(c.deepened.attitudes).map(([target, attitude]: [string, any]) => (
                                <div key={target} className="flex items-start gap-2 text-sm">
                                  <span className="shrink-0 rounded bg-stone-200 px-1.5 py-0.5 text-xs text-stone-600">{target}</span>
                                  <ReadOrEdit
                                    readOnly={readOnly}
                                    value={formatFrameworkText(attitude)}
                                    onSave={(newVal) => updateCharacterAttitude(ci, target, newVal)}
                                    className="min-w-0 flex-1 text-stone-600"
                                    placeholder="关系态度..."
                                  />
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                        {c.deepened.memoryPoints && (
                          <div>
                            <span className="text-xs text-stone-400">记忆点</span>
                            <ReadOrEdit
                              readOnly={readOnly}
                              value={formatFrameworkText(c.deepened.memoryPoints)}
                              onSave={(newVal) => updateCharacterDeepened(ci, 'memoryPoints', newVal)}
                              className="text-sm font-medium text-stone-700"
                              placeholder="记忆点..."
                            />
                          </div>
                        )}
                      </div>
                    )}
                    {isDeepening && !c.deepened && (
                      <div className="mt-2 flex items-center gap-2 text-xs text-stone-400">
                        <LoaderCircle className="h-3 w-3 animate-spin" />
                        等待深化...
                      </div>
                    )}
                  </div>

                  {/* 右侧图片 */}
                  <div className="shrink-0 md:w-48">
                    {charImageUrl ? (
                      <div className="flex flex-col items-center">
                        <div className="relative w-full overflow-hidden rounded-lg shadow-md">
                          <img
                            src={proxiedMediaUrl(charImageUrl)}
                            alt={c.name}
                            className="h-auto w-full object-cover"
                            loading="lazy"
                          />
                        </div>
                        <span className="mt-1.5 text-[11px] text-stone-400">已选定的角色形象</span>
                      </div>
                    ) : (
                      <div className="flex h-32 w-full flex-col items-center justify-center rounded-lg border border-dashed border-stone-200 bg-stone-100/50">
                        <ImageIcon className="h-6 w-6 text-stone-300" />
                        <span className="mt-1 text-[11px] text-stone-400">尚未生成角色形象</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </CollapsibleSection>

      <CollapsibleSection title="故事梗概" headerAction={renderDeepenButton('story', '故事')}>
        {localOutput.deepenedSynopsis ? (
          <FormattedText
            text={localOutput.deepenedSynopsis}
            className="text-sm leading-relaxed text-stone-700"
          />
        ) : (
          <ReadOrEdit
            readOnly={readOnly}
            value={localOutput.synopsis || ''}
            onSave={(newVal) => updateField('synopsis', newVal)}
            className="text-sm leading-relaxed text-stone-700"
            placeholder="故事梗概..."
          />
        )}
      </CollapsibleSection>

      <CollapsibleSection title="幕结构">
        <div className="space-y-3">
          {localOutput.acts?.map((act: any, ai: number) => (
            <div
              key={act.actNo || ai}
              className="rounded-lg border border-stone-200 bg-stone-50/50 p-4"
            >
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-sm font-semibold text-stone-800">
                  第 {act.actNo || ai + 1} 幕 · {act.title || '未命名'}
                </span>
                {act.estimatedDuration && (
                  <span className="text-xs text-stone-500">{act.estimatedDuration}</span>
                )}
                {typeof act.estimatedShots === 'number' && act.estimatedShots > 0 && (
                  <span className="text-xs text-stone-500">{act.estimatedShots} 镜</span>
                )}
                {act.pacing && (
                  <span className="rounded bg-stone-200 px-1.5 py-0.5 text-xs text-stone-600">{act.pacing}</span>
                )}
              </div>
              <div className="mt-2">
                <span className="text-xs text-stone-400">原始简述</span>
                <ReadOrEdit
                  readOnly={readOnly}
                  value={act.content || ''}
                  onSave={(newVal) => {
                    const newActs = [...localOutput.acts]
                    newActs[ai] = { ...newActs[ai], content: newVal }
                    updateField('acts', newActs)
                  }}
                  className="text-sm text-stone-600"
                  placeholder="幕内容概述..."
                />
              </div>
              {act.deepenedContent && (
                <div className="mt-3 border-t border-stone-200 pt-3">
                  <span className="text-xs text-stone-400">深化内容</span>
                  <FormattedText
                    text={act.deepenedContent}
                    className="mt-1 text-sm leading-relaxed text-stone-700"
                  />
                </div>
              )}
              <div className="mt-2 space-y-1">
                <span className="text-xs text-stone-400">核心场景：</span>
                {(act.keyScenes || []).map((s: string, si: number) => (
                  <div key={si} className="flex items-start gap-2">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-stone-400" />
                    <div className="min-w-0 flex-1">
                      <ReadOrEdit
                        readOnly={readOnly}
                        value={s || ''}
                        onSave={(newVal) => {
                          const newActs = [...localOutput.acts]
                          const newScenes = [...(newActs[ai].keyScenes || [])]
                          newScenes[si] = newVal
                          newActs[ai] = { ...newActs[ai], keyScenes: newScenes }
                          updateField('acts', newActs)
                        }}
                        className="text-sm text-stone-600"
                        placeholder="场景描述..."
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </CollapsibleSection>

      {/* Phase 3: 环境设定卡片化 */}
      <CollapsibleSection title={`环境设定 (${Array.isArray(localOutput.environments) ? localOutput.environments.length : 0})`} headerAction={renderDeepenButton('environments', '环境')}>
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {Array.isArray(localOutput.environments) && localOutput.environments.map((env: any, ei: number) => {
            const isObject = typeof env === 'object' && env !== null
            const name = isObject ? formatFrameworkText(env.name) : formatFrameworkText(env)
            const brief = isObject ? formatFrameworkText(env.brief) : ''
            const architecture = isObject ? formatFrameworkText(env.architecture) : ''
            const atmosphere = isObject ? formatFrameworkText(env.atmosphere) : ''
            const culture = isObject ? formatFrameworkText(env.culture) : ''
            const distinctive = isObject ? formatFrameworkText(env.distinctive) : ''
            const storyFunction = isObject ? formatFrameworkText(env.storyFunction) : ''
            return (
              <div key={ei} className="rounded-lg border border-stone-200 bg-stone-50/50 p-4">
                <div className="flex items-center gap-2">
                  <span className="rounded bg-stone-700 px-2 py-0.5 text-xs font-medium text-white">
                    环境 {ei + 1}
                  </span>
                  <span className="font-medium text-stone-800">{name}</span>
                </div>
                {brief && (
                  <p className="mt-2 text-sm italic text-stone-500">{brief}</p>
                )}
                {isObject && (
                  <div className="mt-3 space-y-2">
                    {architecture && (
                      <div>
                        <span className="text-xs text-stone-400">建筑风格</span>
                        <p className="whitespace-pre-line text-sm text-stone-600">{architecture}</p>
                      </div>
                    )}
                    {atmosphere && (
                      <div>
                        <span className="text-xs text-stone-400">影调氛围</span>
                        <p className="whitespace-pre-line text-sm text-stone-600">{atmosphere}</p>
                      </div>
                    )}
                    {culture && (
                      <div>
                        <span className="text-xs text-stone-400">人文情况</span>
                        <p className="whitespace-pre-line text-sm text-stone-600">{culture}</p>
                      </div>
                    )}
                    {distinctive && (
                      <div>
                        <span className="text-xs text-stone-400">辨识度</span>
                        <p className="whitespace-pre-line text-sm font-medium text-stone-700">{distinctive}</p>
                      </div>
                    )}
                    {storyFunction && (
                      <div>
                        <span className="text-xs text-stone-400">叙事功能</span>
                        <p className="whitespace-pre-line text-sm text-stone-600">{storyFunction}</p>
                      </div>
                    )}
                  </div>
                )}
                {/* 兼容旧数据：纯字符串环境 */}
                {!isObject && (
                  <div className="mt-2">
                    <ReadOrEdit
                      readOnly={readOnly}
                      value={String(env)}
                      onSave={(newVal) => {
                        const newEnvs = [...(localOutput.environments || [])]
                        newEnvs[ei] = newVal
                        updateField('environments', newEnvs)
                      }}
                      className="text-sm text-stone-600"
                      placeholder="环境描述..."
                    />
                  </div>
                )}
              </div>
            )
          })}
        </div>
        {/* 旧数据兼容：无环境时的编辑区 */}
        {(!localOutput.environments || localOutput.environments.length === 0) && (
          <ReadOrEdit
            readOnly={readOnly}
            value={(localOutput.environments || []).join('\n')}
            onSave={(newVal) => {
              const lines = newVal.split('\n').filter((l: string) => l.trim())
              updateField('environments', lines)
            }}
            className="text-sm leading-relaxed text-stone-700"
            placeholder="每行一个核心环境..."
          />
        )}
      </CollapsibleSection>

      <CollapsibleSection title="整体节奏策略">
        <ReadOrEdit
          readOnly={readOnly}
          value={localOutput.overallPacing || ''}
          onSave={(newVal) => updateField('overallPacing', newVal)}
          className="text-sm leading-relaxed text-stone-700"
          placeholder="整体节奏策略说明..."
        />
      </CollapsibleSection>

      <CollapsibleSection title="分档与总时长">
        <div className="flex gap-4">
          <div className="flex-1">
            <span className="text-xs text-stone-400">分档</span>
            <ReadOrEdit
              readOnly={readOnly}
              value={localOutput.storyLength || ''}
              onSave={(newVal) => updateField('storyLength', newVal)}
              className="text-sm text-stone-700"
              placeholder="如 short"
            />
          </div>
          <div className="flex-1">
            <span className="text-xs text-stone-400">预估总时长</span>
            <ReadOrEdit
              readOnly={readOnly}
              value={localOutput.totalDuration || ''}
              onSave={(newVal) => updateField('totalDuration', newVal)}
              className="text-sm text-stone-700"
              placeholder="如 4分钟"
            />
          </div>
        </div>
      </CollapsibleSection>
    </div>
  )
}

function StylePanel({
  step,
  project,
  executing,
  onExecute,
  onSelectStyle,
  onError,
  mutate,
  setToast,
  readOnly,
}: {
  step: any
  project: any
  executing: string | null
  onExecute: (stepType: string, body?: any) => void
  onSelectStyle: (styleId: string, styleRefUrl?: string) => void
  onError: (msg: string | null) => void
  mutate: () => Promise<any>
  setToast: (t: { kind: 'success' | 'error'; message: string } | null) => void
  readOnly?: boolean
}) {
  const isExecuting = executing === step.stepType
  const allSteps = project?.steps || []
  const frameworkStep = allSteps.find((s: any) => s.stepType === 'FRAMEWORK')
  const frameworkCompleted = frameworkStep?.status === 'COMPLETED'
  const outputData = step.outputData || {}
  const styleOptions: any[] = outputData.styleOptions || []
  const errorMessage = step.errorMessage || ''

  // 这些必须在下面所有条件 return 之前调用：
  // 提前 return 后再调 Hook 会让 React 认为 Hook 顺序变了，条件渲染时直接崩状态
  const assets = step.resultAssets || []
  const optionsWithImages = styleOptions.map((opt: any) => {
    const asset = assets.find((a: any) => a.metadata?.styleId === opt.id)
    return { ...opt, imageUrl: opt.imageUrl || asset?.url, assetId: asset?.id }
  })
  const [regeneratingId, setRegeneratingId] = useState<string | null>(null)
  const [showConfirmAll, setShowConfirmAll] = useState(false)
  // Phase 5: 每个卡片独立的模型选择状态
  const [cardModels, setCardModels] = useState<Record<string, string>>(() => {
    const initial: Record<string, string> = {}
    optionsWithImages.forEach((opt: any) => {
      const modelNo = opt.modelNo || opt.metadata?.modelNo
      const poolModel = modelNo ? STYLE_MODEL_POOL.find(m => m.no === modelNo) : null
      initial[opt.id] = poolModel?.id || opt.metadata?.imageModel || IMAGE_MODELS.primary
    })
    return initial
  })

  // PROMPT_READY：提示词预览（必须在 PENDING 之前判断）
  if (step.status === 'PENDING' && step.outputData?.prompts?.length > 0) {
    console.log('[PROMPT-BUGFIX] StylePanel PROMPT_READY detected, prompts:', step.outputData.prompts.length)
    const defaultRatio = step.outputData?.aspectRatio || project.selectedAspectRatio || '16:9'
    const defaultModel = IMAGE_MODELS.primary
    return (
      <PromptPreviewWithRatio
        prompts={step.outputData.prompts}
        title="风格提示词预览"
        stepLabel="STYLE"
        defaultRatio={defaultRatio}
        defaultModel={defaultModel}
        onConfirm={(ratio, model) => onExecute('STYLE', { action: 'generate-images', aspectRatio: ratio, imageModel: model })}
        onRegeneratePrompts={() => onExecute('STYLE', { action: 'generate-prompts' })}
        isExecuting={isExecuting}
        editable={!readOnly}
        projectId={project.id}
        stepType="STYLE"
        onSaveSuccess={() => mutate()}
      />
    )
  }

  // PENDING：检查前序步骤
  if (step.status === 'PENDING') {
    if (!frameworkCompleted) {
      return <ProcessingBlock message="请先完成上一步（框架搭建）" />
    }
    return (
      <div className="flex flex-col items-center justify-center gap-6 py-12">
        <div className="text-center">
          <Sparkles className="mx-auto h-10 w-10 text-amber-500" />
          <p className="mt-3 text-sm text-stone-500">框架已就绪，接下来将基于影片设定生成 3 种截然不同的视觉风格</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative inline-block">
            <button
              onClick={() => onExecute('STYLE', { action: 'generate-prompts' })}
              disabled={isExecuting}
              className="flex items-center gap-2 rounded-lg bg-stone-900 px-6 py-3 text-sm font-medium text-white transition hover:bg-stone-800 disabled:opacity-50"
            >
              {isExecuting ? (
                <>
                  <LoaderCircle className="h-4 w-4 animate-spin" />
                  生成中...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4" />
                  生成三种风格
                </>
              )}
            </button>
            <CostBadge cost={DEFAULT_GENERATE_COST} />
          </div>
        </div>
      </div>
    )
  }

  // PROCESSING：骨架屏或部分结果
  if (step.status === 'PROCESSING') {
    if (styleOptions.length > 0) {
      return (
        <div className="space-y-4">
          <p className="text-sm text-stone-600">正在生成风格样图，请稍候...</p>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            {styleOptions.map((opt: any) => (
              <div
                key={opt.id}
                className="overflow-hidden rounded-lg border-2 border-stone-200 bg-white"
              >
                <div className="relative aspect-square animate-pulse bg-stone-200" />
                <div className="space-y-2 p-3">
                  <div className="h-4 w-2/3 animate-pulse rounded bg-stone-200" />
                  <div className="h-3 w-full animate-pulse rounded bg-stone-200" />
                </div>
              </div>
            ))}
          </div>
        </div>
      )
    }
    return <ProcessingBlock message="正在分析影片设定并生成风格方案..." />
  }

  // FAILED：重试
  if (step.status === 'FAILED') {
    return (
      <div className="flex flex-col items-center justify-center gap-6 py-12">
        <ErrorBanner
          message={`生成失败：${errorMessage || '未知错误'}，请检查 API 配置后重试`}
          onDismiss={() => {}}
        />
        <button
          onClick={() => {
            // 工作指令.txt（2026-06-07）：重试必须走完整流程，不能跳过提示词生成
            const hasPrompts = step.outputData?.prompts?.length > 0
            if (hasPrompts) {
              const defaultRatio = step.outputData?.aspectRatio || project.selectedAspectRatio || '16:9'
              const defaultModel = IMAGE_MODELS.primary
              onExecute('STYLE', { action: 'generate-images', force: true, aspectRatio: defaultRatio, imageModel: defaultModel })
            } else {
              onExecute('STYLE', { action: 'generate-prompts' })
            }
          }}
          disabled={isExecuting}
          className="flex items-center gap-2 rounded-lg bg-red-600 px-6 py-3 text-sm font-medium text-white transition hover:bg-red-700 disabled:opacity-50"
        >
          {isExecuting ? (
            <>
              <LoaderCircle className="h-4 w-4 animate-spin" />
              重试中...
            </>
          ) : (
            <>
              <RefreshCw className="h-4 w-4" />
              重试
            </>
          )}
        </button>
      </div>
    )
  }

  // COMPLETED：展示与选择
  async function handleRegenerate(styleId: string, aspectRatio?: string, _imageModel?: string) {
    setRegeneratingId(styleId)
    try {
      // 使用卡片独立选择的模型
      const cardModel = cardModels[styleId] || IMAGE_MODELS.primary
      const res = await fetch(`/api/projects/${project.id}/steps/style/regenerate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ styleId, aspectRatio, imageModel: cardModel }),
      })
      const data = await res.json()
      if (!res.ok || !data.success) throw new Error(data.message || `HTTP ${res.status}`)
      await mutate()
      setToast({ kind: 'success', message: '风格图已重新生成' })
    } catch (e: any) {
      onError('重新生成失败：' + e?.message)
    } finally {
      setRegeneratingId(null)
    }
  }

  return (
    <div className="space-y-4">
      <p className="text-sm text-stone-600">请选择一张风格图作为后续生成的统一视觉基准：</p>
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        {optionsWithImages.map((opt: any) => {
          const isSelected = project.selectedStyleId === opt.id
          return (
            <StyleCard
              key={opt.id}
              option={opt}
              isSelected={isSelected}
              onSelect={() => onSelectStyle(opt.id, opt.imageUrl)}
              onRegenerate={(ar) => handleRegenerate(opt.id, ar)}
              isRegenerating={regeneratingId === opt.id}
              anyRegenerating={!!regeneratingId}
              onModelChange={(modelId) => {
                setCardModels(prev => ({ ...prev, [opt.id]: modelId }))
              }}
            />
          )
        })}
      </div>

      {step.status === 'COMPLETED' && assets.length > 0 && (
        <div className="pt-4 border-t border-stone-100">
          {!showConfirmAll ? (
            <button
              onClick={() => setShowConfirmAll(true)}
              disabled={isExecuting}
              className="flex items-center justify-center gap-2 w-full rounded-lg border border-stone-200 bg-white px-4 py-2.5 text-sm font-medium text-stone-600 transition hover:bg-stone-50 hover:text-stone-800 disabled:opacity-50"
            >
              <RefreshCw className="h-4 w-4" />
              重新生成全部风格图
            </button>
          ) : (
            <div className="rounded-lg border border-amber-200 bg-amber-50 p-4">
              <p className="text-sm font-medium text-stone-800">确定要重新生成全部 {optionsWithImages.length} 张风格图吗？</p>
              <p className="mt-1 text-xs text-stone-500">这会覆盖现有内容，此操作不可撤销。</p>
              <div className="mt-3 flex gap-2">
                <button
                  onClick={() => setShowConfirmAll(false)}
                  className="rounded-md border border-stone-200 bg-white px-4 py-1.5 text-sm text-stone-600 transition hover:bg-stone-50"
                >取消</button>
                <div className="relative inline-block">
                  <button
                    onClick={() => { setShowConfirmAll(false); onExecute('STYLE', { force: true }) }}
                    disabled={isExecuting}
                    className="flex items-center gap-1.5 rounded-md bg-amber-600 px-4 py-1.5 text-sm font-medium text-white transition hover:bg-amber-700 disabled:opacity-50"
                  >
                    {isExecuting ? (
                      <><LoaderCircle className="h-3.5 w-3.5 animate-spin" />生成中...</>
                    ) : '确认重做'}
                  </button>
                  <CostBadge cost={DEFAULT_GENERATE_COST} />
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

/* ============================================================
   比例自适应图片组件
   ============================================================ */

function AspectAwareImage({
  src,
  alt,
  className,
  wrapperClassName,
}: {
  src: string
  alt?: string
  className?: string
  wrapperClassName?: string
}) {
  const [ratio, setRatio] = useState(1)
  const [loaded, setLoaded] = useState(false)

  return (
    <div
      className={`relative w-full bg-stone-100 transition-all duration-300 ${wrapperClassName || ''}`}
      style={{ aspectRatio: ratio }}
    >
      {!loaded && (
        <div className="absolute inset-0 flex items-center justify-center text-stone-400 text-sm">
          <ImageIcon className="h-6 w-6 animate-pulse" />
        </div>
      )}
      {src ? (
        <img
          src={proxiedMediaUrl(src)}
          alt={alt || ''}
          className={`absolute inset-0 h-full w-full object-cover ${className || ''}`}
          loading="lazy"
          onLoad={(e) => {
            const img = e.target as HTMLImageElement;
            if (img.naturalWidth && img.naturalHeight) {
              setRatio(img.naturalWidth / img.naturalHeight);
            }
            setLoaded(true);
          }}
          onError={() => {
            setRatio(1);
            setLoaded(true);
          }}
        />
      ) : (
        <div className="absolute inset-0 flex items-center justify-center text-stone-400 text-sm">
          无图片
        </div>
      )}
    </div>
  )
}

/* ============================================================
   生图模型选项（所有生图步骤共用，以 models-config.ts 实际配置为准）
   ============================================================ */

const IMAGE_MODEL_OPTIONS = IMAGE_MODELS.available
  .filter((m: any) => !(m as any).disabled)
  .map(m => ({
  label: m.label,
  value: m.id,
  desc: m.tags.join(' · '),
  provider: m.provider,
}))

/* ============================================================
   提示词预览组件（所有生图步骤共用）
   ============================================================ */

function PromptPreview({
  prompts,
  title,
  stepLabel,
  onConfirm,
  onRegeneratePrompts,
  isExecuting,
  aspectRatio,
  onAspectRatioChange,
  imageModel,
  onImageModelChange,
  editable,
  projectId,
  stepType,
  onSaveSuccess,
}: {
  prompts: Array<{
    id: string
    chineseDesc: string
    englishPrompt: string
    target: string
    [key: string]: unknown
  }>
  title: string
  stepLabel: string
  onConfirm: () => void
  onRegeneratePrompts: () => void
  isExecuting: boolean
  aspectRatio?: string
  onAspectRatioChange?: (ratio: string) => void
  imageModel?: string
  onImageModelChange?: (model: string) => void
  editable?: boolean
  projectId?: string
  stepType?: string
  onSaveSuccess?: () => void
}) {
  const imageCostPerItem =
    stepLabel === 'STYLE' ? GENERATION_COSTS.STYLE_UNIFY
      : stepLabel === 'CHARACTER' ? GENERATION_COSTS.CHARACTER_DESIGN
        : stepLabel === 'CONCEPT' ? GENERATION_COSTS.CONCEPT_ART
          : stepLabel === 'KEYFRAMES' ? GENERATION_COSTS.KEYFRAME
            : DEFAULT_GENERATE_COST
  const confirmedGenerationCost = calculateBatchCost(imageCostPerItem, prompts.length)
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set())
  const [localPrompts, setLocalPrompts] = useState(prompts)
  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const lastSavedRef = useRef(prompts)

  useEffect(() => {
    const promptsJson = JSON.stringify(prompts)
    const lastSavedJson = JSON.stringify(lastSavedRef.current)
    if (promptsJson !== lastSavedJson) {
      setLocalPrompts(prompts)
      lastSavedRef.current = prompts
    }
  }, [prompts])

  function handleUpdatePrompt(index: number, field: 'chineseDesc' | 'englishPrompt', value: string) {
    const newPrompts = [...localPrompts]
    newPrompts[index] = { ...newPrompts[index], [field]: value }
    setLocalPrompts(newPrompts)
    if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current)
    saveTimeoutRef.current = setTimeout(() => {
      savePrompts(newPrompts)
    }, 500)
  }

  async function savePrompts(newPrompts: typeof prompts) {
    if (!projectId || !stepType) return
    try {
      const res = await fetch(`/api/projects/${projectId}/steps/${stepType.toLowerCase()}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompts: newPrompts }),
      })
      if (!res.ok) throw new Error('保存失败')
      lastSavedRef.current = newPrompts
      onSaveSuccess?.()
      console.log(`[TEXT-EDIT-${stepType}] 保存 prompts 成功, 数量=${newPrompts.length}`)
    } catch (e: any) {
      console.error(`[TEXT-EDIT-${stepType}] 保存失败:`, e.message)
      setLocalPrompts(lastSavedRef.current)
    }
  }

  function toggleExpand(id: string) {
    setExpandedIds((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id); else next.add(id)
      return next
    })
  }

  const selectedRatio = aspectRatio || '16:9'
  const displayPrompts = editable ? localPrompts : prompts

  return (
    <div className="space-y-4">
      {/* 顶部信息栏 */}
      <div className="flex items-center justify-between rounded-lg border border-amber-200 bg-amber-50 px-4 py-3">
        <div>
          <h3 className="text-sm font-semibold text-amber-800">{title}</h3>
          <p className="mt-0.5 text-xs text-amber-600">已生成提示词，请确认后执行生图</p>
        </div>
        <span className="rounded bg-amber-200 px-2 py-1 text-xs font-medium text-amber-800">
          共 {prompts.length} 条
        </span>
      </div>

      {/* 比例 + 模型 下拉选择栏（风格统一步骤隐藏全局模型选择） */}
      {(onAspectRatioChange || onImageModelChange) && stepLabel !== 'STYLE' && (
        <div className="flex items-center gap-6 border-b border-stone-200 py-4">
          {onAspectRatioChange && (
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-stone-700 whitespace-nowrap">画面比例</span>
              <select
                value={selectedRatio}
                onChange={(e) => onAspectRatioChange(e.target.value)}
                className="rounded-md border border-stone-300 bg-white px-3 py-1.5 text-sm text-stone-700 focus:border-amber-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
              >
                {ASPECT_RATIO_OPTIONS.map(opt => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}（{opt.width}×{opt.height}）
                  </option>
                ))}
              </select>
            </div>
          )}
          {onImageModelChange && (
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-stone-700 whitespace-nowrap">生图模型</span>
              <select
                value={imageModel}
                onChange={(e) => onImageModelChange(e.target.value)}
                className="rounded-md border border-stone-300 bg-white px-3 py-1.5 text-sm text-stone-700 focus:border-amber-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
              >
                {IMAGE_MODEL_OPTIONS.map(opt => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label} — {opt.provider} · {getImageGenerationCost(
                      opt.value,
                      imageCostPerItem,
                      stepLabel === 'STYLE' || stepLabel === 'CONCEPT' ? 'low' : 'medium',
                    )} 点/张 · {opt.desc}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>
      )}
      {/* 风格统一步骤只保留比例选择 */}
      {stepLabel === 'STYLE' && onAspectRatioChange && (
        <div className="flex items-center gap-6 border-b border-stone-200 py-4">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-stone-700 whitespace-nowrap">画面比例</span>
            <select
              value={selectedRatio}
              onChange={(e) => onAspectRatioChange(e.target.value)}
              className="rounded-md border border-stone-300 bg-white px-3 py-1.5 text-sm text-stone-700 focus:border-amber-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
            >
              {ASPECT_RATIO_OPTIONS.map(opt => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}（{opt.width}×{opt.height}）
                </option>
              ))}
            </select>
          </div>
        </div>
      )}

      {/* 提示词卡片网格 */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {displayPrompts.map((p, idx) => {
          const expanded = expandedIds.has(p.id)
          return (
            <div
              key={p.id}
              className="rounded-lg border border-stone-200 bg-white p-4"
            >
              {/* 模型选择下拉（风格统一步骤专属） */}
              {'modelNo' in p && (
                <div className="mb-2 flex items-center justify-between">
                  <span className="text-sm font-medium text-stone-700">风格 {idx + 1}</span>
                  <select
                    value={(p as any).modelNo || 1}
                    onChange={(e) => {
                      const newModelNo = Number(e.target.value)
                      const newPrompts = [...localPrompts]
                      newPrompts[idx] = { ...newPrompts[idx], modelNo: newModelNo }
                      setLocalPrompts(newPrompts)
                      if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current)
                      saveTimeoutRef.current = setTimeout(() => {
                        savePrompts(newPrompts)
                      }, 500)
                    }}
                    className="rounded-full bg-blue-100 px-2 py-0.5 text-xs font-medium text-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-300 cursor-pointer"
                  >
                    {STYLE_MODEL_POOL.map((m) => (
                      <option key={m.no} value={m.no}>
                        {m.label}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* 序号角标 */}
              <div className="mb-2 flex items-center gap-2">
                <span className="rounded bg-stone-800 px-1.5 py-0.5 font-mono text-[10px] font-medium text-white">
                  {idx + 1}/{displayPrompts.length}
                </span>
                <span className="text-xs text-stone-400">{p.target || ''}</span>
              </div>

              {/* 中文描述 — 可编辑 */}
              {editable ? (
                <div className="mb-3">
                  <div className="text-[10px] text-stone-400 mb-1">中文描述</div>
                  <ClickToEdit
                    value={p.chineseDesc}
                    onSave={(newVal) => handleUpdatePrompt(idx, 'chineseDesc', newVal)}
                    className="text-sm font-medium text-stone-800"
                    placeholder="点击添加中文描述..."
                  />
                </div>
              ) : (
                <p className="mb-2 text-sm font-medium text-stone-800">{p.chineseDesc}</p>
              )}

              {/* 英文提示词 — 可编辑 / 可折叠 */}
              {editable ? (
                <div>
                  <div className="text-[10px] text-stone-400 mb-1">英文提示词</div>
                  <ClickToEdit
                    value={p.englishPrompt}
                    onSave={(newVal) => handleUpdatePrompt(idx, 'englishPrompt', newVal)}
                    className="text-xs font-mono text-stone-600"
                    placeholder="点击添加英文提示词..."
                  />
                </div>
              ) : (
                <button
                  onClick={() => toggleExpand(p.id)}
                  className="w-full text-left"
                >
                  <p className={`text-xs leading-relaxed text-stone-400 ${expanded ? '' : 'line-clamp-2'}`}>
                    {p.englishPrompt}
                  </p>
                  <span className="text-[10px] text-stone-300">{expanded ? '收起' : '展开'}</span>
                </button>
              )}
            </div>
          )
        })}
      </div>

      {/* 底部操作栏 */}
      <div className="flex items-center justify-between gap-3 border-t border-stone-200 pt-4">
        <button
          onClick={onRegeneratePrompts}
          disabled={isExecuting}
          className="rounded-lg border border-stone-200 bg-white px-4 py-2 text-sm font-medium text-stone-600 transition hover:bg-stone-50 disabled:opacity-50"
        >
          重新生成提示词
        </button>
        <div className="flex items-center gap-3">
          <div className="relative inline-block">
            <button
              onClick={onConfirm}
              disabled={isExecuting}
              className="flex items-center gap-2 rounded-lg bg-stone-900 px-6 py-2 text-sm font-medium text-white transition hover:bg-stone-800 disabled:opacity-50"
            >
              确认执行
            </button>
            <CostBadge cost={confirmedGenerationCost} />
          </div>
        </div>
      </div>
    </div>
  )
}

/* ============================================================
   带比例管理的提示词预览包装组件（各 Panel 内部使用，免重复 useState）
   ============================================================ */

function PromptPreviewWithRatio({
  prompts,
  title,
  stepLabel,
  defaultRatio,
  defaultModel,
  onConfirm,
  onRegeneratePrompts,
  isExecuting,
  editable,
  projectId,
  stepType,
  onSaveSuccess,
}: {
  prompts: Array<{ id: string; chineseDesc: string; englishPrompt: string; target: string; [key: string]: unknown }>
  title: string
  stepLabel: string
  defaultRatio: string
  defaultModel: string
  onConfirm: (ratio: string, model: string) => void
  onRegeneratePrompts: () => void
  isExecuting: boolean
  editable?: boolean
  projectId?: string
  stepType?: string
  onSaveSuccess?: () => void
}) {
  const [selectedRatio, setSelectedRatio] = useState(defaultRatio)
  const [selectedModel, setSelectedModel] = useState(defaultModel)
  return (
    <PromptPreview
      prompts={prompts}
      title={title}
      stepLabel={stepLabel}
      onConfirm={() => onConfirm(selectedRatio, selectedModel)}
      onRegeneratePrompts={onRegeneratePrompts}
      isExecuting={isExecuting}
      aspectRatio={selectedRatio}
      onAspectRatioChange={setSelectedRatio}
      imageModel={selectedModel}
      onImageModelChange={setSelectedModel}
      editable={editable}
      projectId={projectId}
      stepType={stepType}
      onSaveSuccess={onSaveSuccess}
    />
  )
}

function StyleCard({
  option,
  isSelected,
  onSelect,
  onRegenerate,
  isRegenerating,
  anyRegenerating,
  onModelChange,
}: {
  option: any
  isSelected: boolean
  onSelect: () => void
  onRegenerate?: (aspectRatio: string, imageModel: string) => Promise<void>
  isRegenerating?: boolean
  anyRegenerating?: boolean
  onModelChange?: (modelId: string) => void
}) {
  const [showPrompt, setShowPrompt] = useState(false)
  const [showModelDropdown, setShowModelDropdown] = useState(false)
  const [aspectRatio, setAspectRatio] = useState(1)
  const isMock = !!option.isMock
  // [CARD-HOVER] 从 metadata 读取生成时的比例和模型
  const cardRatio = option.metadata?.aspectRatio || '16:9'
  // 工作指令.txt（2026-05-24）：优先从 modelNo 映射模型简称，旧项目回退到 imageModel
  const cardModelNo = option.metadata?.modelNo
  const cardModelFromPool = cardModelNo ? STYLE_MODEL_POOL.find(m => m.no === cardModelNo) : null
  const defaultModelId = cardModelFromPool?.id || option.metadata?.imageModel || IMAGE_MODELS.primary
  const [selectedModel, setSelectedModel] = useState(defaultModelId)
  const modelShortLabel = MODEL_SHORT_NAME[selectedModel] || selectedModel.split('-')[0]

  // 可用模型列表（排除 disabled 的）
  const availableModels = (IMAGE_MODELS.available as unknown as any[]).filter(m => !m.disabled)

  const handleModelChange = (modelId: string) => {
    setSelectedModel(modelId)
    setShowModelDropdown(false)
    onModelChange?.(modelId)
  }

  return (
    <div
      className={`relative flex flex-col overflow-hidden rounded-lg border-2 transition ${
        isSelected
          ? 'border-amber-500 shadow-md'
          : isMock
          ? 'border-yellow-400 bg-yellow-50/40'
          : 'border-stone-200 bg-white hover:border-stone-400'
      }`}
    >
      {option.imageUrl ? (
        <div
          className="relative w-full cursor-pointer group transition-all duration-300"
          style={{ aspectRatio }}
          onClick={onSelect}
        >
          <HoverImageBadge
            src={proxiedMediaUrl(option.imageUrl)}
            alt={option.styleName}
            aspectRatio={cardRatio}
            imageModel={selectedModel}
            modelShortLabel={modelShortLabel}
            isMock={isMock}
            onClick={onSelect}
            onRegenerate={onRegenerate}
            isRegenerating={isRegenerating}
            anyRegenerating={anyRegenerating}
            onLoad={(w, h) => setAspectRatio(w / h)}
            wrapperClassName="absolute inset-0"
          />
        </div>
      ) : (
        <div
          className="relative w-full cursor-pointer group transition-all duration-300"
          style={{ aspectRatio }}
          onClick={onSelect}
        >
          <div className="absolute inset-0 flex items-center justify-center bg-stone-100 text-stone-400">
            <ImageIcon className="h-8 w-8" />
          </div>
        </div>
      )}
      {isSelected && (
        <div className="absolute right-2 top-2 z-30 flex h-6 w-6 items-center justify-center rounded-full bg-amber-500">
          <Check className="h-4 w-4 text-white" />
        </div>
      )}

      {/* 模型选择交互区（右上角） */}
      {onModelChange && (
        <div className="absolute right-2 top-2 z-20">
          <button
            onClick={(e) => {
              e.stopPropagation()
              setShowModelDropdown((v) => !v)
            }}
            className="flex items-center gap-1 rounded-full bg-black/60 px-2 py-0.5 text-[10px] text-white backdrop-blur-sm transition hover:bg-black/80"
          >
            {modelShortLabel}
            <ChevronDown className="h-2.5 w-2.5" />
          </button>
          {showModelDropdown && (
            <div className="absolute right-0 top-7 w-48 rounded-lg border border-stone-200 bg-white py-1 shadow-lg">
              <div className="px-3 py-1 text-[10px] text-stone-400">选择生图模型</div>
              {availableModels.map((m) => (
                <button
                  key={m.id}
                  onClick={(e) => {
                    e.stopPropagation()
                    handleModelChange(m.id)
                  }}
                  className={`flex w-full items-center justify-between px-3 py-1.5 text-left text-xs transition hover:bg-stone-50 ${
                    selectedModel === m.id ? 'text-amber-600 font-medium' : 'text-stone-700'
                  }`}
                >
                  <span>{m.label}</span>
                  {selectedModel === m.id && <Check className="h-3 w-3" />}
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      <div className="flex flex-1 flex-col p-3">
        <h3 className="text-sm font-semibold text-stone-800">{option.styleName}</h3>
        <p className="mt-1 text-xs leading-relaxed text-stone-500">{option.styleDescription}</p>

        {isMock && (
          <p
            className="mt-2 rounded border border-yellow-300 bg-yellow-50 px-2 py-1 text-[11px] leading-relaxed text-yellow-800"
            title={option.mockReason || ''}
          >
            真实 API 失败,当前为占位图。{option.mockReason ? `(${String(option.mockReason).slice(0, 60)})` : ''}
          </p>
        )}

        {/* 提示词折叠面板 */}
        <button
          onClick={() => setShowPrompt((v) => !v)}
          className="mt-2 flex items-center gap-1 text-xs text-stone-400 transition hover:text-stone-600"
        >
          {showPrompt ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
          {showPrompt ? '隐藏提示词' : '查看提示词'}
        </button>
        {showPrompt && (
          <div className="mt-2 rounded bg-stone-50 p-2">
            <p className="break-words text-[11px] leading-relaxed text-stone-500">{option.prompt}</p>
          </div>
        )}

        <div className="mt-3 flex-1" />
        <button
          onClick={onSelect}
          disabled={isSelected}
          className={`w-full rounded-md px-3 py-1.5 text-xs font-medium transition ${
            isSelected
              ? 'bg-amber-50 text-amber-700'
              : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
          } disabled:cursor-not-allowed`}
        >
          {isSelected ? '✓ 已选为基准' : '选为基准'}
        </button>
      </div>
    </div>
  )
}

function CharacterPanel({
  step,
  project,
  projectId,
  executing,
  onExecute,
  onError,
  mutate,
  setToast,
  readOnly,
}: {
  step: any
  project: any
  projectId: string
  executing: string | null
  onExecute: (stepType: string, body?: any) => void
  onError: (msg: string | null) => void
  mutate: () => Promise<any>
  setToast: (t: { kind: 'success' | 'error'; message: string } | null) => void
  readOnly?: boolean
}) {
  const assets = step.resultAssets || []
  const isExecuting = executing === step.stepType
  const [regeneratingId, setRegeneratingId] = useState<string | null>(null)
  const [showConfirmAll, setShowConfirmAll] = useState(false)
  const [generatingAct, setGeneratingAct] = useState<number | null>(null)
  const [ratios, setRatios] = useState<Record<string, number>>({})
  const [expandedPromptIds, setExpandedPromptIds] = useState<Set<string>>(new Set())
  const [dragOverCharacterId, setDragOverCharacterId] = useState<string | null>(null)
  const [assigningCharacterId, setAssigningCharacterId] = useState<string | null>(null)
  const [justAssignedCharacterId, setJustAssignedCharacterId] = useState<string | null>(null)
  const promptSaveTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const lastSavedPromptsRef = useRef<any[]>(step.outputData?.prompts || [])

  const assignReferenceToCharacter = useCallback(async (input: {
    characterId: string
    assetId?: string
    referenceAssetId?: string
    referenceUrl: string
  }) => {
    setAssigningCharacterId(input.characterId)
    try {
      const res = await fetch(`/api/projects/${projectId}/steps/character/assign-reference`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(input),
      })
      const data = await res.json().catch(() => ({}))
      if (!res.ok || !data.success) {
        throw new Error(data.message || data.error || `HTTP ${res.status}`)
      }
      setJustAssignedCharacterId(input.characterId)
      setTimeout(() => setJustAssignedCharacterId((prev) => prev === input.characterId ? null : prev), 2200)
      setToast?.({ kind: 'success', message: '参考图已设为角色图' })
      await mutate()
    } catch (e: any) {
      onError('设置角色参考图失败：' + (e?.message || e))
    } finally {
      setAssigningCharacterId(null)
    }
  }, [projectId, mutate, onError, setToast])

  useEffect(() => {
    function findCharacterFromEl(el: Element | null): { characterId: string | null; assetId?: string } {
      let cur: Element | null = el
      while (cur && cur !== document.body) {
        const ds = (cur as HTMLElement).dataset
        if (ds?.characterId) return { characterId: ds.characterId, assetId: ds.characterAssetId }
        cur = cur.parentElement
      }
      return { characterId: null }
    }

    function handleDragMove(e: any) {
      const el = document.elementFromPoint(e.detail?.clientX || 0, e.detail?.clientY || 0)
      const { characterId } = findCharacterFromEl(el)
      setDragOverCharacterId((prev) => prev === characterId ? prev : characterId)
    }

    function handleCustomDrop(e: any) {
      const item = e.detail?.item
      const el = document.elementFromPoint(e.detail?.clientX || 0, e.detail?.clientY || 0)
      const { characterId, assetId } = findCharacterFromEl(el)
      if (characterId && item?.url) {
        assignReferenceToCharacter({ characterId, assetId, referenceAssetId: item.id, referenceUrl: item.url })
      }
      setDragOverCharacterId(null)
    }

    function handleDragEnd() {
      setDragOverCharacterId(null)
    }

    window.addEventListener('customdragmove', handleDragMove as EventListener)
    window.addEventListener('customdrop', handleCustomDrop as EventListener)
    window.addEventListener('customdragend', handleDragEnd as EventListener)
    return () => {
      window.removeEventListener('customdragmove', handleDragMove as EventListener)
      window.removeEventListener('customdrop', handleCustomDrop as EventListener)
      window.removeEventListener('customdragend', handleDragEnd as EventListener)
    }
  }, [assignReferenceToCharacter])

  // PROMPT_READY：提示词预览（必须在 PROCESSING 之前判断）
  if (step.status === 'PENDING' && step.outputData?.prompts?.length > 0) {
    const defaultRatio = step.outputData?.aspectRatio || project.selectedAspectRatio || '16:9'
    const defaultModel = IMAGE_MODELS.primary
    return (
      <PromptPreviewWithRatio
        prompts={step.outputData.prompts}
        title="人物设计提示词预览"
        stepLabel="CHARACTER"
        defaultRatio={defaultRatio}
        defaultModel={defaultModel}
        onConfirm={(ratio, model) => onExecute('CHARACTER', { action: 'generate-images', aspectRatio: ratio, imageModel: model })}
        onRegeneratePrompts={() => onExecute('CHARACTER', { action: 'generate-prompts' })}
        isExecuting={isExecuting}
        editable={!readOnly}
        projectId={projectId}
        stepType="CHARACTER"
        onSaveSuccess={() => mutate()}
      />
    )
  }

  if (step.status === 'PROCESSING' || isExecuting) {
    return (
      <div className="flex flex-col items-center justify-center py-16 gap-4">
        <LoaderCircle className="h-8 w-8 animate-spin text-stone-400" />
        <p className="text-sm text-stone-500">正在生成角色设计...</p>
        <button
          onClick={async () => {
            try {
              const res = await fetch(`/api/projects/${projectId}/steps/character/sync-status`, { method: 'POST' })
              const data = await res.json()
              if (data.synced) {
                await mutate()
                if (data.timedOut) {
                  setToast?.({ kind: 'error', message: `超时未完成（${data.actualCount}/${data.expectedCount}），已保存现有结果` })
                } else {
                  setToast?.({ kind: 'success', message: '状态已同步' })
                }
              } else if (data.actualCount < data.expectedCount) {
                setToast?.({ kind: 'error', message: `生成中（${data.actualCount}/${data.expectedCount}），请稍后再试` })
              } else {
                await mutate()
              }
            } catch (e: any) {
              setToast?.({ kind: 'error', message: '刷新失败：' + e.message })
            }
          }}
          disabled={isExecuting}
          className="flex items-center gap-1.5 rounded-lg border border-stone-200 px-3 py-1.5 text-xs font-medium text-stone-500 transition hover:bg-stone-50 disabled:opacity-50"
        >
          <RefreshCw className="h-3 w-3" />
          刷新状态
        </button>
      </div>
    )
  }

  if (step.status === 'PENDING') {
    return (
      <div className="flex flex-col items-center justify-center gap-6 py-12">
        <div className="text-center">
          <ImageIcon className="mx-auto h-10 w-10 text-stone-300" />
          <p className="mt-3 text-sm text-stone-500">将基于框架设定为每个角色生成人像</p>
        </div>
        <div className="relative inline-block">
          <button
            onClick={() => onExecute('CHARACTER', { action: 'generate-prompts' })}
            disabled={isExecuting}
            className="flex items-center gap-2 rounded-lg bg-stone-900 px-6 py-3 text-sm font-medium text-white transition hover:bg-stone-800 disabled:opacity-50"
          >
            {isExecuting ? (
              <><LoaderCircle className="h-4 w-4 animate-spin" />生成中...</>
            ) : (
              <><Play className="h-4 w-4" />开始执行</>
            )}
          </button>
          <CostBadge cost={DEFAULT_GENERATE_COST} />
        </div>
      </div>
    )
  }

  async function handleRegenerate(assetId?: string, characterId?: string, aspectRatio?: string, imageModel?: string) {
    const id = assetId || characterId
    if (!id) return
    setRegeneratingId(id)
    try {
      const res = await fetch(`/api/projects/${projectId}/steps/character/regenerate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ assetId, characterId, aspectRatio, imageModel }),
      })
      const data = await res.json()
      if (!res.ok || !data.success) throw new Error(data.message || `HTTP ${res.status}`)
      await mutate()
      if (data.isMock) {
        setToast({ kind: 'error', message: data.warning || '当前模型不可用，返回了占位图，请切换模型重试' })
      } else {
        setToast({ kind: 'success', message: '角色已重新生成' })
      }
    } catch (e: any) {
      onError('重新生成失败：' + e?.message)
    } finally {
      setRegeneratingId(null)
    }
  }

  // Round 6 Phase 2+5：英文提示词展开/折叠
  function togglePromptExpand(assetId: string) {
    setExpandedPromptIds((prev) => {
      const next = new Set(prev)
      if (next.has(assetId)) next.delete(assetId); else next.add(assetId)
      return next
    })
  }

  // Round 6 Phase 5：编辑英文提示词并保存到 workflowStep.outputData.prompts
  function handleUpdatePrompt(characterId: string, newPrompt: string) {
    const existingPrompts = step.outputData?.prompts || []
    const idx = existingPrompts.findIndex((p: any) => p.characterId === characterId)
    if (idx < 0) return
    const newPrompts = [...existingPrompts]
    newPrompts[idx] = { ...newPrompts[idx], englishPrompt: newPrompt }
    if (promptSaveTimeoutRef.current) clearTimeout(promptSaveTimeoutRef.current)
    promptSaveTimeoutRef.current = setTimeout(() => {
      savePrompts(newPrompts)
    }, 500)
  }

  async function savePrompts(newPrompts: any[]) {
    try {
      const res = await fetch(`/api/projects/${projectId}/steps/character`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompts: newPrompts }),
      })
      if (!res.ok) throw new Error('保存失败')
      lastSavedPromptsRef.current = newPrompts
      await mutate()
      console.log('[TEXT-EDIT-CHARACTER-CARD] 保存 prompts 成功, 数量=', newPrompts.length)
    } catch (e: any) {
      console.error('[TEXT-EDIT-CHARACTER-CARD] 保存失败:', e.message)
    }
  }

  return (
    <div className="space-y-4">
      {(() => {
        const failedCount = (step.outputData?.failedCharacters || []).length
        return (
          <p className="text-sm text-stone-600">
            已生成 {assets.length} 个角色人像
            {failedCount > 0 && (
              <span className="ml-2 text-xs text-red-500">（{failedCount} 个生成失败，可点击下方失败卡片单独重试）</span>
            )}
          </p>
        )
      })()}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-3">
        {assets.map((asset: any) => {
          const isRegenerating = regeneratingId === asset.id
          const characterId = asset.metadata?.characterId
          const isDragTarget = characterId && dragOverCharacterId === characterId
          const isAssigning = characterId && assigningCharacterId === characterId
          const justAssigned = characterId && justAssignedCharacterId === characterId
          const cardRatio = asset.metadata?.aspectRatio || '16:9'
          // 默认 gpt-image-1（除非用户手动选择其他模型）
          const cardModel = IMAGE_MODELS.primary
          return (
            <div
              key={asset.id}
              data-character-id={characterId || ''}
              data-character-asset-id={asset.id}
              className={`group relative overflow-hidden rounded-lg border bg-white transition ${
                isDragTarget ? 'border-emerald-400 ring-2 ring-emerald-200' : 'border-stone-200'
              }`}
            >
              <div
                className="relative w-full bg-stone-100 transition-all duration-300"
                style={{ aspectRatio: ratios[asset.id] || 1 }}
              >
                <HoverImageBadge
                  src={proxiedMediaUrl(asset.url)}
                  alt={asset.metadata?.characterName}
                  aspectRatio={cardRatio}
                  imageModel={cardModel}
                  isMock={!!asset.metadata?.isMock}
                  onRegenerate={(ar, model) => handleRegenerate(asset.id, undefined, ar, model)}
                  isRegenerating={isRegenerating}
                  anyRegenerating={!!regeneratingId}
                  onLoad={(w, h) => setRatios(prev => ({ ...prev, [asset.id]: w / h }))}
                  wrapperClassName="absolute inset-0"
                />
                {(isAssigning || justAssigned) && (
                  <div className="absolute inset-0 z-30 flex items-center justify-center bg-emerald-50/80 text-xs font-medium text-emerald-700">
                    {isAssigning ? <LoaderCircle className="mr-1.5 h-3.5 w-3.5 animate-spin" /> : <Check className="mr-1.5 h-3.5 w-3.5" />}
                    {isAssigning ? '设置中' : '已替换'}
                  </div>
                )}
              </div>
              <div className="p-3">
                <p className="text-sm font-medium text-stone-800">
                  {asset.metadata?.characterName}
                </p>
                <p className="text-xs text-stone-400 line-clamp-2">
                  {asset.metadata?.chineseDesc || asset.metadata?.characterId}
                </p>
                {/* Round 6 Phase 2+5：可展开/可编辑的英文提示词 */}
                {asset.metadata?.llmPrompt && (
                  <div className="mt-2">
                    <button
                      onClick={() => togglePromptExpand(asset.id)}
                      className="flex items-center gap-1 text-[11px] text-stone-400 hover:text-stone-600 transition"
                    >
                      <span>英文提示词</span>
                      <span>{expandedPromptIds.has(asset.id) ? '▲' : '▼'}</span>
                    </button>
                    {expandedPromptIds.has(asset.id) && (
                      <div className="mt-1">
                        <ReadOrEdit
                          readOnly={readOnly}
                          value={asset.metadata?.llmPrompt || ''}
                          onSave={(newVal) => handleUpdatePrompt(asset.metadata?.characterId, newVal)}
                          className="text-[11px] font-mono text-stone-500 leading-relaxed"
                          placeholder="双击编辑英文提示词..."
                        />
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )
        })}

        {/* 生成失败的角色卡片：保留并允许单独重新生成 */}
        {(() => {
          const failed: any[] = step.outputData?.failedCharacters || []
          const existingCharacterIds = new Set(
            assets.map((a: any) => a.metadata?.characterId).filter(Boolean)
          )
          const pendingFailed = failed.filter((f: any) => !existingCharacterIds.has(f.characterId))
          return pendingFailed.map((f: any) => {
            const isRetrying = regeneratingId === f.characterId
            const isDragTarget = dragOverCharacterId === f.characterId
            const isAssigning = assigningCharacterId === f.characterId
            const justAssigned = justAssignedCharacterId === f.characterId
            return (
              <div
                key={`failed-${f.characterId}`}
                data-character-id={f.characterId}
                className={`relative overflow-hidden rounded-lg border bg-red-50 transition ${
                  isDragTarget ? 'border-emerald-400 ring-2 ring-emerald-200' : 'border-red-100'
                }`}
              >
                <div
                  className="relative flex w-full flex-col items-center justify-center gap-2 bg-red-100/50 p-4 text-center"
                  style={{ aspectRatio: project.selectedAspectRatio || '16:9' }}
                >
                  <ImageIcon className="h-8 w-8 text-red-300" />
                  <p className="text-xs text-red-400">生成失败</p>
                  {(isAssigning || justAssigned) && (
                    <div className="absolute inset-0 z-30 flex items-center justify-center bg-emerald-50/85 text-xs font-medium text-emerald-700">
                      {isAssigning ? (
                        <LoaderCircle className="mr-1.5 h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <Check className="mr-1.5 h-3.5 w-3.5" />
                      )}
                      {isAssigning ? '设置中' : '已设置'}
                    </div>
                  )}
                </div>
                <div className="p-3">
                  <p className="text-sm font-medium text-stone-800">{f.characterName}</p>
                  <p className="text-xs text-stone-500 line-clamp-2">{f.chineseDesc || f.role}</p>
                  <button
                    onClick={() => handleRegenerate(undefined, f.characterId, project.selectedAspectRatio)}
                    disabled={isRetrying || !!regeneratingId}
                    className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-md bg-stone-900 px-3 py-1.5 text-xs font-medium text-white transition hover:bg-stone-800 disabled:opacity-50"
                  >
                    {isRetrying ? (
                      <><LoaderCircle className="h-3 w-3 animate-spin" />重新生成中...</>
                    ) : (
                      <><RefreshCw className="h-3 w-3" />重新生成</>
                    )}
                  </button>
                </div>
              </div>
            )
          })
        })()}
      </div>

      {step.status === 'COMPLETED' && assets.length > 0 && (
        <div className="pt-4 border-t border-stone-100">
          {!showConfirmAll ? (
            <button
              onClick={() => setShowConfirmAll(true)}
              disabled={isExecuting}
              className="flex items-center justify-center gap-2 w-full rounded-lg border border-stone-200 bg-white px-4 py-2.5 text-sm font-medium text-stone-600 transition hover:bg-stone-50 hover:text-stone-800 disabled:opacity-50"
            >
              <RefreshCw className="h-4 w-4" />
              重新生成全部角色
            </button>
          ) : (
            <div className="rounded-lg border border-amber-200 bg-amber-50 p-4">
              <p className="text-sm font-medium text-stone-800">确定要重新生成全部 {assets.length} 个角色吗？</p>
              <p className="mt-1 text-xs text-stone-500">这会覆盖现有内容，此操作不可撤销。</p>
              <div className="mt-3 flex gap-2">
                <button
                  onClick={() => setShowConfirmAll(false)}
                  className="rounded-md border border-stone-200 bg-white px-4 py-1.5 text-sm text-stone-600 transition hover:bg-stone-50"
                >取消</button>
                <div className="relative inline-block">
                  <button
                    onClick={() => { setShowConfirmAll(false); onExecute('CHARACTER', { force: true }) }}
                    disabled={isExecuting}
                    className="flex items-center gap-1.5 rounded-md bg-amber-600 px-4 py-1.5 text-sm font-medium text-white transition hover:bg-amber-700 disabled:opacity-50"
                  >
                    {isExecuting ? (
                      <><LoaderCircle className="h-3.5 w-3.5 animate-spin" />生成中...</>
                    ) : '确认重做'}
                  </button>
                  <CostBadge cost={DEFAULT_GENERATE_COST} />
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

function ConceptPanel({
  step,
  project,
  projectId,
  executing,
  onExecute,
  onError,
  mutate,
  setToast,
  readOnly,
  onRetryReady,
}: {
  step: any
  project: any
  projectId: string
  executing: string | null
  onExecute: (stepType: string, body?: any) => void
  onError: (msg: string | null) => void
  mutate: () => Promise<any>
  setToast: (t: { kind: 'success' | 'error'; message: string } | null) => void
  readOnly?: boolean
  /** 组件挂载时传入 startGeneration 函数，供父组件在重试时调用 */
  onRetryReady?: (fn: (totalScenes: number, aspectRatio: string, imageModel: string) => void) => void
}) {
  const assets = step.resultAssets || []
  const isExecuting = executing === step.stepType
  const [regeneratingId, setRegeneratingId] = useState<string | null>(null)
  const [showConfirmAll, setShowConfirmAll] = useState(false)
  const [ratios, setRatios] = useState<Record<string, number>>({})
  // 前端驱动分批生成状态
  const [generatingIndex, setGeneratingIndex] = useState<number | null>(null)
  const [generatingAct, setGeneratingAct] = useState<number | null>(null)
  const [localAssets, setLocalAssets] = useState<any[]>(() =>
    step.status === 'PROCESSING' ? (step.resultAssets || []) : []
  )

  const startGeneration = async (totalScenes: number, aspectRatio: string, imageModel: string) => {
    const outputData = (step.outputData as any) || {}
    const prompts: any[] = outputData.prompts || []
    const actNumberSet = new Set(prompts.map((p: any) => p.actNumber))
    const actNumbers = Array.from(actNumberSet).sort()
    if (actNumbers.length === 0) return

    setGeneratingIndex(0)
    setLocalAssets([])

    for (const actNumber of actNumbers) {
      fetch(`/api/projects/${projectId}/steps/concept/generate-one`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ actNumber, aspectRatio, imageModel }),
      }).catch(() => {})
    }
    setToast?.({ kind: 'success', message: '概念图生成中，稍后刷新页面查看进度' })
  }

  // 触发单个幕的生成（按钮专用，不影响其他幕）
  async function triggerActGenerate(actNumber: number, aspectRatio: string, imageModel: string) {
    setGeneratingAct(actNumber)
    setToast?.({ kind: 'success', message: `第 ${actNumber} 幕生成中` })
    try {
      const res = await fetch(`/api/projects/${projectId}/steps/concept/generate-one`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ actNumber, aspectRatio, imageModel }),
      })
      console.log('[triggerActGenerate] response status:', res.status, 'actNumber:', actNumber)
      const data = await res.json().catch(() => ({}))
      console.log('[triggerActGenerate] response data:', JSON.stringify(data))
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}: ${data?.error || data?.message || '未知错误'}`)
      }
      // 强制 revalidate，绕过 SWR 缓存直接拉最新数据
      await mutate()
      setToast?.({ kind: 'success', message: `第 ${actNumber} 幕已生成` })
    } catch (e: any) {
      console.error('[triggerActGenerate] failed:', e?.message)
      onError?.(`第 ${actNumber} 幕生成失败：` + e?.message)
    } finally {
      setGeneratingAct(null)
    }
  }

  // 挂载时注册到 window，供父组件 StepHeader 调用
  useEffect(() => {
    (window as any).__conceptRetry = startGeneration
    return () => { delete (window as any).__conceptRetry }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // PROCESSING 时每 30s 自动刷新一次数据
  useEffect(() => {
    if (step.status !== 'PROCESSING') return
    const id = setInterval(() => mutate(), 30000)
    return () => clearInterval(id)
  }, [step.status, mutate])

  if (step.status === 'PROCESSING' || isExecuting) {
    return (
      <div className="flex flex-col items-center justify-center gap-4 py-16 text-center">
        <LoaderCircle className="h-10 w-10 animate-spin text-blue-400" />
        <div>
          <p className="text-sm font-medium text-stone-600">概念图生成中</p>
          <p className="mt-1 text-xs text-stone-400">每幕预计 2-5 分钟，生成完成后自动更新</p>
        </div>
        <button
          onClick={() => mutate()}
          className="rounded-lg border border-stone-200 bg-white px-4 py-2 text-sm text-stone-600 transition hover:bg-stone-50"
        >
          立即刷新
        </button>
      </div>
    )
  }
    // PROMPT_READY：提示词预览（必须在 PENDING 之前判断）
  if (step.status === 'PENDING' && step.outputData?.prompts?.length > 0) {
    const defaultRatio = step.outputData?.aspectRatio || project.selectedAspectRatio || '16:9'
    const defaultModel = IMAGE_MODELS.primary
    return (
      <PromptPreviewWithRatio
        prompts={step.outputData.prompts}
        title="概念图提示词预览"
        stepLabel="CONCEPT"
        defaultRatio={defaultRatio}
        defaultModel={defaultModel}
        onConfirm={(ratio, model) => {
          // 发送全部 202 请求 + 轮询
          startGeneration(step.outputData.prompts.length, ratio, model)
        }}
        onRegeneratePrompts={() => onExecute('CONCEPT', { action: 'generate-prompts' })}
        isExecuting={isExecuting}
        editable={!readOnly}
        projectId={projectId}
        stepType="CONCEPT"
        onSaveSuccess={() => mutate()}
      />
    )
  }

  // PENDING 状态显示生成按钮
  if (step.status === 'PENDING') {
    return (
      <div className="flex flex-col items-center justify-center gap-6 py-12">
        <div className="text-center">
          <ImageIcon className="mx-auto h-10 w-10 text-stone-300" />
          <p className="mt-3 text-sm text-stone-500">将基于框架设定生成各幕场景概念图</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative inline-block">
            <button
              onClick={() => onExecute('CONCEPT', { action: 'generate-prompts' })}
              disabled={isExecuting}
              className="flex items-center gap-2 rounded-lg bg-stone-900 px-6 py-3 text-sm font-medium text-white transition hover:bg-stone-800 disabled:opacity-50"
            >
              <Play className="h-4 w-4" />
              生成概念图
            </button>
            <CostBadge cost={DEFAULT_GENERATE_COST} />
          </div>
        </div>
      </div>
    )
  }

  const grouped = assets.reduce(
    (acc: Record<string, any[]>, asset: any) => {
      const act = asset.metadata?.actNumber || 0
      if (!acc[act]) acc[act] = []
      acc[act].push(asset)
      return acc
    },
    {}
  )

  async function handleRegenerate(assetId: string, aspectRatio?: string, imageModel?: string) {
    setRegeneratingId(assetId)
    console.log('[CONCEPT-REGENERATE-UI] 点击重做:', assetId)
    try {
      const res = await fetch(`/api/projects/${projectId}/steps/concept/regenerate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ assetId, aspectRatio, imageModel }),
      })
      const data = await res.json()
      if (!res.ok || !data.success) {
        throw new Error(data.message || `HTTP ${res.status}`)
      }
      // 触发全局数据刷新
      await mutate()
      setToast?.({ kind: 'success', message: '概念图已重新生成' })
    } catch (e: any) {
      console.error('[CONCEPT-REGENERATE-UI] 失败:', e?.message)
      onError?.('重新生成失败：' + e?.message)
    } finally {
      setRegeneratingId(null)
    }
  }

  async function handleRegenerateAll() {
    setShowConfirmAll(false)
    setLocalAssets([])
    const defaultRatio = (step.outputData as any)?.aspectRatio || project.selectedAspectRatio || '16:9'
    const defaultModel = (step.outputData as any)?.imageModel || IMAGE_MODELS.primary
    const totalScenes = (step.outputData as any)?.prompts?.length || 6
    // 调用主 API 的 force 路径删除旧资产（不等待完成）
    fetch(`/api/projects/${projectId}/steps/concept`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ force: true }),
    }).catch(() => {})
    // 立即触发新生成
    startGeneration(totalScenes, defaultRatio, defaultModel)
  }
  // 从 prompts 按 actNumber 分组，展示每幕的生成状态和按钮
  const outputData = (step.outputData as any) || {}
  const prompts: any[] = (outputData.prompts || []).map((p: any, i: number) => ({ ...p, _idx: i }))
  const actNumberSet = new Set(prompts.map((p: any) => p.actNumber))
  const actNumbers = Array.from(actNumberSet).sort((a, b) => a - b)

  // 提取每幕已有图片（按 sceneIndex 索引）
  const assetIndexMap: Record<number, Record<number, any>> = {}
  for (const asset of assets) {
    const act = asset.metadata?.actNumber ?? 0
    const idx = asset.metadata?.sceneIndex ?? 0
    if (!assetIndexMap[act]) assetIndexMap[act] = {}
    assetIndexMap[act][idx] = asset
  }

  const defaultRatio = outputData.aspectRatio || project.selectedAspectRatio || '16:9'
  const defaultModel = outputData.imageModel || IMAGE_MODELS.primary

  return (
    <div className="space-y-6">
      {actNumbers.map((actNumber: number) => {
        const actImages = assetIndexMap[actNumber] || {}
        const actPrompts = prompts.filter((p: any) => p.actNumber === actNumber)
        const isGeneratingThisAct = generatingAct === actNumber
        const hasAnyImage = Object.keys(actImages).length > 0
        return (
          <div key={actNumber}>
            <div className="mb-3 flex items-center justify-between">
              <h3 className="text-sm font-semibold text-stone-700">
                第 {actNumber} 幕
              </h3>
              <button
                onClick={() => triggerActGenerate(actNumber, defaultRatio, defaultModel)}
                disabled={isGeneratingThisAct || isExecuting}
                className="flex items-center gap-1.5 rounded-md bg-stone-800 px-3 py-1.5 text-xs font-medium text-white transition hover:bg-stone-700 disabled:opacity-50"
              >
                {isGeneratingThisAct ? (
                  <>
                    <LoaderCircle className="h-3 w-3 animate-spin" />
                    生成中...
                  </>
                ) : (
                  <>
                    <Play className="h-3 w-3" />
                    {hasAnyImage ? '追加生成' : '生成'}
                  </>
                )}
              </button>
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {actPrompts.map((promptItem: any) => {
                const asset = actImages[promptItem._idx]
                if (!asset) {
                  return (
                    <div key={promptItem._idx} className="group relative overflow-hidden rounded-lg border border-dashed border-stone-300 bg-stone-50">
                      <div className="relative flex w-full flex-col items-center justify-center" style={{ aspectRatio: defaultRatio }}>
                        <span className="text-xs text-stone-400">待生成</span>
                        <span className="mt-1 max-w-[90%] truncate px-2 text-xs text-stone-400">
                          {promptItem.sceneDesc?.slice(0, 50) || promptItem.englishPrompt?.slice(0, 50)}
                        </span>
                      </div>
                    </div>
                  )
                }
                const isRegenerating = regeneratingId === asset.id
                const cardRatio = asset.metadata?.aspectRatio || '16:9'
                // 默认 gpt-image-1（除非用户手动选择其他模型）
                const cardModel = IMAGE_MODELS.primary
                return (
                  <div key={asset.id} className="group relative overflow-hidden rounded-lg border border-stone-200">
                    <div className="relative w-full bg-stone-100 transition-all duration-300" style={{ aspectRatio: ratios[asset.id] || 1.78 }}>
                      <HoverImageBadge
                        src={proxiedMediaUrl(asset.url)}
                        alt={asset.metadata?.sceneDesc}
                        aspectRatio={cardRatio}
                        imageModel={cardModel}
                        isMock={!!asset.metadata?.isMock}
                        onRegenerate={(ar, model) => handleRegenerate(asset.id, ar, model)}
                        isRegenerating={isRegenerating}
                        anyRegenerating={!!regeneratingId}
                        onLoad={(w, h) => setRatios(prev => ({ ...prev, [asset.id]: w / h }))}
                        wrapperClassName="absolute inset-0"
                      />
                    </div>
                    <p className="p-3 text-xs text-stone-500">
                      {asset.metadata?.sceneDesc || asset.metadata?.llmPrompt?.slice(0, 60)}
                    </p>
                  </div>
                )
              })}
            </div>
          </div>
        )
      })}

      {/* 整体重做 */}
      {step.status === 'COMPLETED' && assets.length > 0 && (
        <div className="pt-4 border-t border-stone-100">
          {!showConfirmAll ? (
            <button
              onClick={() => setShowConfirmAll(true)}
              disabled={isExecuting}
              className="flex items-center justify-center gap-2 w-full rounded-lg border border-stone-200 bg-white px-4 py-2.5 text-sm font-medium text-stone-600 transition hover:bg-stone-50 hover:text-stone-800 disabled:opacity-50"
            >
              <RefreshCw className="h-4 w-4" />
              重新生成全部概念图
            </button>
          ) : (
            <div className="rounded-lg border border-amber-200 bg-amber-50 p-4">
              <p className="text-sm font-medium text-stone-800">
                确定要重新生成全部 {assets.length} 张概念图吗？
              </p>
              <p className="mt-1 text-xs text-stone-500">
                这会覆盖现有内容，此操作不可撤销。
              </p>
              <div className="mt-3 flex gap-2">
                <button
                  onClick={() => setShowConfirmAll(false)}
                  className="rounded-md border border-stone-200 bg-white px-4 py-1.5 text-sm text-stone-600 transition hover:bg-stone-50"
                >
                  取消
                </button>
                <div className="relative inline-block">
                  <button
                    onClick={handleRegenerateAll}
                    disabled={isExecuting}
                    className="flex items-center gap-1.5 rounded-md bg-amber-600 px-4 py-1.5 text-sm font-medium text-white transition hover:bg-amber-700 disabled:opacity-50"
                  >
                    {isExecuting ? (
                      <>
                        <LoaderCircle className="h-3.5 w-3.5 animate-spin" />
                        生成中...
                      </>
                    ) : (
                      '确认重做'
                    )}
                  </button>
                  <CostBadge cost={DEFAULT_GENERATE_COST} />
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
function StoryboardMockImage({ shot }: { shot: any }) {
  return (
    <div
      className="relative flex w-full flex-col items-center justify-center overflow-hidden rounded border-2 border-dashed border-stone-300 bg-stone-100"
      style={{ aspectRatio: '16/9' }}
    >
      <span className="font-mono text-sm font-bold text-stone-600">{shot.shotId || ''}</span>
      <span className="mt-1 max-w-[90%] truncate px-2 text-xs text-stone-400">
        {(shot.sceneName || '').slice(0, 14)}
      </span>
      <span className="mt-2 rounded bg-stone-200 px-2 py-0.5 text-[10px] text-stone-400">
        待生成
      </span>
    </div>
  )
}

function StoryboardPanel({
  step,
  project,
  projectId,
  executing,
  onExecute,
  onError,
  mutate,
  setToast,
  storyboardMode,
  setStoryboardMode,
  readOnly,
  framework,
}: {
  step: any
  project: any
  projectId: string
  executing: string | null
  onExecute: (stepType: string, body?: any) => void
  onError: (msg: string | null) => void
  mutate: () => Promise<any>
  setToast: (t: { kind: 'success' | 'error'; message: string } | null) => void
  storyboardMode?: 'reference' | 'keyframe'
  setStoryboardMode?: (mode: 'reference' | 'keyframe') => void
  readOnly?: boolean
  framework?: any
}) {
  const shots = useMemo(
    () => (step.outputData?.shots || []).map((shot: any) => ({
      ...shot,
      actNumber: normalizeOptionalInt(shot.actNumber),
    })),
    [step.outputData?.shots]
  )
  const shotAssets = useMemo(
    () => (step.resultAssets || []).map((asset: any) => ({
      ...asset,
      metadata: asset.metadata
        ? { ...asset.metadata, actNumber: normalizeOptionalInt(asset.metadata.actNumber) }
        : asset.metadata,
    })),
    [step.resultAssets]
  )
  const isExecuting = executing === step.stepType
  const [regeneratingId, setRegeneratingId] = useState<string | null>(null)
  const [showConfirmAll, setShowConfirmAll] = useState(false)
  const [confirmingShotId, setConfirmingShotId] = useState<string | null>(null)
  const [localGeneratingShots, setLocalGeneratingShots] = useState<Record<string, any>>({})
  const generatingShots: Record<string, any> = {
    ...(step.outputData?.generatingShots || {}),
    ...localGeneratingShots,
  }

  useEffect(() => {
    const handleGenerationState = (event: Event) => {
      const detail = (event as CustomEvent<{ key?: string; state?: Record<string, any> }>).detail
      if (!detail?.key || !detail.state) return
      setLocalGeneratingShots((current) => ({ ...current, [detail.key!]: detail.state }))
    }
    window.addEventListener('storyboard-generation-state', handleGenerationState)
    return () => window.removeEventListener('storyboard-generation-state', handleGenerationState)
  }, [])

  // [DRAG-REF] 用户拖入到分镜卡片的额外参考图（key = `${shotId}_${actNumber}` 或仅 shotId）
// 从 outputData.shotExtraRefs 初始化，刷新后保留
  const persistedExtraRefs: Record<string, Array<{ url: string; id?: string }>> = step.outputData?.shotExtraRefs || {}
  const [shotExtraRefs, setShotExtraRefs] = useState<Record<string, { url: string; id?: string }[]>>(persistedExtraRefs)
  const [dragOverShotId, setDragOverShotId] = useState<string | null>(null)
  const [justDroppedShotId, setJustDroppedShotId] = useState<string | null>(null)

  // 当 outputData.shotExtraRefs 从服务器更新时（如 mutate 后），同步本地 state
  useEffect(() => {
    setShotExtraRefs(step.outputData?.shotExtraRefs || {})
  }, [step.outputData?.shotExtraRefs])

  // [DRAG-REF] 监听 useDragRef 的自定义事件，通过 elementFromPoint + DOM 向上查找命中哪个 shot
  useEffect(() => {
    function findShotShotIdFromEl(el: Element | null): string | null {
      while (el && el !== document.body) {
        const id = (el as HTMLElement).dataset?.shotId
        if (id) return id
        el = el.parentElement
      }
      return null
    }
    function findShotShotIdAndActFromEl(el: Element | null): { shotId: string | null; actNumber: number | null } {
      // DOM 向上查找同时带有 data-shot-id 和 data-shot-act 的最近祖先，
      // 这样可以正确处理不同幕中相同 shotId 的情况。
      let cur: Element | null = el
      while (cur && cur !== document.body) {
        const dsid = (cur as HTMLElement).dataset?.shotId
        const dsact = (cur as HTMLElement).dataset?.shotAct
        if (dsid && dsact && dsact !== '') {
          const parsed = parseInt(dsact, 10)
          if (!isNaN(parsed)) return { shotId: dsid, actNumber: parsed }
        }
        cur = cur.parentElement
      }
      // 兜底：data-shot-act 缺失时退回到 shots.find（老项目兼容）
      const shotId = findShotShotIdFromEl(el)
      if (!shotId) return { shotId: null, actNumber: null }
      const shot = shots.find((s: any) => s.shotId === shotId)
      return { shotId, actNumber: shot?.actNumber ?? null }
    }
    function handleDragMove(e: any) {
      const x = e.detail?.clientX || 0
      const y = e.detail?.clientY || 0
      const el = document.elementFromPoint(x, y)
      const shotId = findShotShotIdFromEl(el)
      setDragOverShotId(prev => prev === shotId ? prev : shotId)
    }
    function handleCustomDrop(e: any) {
      const x = e.detail?.clientX || 0
      const y = e.detail?.clientY || 0
      const el = document.elementFromPoint(x, y)
      const data = findShotShotIdAndActFromEl(el)
      const shotId = data.shotId
      const actNum = data.actNumber
      const item = e.detail?.item
      if (shotId && item?.url) {
        const extraRefsKey = actNum != null ? `${shotId}_${actNum}` : shotId
        setShotExtraRefs(prev => {
          const existing = prev[extraRefsKey] || []
          if (existing.some(e => e.url === item.url)) return prev
          return { ...prev, [extraRefsKey]: [...existing, { url: item.url, id: item.id }] }
        })
        setJustDroppedShotId(shotId)
        setTimeout(() => setJustDroppedShotId(prev => prev === shotId ? null : prev), 2200)
        // 持久化到后端：actNumber 也写入，刷新后保留
        const newRefs = (shotExtraRefs[extraRefsKey] || []).filter(r => r.url !== item.url).concat({ url: item.url, id: item.id })
        fetch(`/api/projects/${projectId}/steps/storyboard/shot-extra-refs`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ shotId, actNumber: actNum, refs: newRefs }),
        }).catch(err => console.warn('[DRAG-REF] 持久化失败:', err))
      }
      setDragOverShotId(null)
    }
    function handleDragEnd() {
      setDragOverShotId(null)
    }
    window.addEventListener('customdragmove', handleDragMove as EventListener)
    window.addEventListener('customdrop', handleCustomDrop as EventListener)
    window.addEventListener('customdragend', handleDragEnd as EventListener)

    // [DRAG-REF] 监听参考图拖拽事件，转换为 customdragmove/customdrop
    let currentRefItem: { url: string; id: string } | null = null
    function handleRefDragStart(e: Event) {
      const detail = (e as CustomEvent).detail
      currentRefItem = { url: detail.url, id: detail.id }
    }
    function handleRefDragOver(e: DragEvent) {
      if (!currentRefItem) return
      window.dispatchEvent(new CustomEvent('customdragmove', {
        detail: { clientX: e.clientX, clientY: e.clientY }
      }))
    }
    function handleRefDrop(e: DragEvent) {
      if (!currentRefItem) return
      e.preventDefault()
      window.dispatchEvent(new CustomEvent('customdrop', {
        detail: { clientX: e.clientX, clientY: e.clientY, item: currentRefItem }
      }))
      currentRefItem = null
    }
    function handleRefDragEnd() {
      currentRefItem = null
      window.dispatchEvent(new CustomEvent('customdragend'))
    }
    window.addEventListener('refdragstart', handleRefDragStart as EventListener)
    window.addEventListener('dragover', handleRefDragOver as EventListener)
    window.addEventListener('drop', handleRefDrop as EventListener)
    window.addEventListener('refdragend', handleRefDragEnd as EventListener)

    return () => {
      window.removeEventListener('customdragmove', handleDragMove as EventListener)
      window.removeEventListener('customdrop', handleCustomDrop as EventListener)
      window.removeEventListener('customdragend', handleDragEnd as EventListener)
      window.removeEventListener('refdragstart', handleRefDragStart as EventListener)
      window.removeEventListener('dragover', handleRefDragOver as EventListener)
      window.removeEventListener('drop', handleRefDrop as EventListener)
      window.removeEventListener('refdragend', handleRefDragEnd as EventListener)
    }
  }, [])

  // [ACT-QUEUE] 每幕异步生图进度（独立轮询，不占用全局 executing 状态）
  const [actProgress, setActProgress] = useState<Record<number, { current: number; total: number; shotId: string | null }>>({})

  // [WORKFLOW-FIX] 如果已有生成数据，从 outputData 读取模式
  const savedMode = step.outputData?.mode as 'reference' | 'keyframe' | undefined
  const currentMode = savedMode || storyboardMode || 'keyframe'

  // [ACT-GENERATE] 每幕的生图设置（比例 + 模型）
  const [actSettings, setActSettings] = useState<Record<number, { ratio: string; model: string }>>({})

  // 初始化每幕的默认设置
  useEffect(() => {
    const defaultRatio = step.outputData?.aspectRatio || project.selectedAspectRatio || '16:9'
    const defaultModel = IMAGE_MODELS.primary
    const settings: Record<number, { ratio: string; model: string }> = {}
    for (const shot of shots) {
      const act = shot.actNumber || 0
      if (!settings[act]) {
        settings[act] = { ratio: defaultRatio, model: defaultModel }
      }
    }
    setActSettings(settings)
  }, [shots.length, step.outputData?.aspectRatio, step.outputData?.imageModel])

  // 按幕分组 shots
  const shotsByAct = useMemo(() => {
    const grouped = new Map<number, any[]>()
    for (const shot of shots) {
      const act = shot.actNumber || 0
      if (!grouped.has(act)) grouped.set(act, [])
      grouped.get(act)!.push(shot)
    }
    return Array.from(grouped.entries()).sort((a, b) => a[0] - b[0])
  }, [shots])

  // [CHARACTER-MAP] 角色 ID → 名称映射
  const characterMap = useMemo(() => {
    const chars = framework?.characters || []
    const map: Record<string, string> = {}
    for (const c of chars) {
      if (c.id && c.name) map[c.id] = c.name
    }
    return map
  }, [framework])

  function getActSettings(act: number) {
    return actSettings[act] || { ratio: '16:9', model: IMAGE_MODELS.primary }
  }

  function handleModeSelect(mode: 'reference' | 'keyframe') {
    setStoryboardMode?.(mode)
  }

  async function handleGenerateAct(actNumber: number, force = false) {
    const { ratio, model } = getActSettings(actNumber)
    const actShots = shotsByAct.find(([a]) => a === actNumber)?.[1] || []
    const total = actShots.length

    setActProgress(prev => ({ ...prev, [actNumber]: { current: 0, total, shotId: null } }))

    try {
      let remaining = total
      while (remaining > 0) {
        const res = await fetchWithRetry(`/api/projects/${projectId}/steps/storyboard`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'generate-act-images',
            actNumber,
            aspectRatio: ratio,
            imageModel: model,
            force: force && remaining === total, // 仅在第一轮传 force
          }),
        })
        const result = await res.json()
        if (!res.ok || !result.success) {
          throw new Error(result.message || result.error || `HTTP ${res.status}`)
        }

        const data = result.data
        await mutate()

        if (data.status === 'completed') {
          setActProgress(prev => ({
            ...prev,
            [actNumber]: { current: data.processedCount, total: data.totalCount, shotId: null },
          }))
          break
        }

        setActProgress(prev => ({
          ...prev,
          [actNumber]: { current: data.processedCount, total: data.totalCount, shotId: data.currentShotId },
        }))
        remaining = data.remainingCount
      }
      setToast({ kind: 'success', message: `第 ${actNumber} 幕图片生成完成` })
    } catch (e: any) {
      onError('生图失败：' + e?.message)
    } finally {
      setActProgress(prev => {
        const next = { ...prev }
        delete next[actNumber]
        return next
      })
    }
  }

  async function handleGenerateSingleShot(actNumber: number, shotId: string) {
    const { ratio, model } = getActSettings(actNumber)
    setActProgress(prev => ({ ...prev, [actNumber]: { current: 0, total: 1, shotId } }))
    try {
      const res = await fetchWithRetry(`/api/projects/${projectId}/steps/storyboard`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'generate-act-images',
          actNumber,
          shotId,
          aspectRatio: ratio,
          imageModel: model,
        }),
      })
      const result = await res.json()
      if (!res.ok || !result.success) throw new Error(result.message || `HTTP ${res.status}`)
      await mutate()
      setToast({ kind: 'success', message: `镜头 ${shotId} 生成完成` })
    } catch (e: any) {
      onError('生图失败：' + e?.message)
    } finally {
      setActProgress(prev => {
        const next = { ...prev }
        delete next[actNumber]
        return next
      })
    }
  }

  async function clearShotGenerationState(actNumber: number, shotId: string) {
    const key = `${actNumber}_${shotId}`
    const qs = new URLSearchParams({ key, actNumber: String(actNumber), shotId })
    const res = await fetch(`/api/projects/${projectId}/steps/storyboard/generation-state?${qs.toString()}`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key, actNumber, shotId }),
    })
    const result = await res.json().catch(() => ({}))
    if (!res.ok || !result.success) throw new Error(result.message || result.error || `HTTP ${res.status}`)
    await mutate()
  }

  async function handleInterruptAndRetry(actNumber: number, shotId: string) {
    try {
      await clearShotGenerationState(actNumber, shotId)
      await handleGenerateSingleShot(actNumber, shotId)
    } catch (e: any) {
      onError('中断并重试失败：' + e?.message)
    }
  }

  async function handleRegenerate(shotId: string, aspectRatio?: string, imageModel?: string, actNumber?: number) {
    setRegeneratingId(shotId)
    try {
      // 收集当前所有参考图和 prompt，打开重试副工作台
      const allRefs: Array<{ url: string; label: string; type: 'character' | 'style' | 'previous-shot' | 'user-upload' | 'user-dragged'; removable: boolean }> = []

      // 1) 用户拖入的最高优先级参考（持久化的）
      const extraRefsKey = actNumber != null ? `${shotId}_${actNumber}` : shotId
      const extras = shotExtraRefs[extraRefsKey] || shotExtraRefs[shotId] || []
      extras.forEach((r) => allRefs.push({ url: r.url, label: r.id || '最高优先级', type: 'user-dragged', removable: true }))

      // 2) 角色图、风格图、上一帧、用户参考（直接从后端拉取）
      try {
        const refRes = await fetch(`/api/projects/${projectId}/steps/storyboard/regenerate-prefill?shotId=${shotId}&actNumber=${actNumber || ''}`)
        if (refRes.ok) {
          const refData = await refRes.json()
          refData.refs?.forEach((r: any) => {
            if (!allRefs.find(x => x.url === r.url)) {
              allRefs.push({ url: r.url, label: r.label, type: r.type, removable: true })
            }
          })
        }
      } catch {}

      // 3) 镜头当前 prompt
      // 多级兜底：shotPrompts 只有「分镜生成」路径会写，
      // 而 xlsx 导入路径（import-storyboard）不写它 —— 只看 shotPrompts 会让
      // 导入项目的 basePrompt 为空，副工作台的确认按钮
      // (disabled={!promptOverride.trim()}) 恒为 true，用户看到的就是"点了没反应"。
      const stepOutput = step.outputData || {}
      const shotPrompts: any[] = stepOutput.shotPrompts || []
      const actPrompts: any[] = stepOutput.prompts || []
      const shot = (stepOutput.shots || []).find(
        (s: any) => s.shotId === shotId && (actNumber == null || s.actNumber == null || s.actNumber === actNumber)
      )
      const matchesAct = (p: any) =>
        p?.shotId === shotId && (actNumber == null || p?.actNumber == null || p?.actNumber === actNumber)

      const currentShotPrompt = shotPrompts.find(matchesAct)
      const basePrompt =
        currentShotPrompt?.prompt
        || currentShotPrompt?.englishPrompt
        // 兜底 1：幕级 prompts（注意字段名是 englishPrompt，不是 prompt）
        || actPrompts.find(matchesAct)?.englishPrompt
        || actPrompts.find(matchesAct)?.prompt
        // 兜底 2：shot 自身的描述/提示词
        || shot?.imagePrompt
        || shot?.prompt
        || shot?.description
        || ''

      // 4) 镜头当前原图（修改原图模式用）
      // 导入的图片 Asset 不挂在 stepId 上，resultAssets 里取不到，
      // 必须回退到 shot.firstFrameUrl
      const asset = (step.resultAssets || []).find((a: any) => {
        const m = (a.metadata || {}) as any
        return m.shotId === shotId && (m.actNumber === actNumber || (!actNumber && !m.actNumber))
      })
      const originalImageUrl = asset?.url || shot?.firstFrameUrl || null

      ;(window as any).__openRetryEditForStoryboard?.({
        shotId,
        actNumber,
        targetLabel: `${shotId}（第${actNumber || '?'}幕）`,
        basePrompt,
        baseRefs: allRefs,
        originalImageUrl,
        currentModel: imageModel || IMAGE_MODELS.primary,
        aspectRatio: aspectRatio || '16:9',
      })
    } finally {
      setRegeneratingId(null)
    }
  }

  if (step.status === 'PROCESSING' || isExecuting) {
    return <ProcessingBlock message="正在生成分镜设计..." />
  }

  // PENDING 且没有 prompts → 模式选择
  if (step.status === 'PENDING' && !step.outputData?.prompts?.length) {
    return (
      <div className="space-y-4">
        <div className="flex justify-center py-8">
          <div className="space-y-6 text-center">
            <p className="text-sm text-stone-500">选择分镜设计模式：</p>
            <div className="flex gap-4 justify-center">
              <button
                onClick={() => { handleModeSelect('reference'); onExecute('STORYBOARD', { action: 'generate-prompts', mode: 'reference' }) }}
                disabled={isExecuting}
                className={`flex flex-col items-center gap-2 rounded-xl border-2 p-6 w-48 transition ${
                  currentMode === 'reference'
                    ? 'border-amber-500 bg-amber-50'
                    : 'border-stone-200 bg-white hover:border-stone-400'
                } disabled:opacity-50`}
              >
                <Film className="h-6 w-6 text-amber-600" />
                <span className="text-sm font-medium text-stone-800">实拍参考模式</span>
                <span className="text-xs text-stone-500">生成代表画面，用于实拍参考</span>
              </button>
              <button
                onClick={() => { handleModeSelect('keyframe'); onExecute('STORYBOARD', { action: 'generate-prompts', mode: 'keyframe' }) }}
                disabled={isExecuting}
                className={`flex flex-col items-center gap-2 rounded-xl border-2 p-6 w-48 transition ${
                  currentMode === 'keyframe'
                    ? 'border-amber-500 bg-amber-50'
                    : 'border-stone-200 bg-white hover:border-stone-400'
                } disabled:opacity-50`}
              >
                <Play className="h-6 w-6 text-amber-600" />
                <span className="text-sm font-medium text-stone-800">视频生成模式</span>
                <span className="text-xs text-stone-500">生成起始帧，用于后续视频生成</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  // PENDING 有 prompts / COMPLETED → 纵向分镜表
  const hasPrompts = step.outputData?.prompts?.length > 0
  const showStoryboardTable = hasPrompts || step.status === 'COMPLETED'

  if (showStoryboardTable) {
    return (
      <div className="space-y-6">
        {shotsByAct.map(([actNumber, actShots]) => {
          const actAssetsMap = new Map<string, any>()
          for (const shot of actShots) {
            const asset = shotAssets.find((a: any) => a.metadata?.shotId === shot.shotId && a.metadata?.actNumber === actNumber)
            if (asset) actAssetsMap.set(shot.shotId, asset)
          }
          const generatedCount = actAssetsMap.size
          const totalCount = actShots.length
          const allGenerated = generatedCount === totalCount && totalCount > 0
          const someGenerated = generatedCount > 0 && generatedCount < totalCount
          const { ratio, model } = getActSettings(actNumber)
          const actHasServerGenerating = actShots.some((shot: any) => generatingShots[`${actNumber}_${shot.shotId}`]?.status === 'processing')

          return (
            <div key={actNumber} className="rounded-lg border border-stone-200 bg-white overflow-hidden">
              {/* 头部 */}
              <div className="flex items-center justify-between px-4 py-3 border-b border-stone-100 bg-stone-50">
                <div>
                  <h3 className="text-sm font-semibold text-stone-800">第 {actNumber} 幕</h3>
                  <span className="text-xs text-stone-500">{totalCount} 个镜头</span>
                </div>
                <div className="flex items-center gap-2">
                  {allGenerated && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-green-100 px-2 py-0.5 text-xs font-medium text-green-700">
                      <Check className="h-3 w-3" /> 已生成
                    </span>
                  )}
                  {someGenerated && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2 py-0.5 text-xs font-medium text-amber-700">
                      部分生成 {generatedCount}/{totalCount}
                    </span>
                  )}
                  {!generatedCount && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-stone-100 px-2 py-0.5 text-xs font-medium text-stone-500">
                      未生成
                    </span>
                  )}
                </div>
              </div>

              {/* 分镜行卡片列表（左侧信息 + 右侧图片） */}
              <div className="divide-y divide-stone-100">
                {actShots.map((shot: any) => {
                  const asset = actAssetsMap.get(shot.shotId) || (shot.firstFrameUrl ? { url: shot.firstFrameUrl, metadata: { shotId: shot.shotId, actNumber } } : null)
                  const isRegenerating = regeneratingId === shot.shotId
                  const generationKey = `${actNumber}_${shot.shotId}`
                  const generationState = generatingShots[generationKey]
                  const isServerGenerating = generationState?.status === 'processing'
                  const generationStartedAt = generationState?.startedAt ? new Date(generationState.startedAt).getTime() : 0
                  const generationIsStale = isServerGenerating && generationStartedAt > 0 && Date.now() - generationStartedAt > 12 * 60 * 1000
                  const blocksGeneration = isServerGenerating && !generationIsStale
                  const cardRatio = asset?.metadata?.aspectRatio || '16:9'
                  // 默认 gpt-image-1（除非用户手动选择其他模型）
                  const cardModel = IMAGE_MODELS.primary
                  const mappedChars = shot.characters?.map((cid: string) => characterMap[cid] || cid).join('、')

                  return (
                    <div
                      key={shot.shotId}
                      data-shot-id={shot.shotId}
                      data-shot-act={shot.actNumber ?? ''}
                      className={`flex flex-col sm:flex-row gap-4 px-4 py-3 transition-colors ${dragOverShotId === shot.shotId ? 'bg-emerald-50/40' : ''}`}
                    >
                      {/* 左侧：镜头信息 */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-mono text-[11px] text-stone-400 bg-stone-100 px-1.5 py-0.5 rounded">
                            {shot.shotId}
                          </span>
                          <span className="text-sm font-medium text-stone-800">{shot.sceneName}</span>
                          {isServerGenerating && (
                            <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-medium ${generationIsStale ? 'bg-amber-100 text-amber-700' : 'bg-blue-100 text-blue-700'}`}>
                              <LoaderCircle className="h-3 w-3 animate-spin" />
                              {generationIsStale ? '生成可能超时' : '正在生成'}
                            </span>
                          )}
                          {generationState?.status === 'failed' && (
                            <span className="inline-flex items-center gap-1 rounded-full bg-red-100 px-2 py-0.5 text-[10px] font-medium text-red-700" title={generationState.message || ''}>
                              生成失败
                            </span>
                          )}
                          {dragOverShotId === shot.shotId && (
                            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-600 px-2 py-0.5 text-[10px] font-medium text-white">
                              释放以置顶参考
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-stone-600 leading-relaxed mb-2">{shot.description}</p>
                        <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-stone-500">
                          <span>
                            <span className="text-stone-400">运镜</span> {shot.cameraMove}
                          </span>
                          <span>
                            <span className="text-stone-400">时长</span> {shot.duration}s
                          </span>
                          {mappedChars && (
                            <span>
                              <span className="text-stone-400">角色</span>{' '}
                              <span className="text-stone-600">{mappedChars}</span>
                            </span>
                          )}
                        </div>
                      </div>

                      {/* 右侧：图片区 */}
                      <div className="w-full sm:w-60 shrink-0">
                        {(() => {
                          const extraRefsKey = actNumber != null ? `${shot.shotId}_${actNumber}` : shot.shotId
                          const refs = shotExtraRefs[extraRefsKey] || []
                          if (refs.length === 0) return null
                          return (
                          <div className="mb-2 rounded-lg border border-emerald-200 bg-emerald-50 p-2">
                            <div className="mb-1.5 flex items-center gap-1.5 text-[11px] font-medium text-emerald-700">
                              <Check className="h-3 w-3" />
                              <span>已添加 {refs.length} 个最高优先级参考</span>
                              <button
                                onClick={() => {
                                  setShotExtraRefs(prev => { const n = { ...prev }; delete n[extraRefsKey]; return n })
                                  fetch(`/api/projects/${projectId}/steps/storyboard/shot-extra-refs`, {
                                    method: 'DELETE',
                                    headers: { 'Content-Type': 'application/json' },
                                    body: JSON.stringify({ shotId: shot.shotId, actNumber }),
                                  }).catch(err => console.warn('[DRAG-REF] 清除失败:', err))
                                }}
                                className="ml-auto text-stone-400 hover:text-stone-600"
                                title="清除"
                              >
                                <X className="h-3 w-3" />
                              </button>
                            </div>
                            <div className="flex flex-wrap gap-1.5">
                              {refs.map((r, i) => (
                                <div key={i} className="relative h-12 w-16 overflow-hidden rounded border border-emerald-200">
                                  <img src={proxiedMediaUrl(r.url)} alt="" className="h-full w-full object-cover" />
                                </div>
                              ))}
                            </div>
                          </div>
                          )
                        })()}
                        {asset ? (
                          <div
                            className={`group/thumb relative w-full transition ${dragOverShotId === shot.shotId ? 'ring-2 ring-emerald-400 ring-offset-1 rounded' : ''}`}
                            style={{ aspectRatio: cardRatio.replace(':', '/') }}
                          >
                            <img
                              src={proxiedMediaUrl(asset.url)}
                              alt=""
                              className="h-full w-full rounded object-cover"
                            />
                            <HoverImageBadge
                              src={proxiedMediaUrl(asset.url)}
                              aspectRatio={cardRatio}
                              imageModel={cardModel}
                              onRegenerate={(ar, m) => handleRegenerate(shot.shotId, ar, m, actNumber)}
                              isRegenerating={isRegenerating}
                              anyRegenerating={!!regeneratingId || blocksGeneration}
                              wrapperClassName="absolute inset-0"
                            />
                            {isServerGenerating && (
                              <div className={`absolute inset-0 z-30 flex flex-col items-center justify-center gap-2 rounded bg-black/55 text-white ${generationIsStale ? '' : 'pointer-events-none'}`}>
                                <LoaderCircle className="h-5 w-5 animate-spin" />
                                <span className="text-xs font-medium">{generationIsStale ? '生成可能超时' : '正在生成'}</span>
                                {generationIsStale && !readOnly && (
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation()
                                      handleInterruptAndRetry(actNumber, shot.shotId)
                                    }}
                                    disabled={!!actProgress[actNumber]}
                                    className="rounded-md bg-white px-3 py-1 text-[11px] font-medium text-stone-800 shadow transition hover:bg-stone-100 disabled:opacity-50"
                                  >
                                    中断并重试
                                  </button>
                                )}
                              </div>
                            )}
                            {generationState?.status === 'failed' && (
                              <div className="absolute inset-x-1 bottom-1 z-30 rounded bg-red-600/90 px-2 py-1 text-[10px] text-white" title={generationState.message || ''}>
                                生成失败：{String(generationState.message || '').slice(0, 28)}
                              </div>
                            )}
                            {justDroppedShotId === shot.shotId && (
                              <div className="pointer-events-none absolute right-1 top-1 z-30 flex items-center gap-1 rounded-full bg-emerald-600 px-2 py-0.5 text-[10px] font-medium text-white shadow">
                                <Check className="h-3 w-3" />
                                参考已置顶
                              </div>
                            )}
                          </div>
                        ) : (
                          <div
                            className={`relative flex w-full flex-col items-center justify-center overflow-hidden rounded border-2 border-dashed transition-colors ${dragOverShotId === shot.shotId ? 'border-emerald-400 bg-emerald-50' : 'border-stone-300 bg-stone-100'}`}
                            style={{ aspectRatio: '16/9' }}
                          >
                            <span className="font-mono text-sm font-bold text-stone-600">{shot.shotId || ''}</span>
                            <span className="mt-1 max-w-[90%] truncate px-2 text-xs text-stone-400">{(shot.sceneName || '').slice(0, 14)}</span>
                            {!readOnly && (
                              <>
                                {confirmingShotId === shot.shotId ? (
                                  <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 rounded bg-amber-50/95 px-2">
                                    <p className="text-[11px] font-medium text-stone-700">确认生成镜头 {shot.shotId}？</p>
                                    <div className="flex gap-2">
                                      <button
                                        onClick={() => setConfirmingShotId(null)}
                                        className="rounded-md border border-stone-300 bg-white px-3 py-1 text-[11px] text-stone-600 transition hover:bg-stone-50"
                                      >取消</button>
                                      <button
                                        onClick={() => { setConfirmingShotId(null); handleGenerateSingleShot(actNumber, shot.shotId) }}
                                        disabled={isExecuting || !!actProgress[actNumber] || blocksGeneration}
                                        className="rounded-md bg-amber-600 px-3 py-1 text-[11px] font-medium text-white transition hover:bg-amber-700 disabled:opacity-50"
                                      >确认生成</button>
                                    </div>
                                  </div>
                                ) : (
                                  <button
                                    onClick={() => {
                                      if (generationIsStale) {
                                        handleInterruptAndRetry(actNumber, shot.shotId)
                                      } else {
                                        setConfirmingShotId(shot.shotId)
                                      }
                                    }}
                                    disabled={isExecuting || !!actProgress[actNumber] || blocksGeneration}
                                    className="absolute inset-0 flex flex-col items-center justify-center gap-1 rounded bg-stone-100/80 text-xs font-medium text-stone-600 transition hover:bg-stone-200/90 hover:text-stone-800 disabled:opacity-50"
                                  >
                                    {generationIsStale ? (
                                      <>
                                        <RefreshCw className="h-4 w-4" />
                                        中断并重试
                                      </>
                                    ) : actProgress[actNumber]?.shotId === shot.shotId || isServerGenerating ? (
                                      <>
                                        <LoaderCircle className="h-4 w-4 animate-spin" />
                                        生成中
                                      </>
                                    ) : (
                                      <>
                                        <ImageIcon className="h-4 w-4" />
                                        生成
                                      </>
                                    )}
                                  </button>
                                )}
                              </>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>

              {/* 生图控制 */}
              {!readOnly && (
                <div className="flex items-center gap-3 px-4 py-3 border-t border-stone-100 bg-stone-50">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-medium text-stone-600">比例</span>
                    <select
                      value={ratio}
                      onChange={(e) => {
                        setActSettings(prev => ({
                          ...prev,
                          [actNumber]: { ...prev[actNumber], ratio: e.target.value }
                        }))
                      }}
                      className="rounded-md border border-stone-300 bg-white px-2 py-1 text-xs text-stone-700 focus:border-amber-500 focus:outline-none"
                    >
                      {ASPECT_RATIO_OPTIONS.map(opt => (
                        <option key={opt.value} value={opt.value}>
                          {opt.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-medium text-stone-600">模型</span>
                    <select
                      value={model}
                      onChange={(e) => {
                        setActSettings(prev => ({
                          ...prev,
                          [actNumber]: { ...prev[actNumber], model: e.target.value }
                        }))
                      }}
                      className="rounded-md border border-stone-300 bg-white px-2 py-1 text-xs text-stone-700 focus:border-amber-500 focus:outline-none"
                    >
                      {IMAGE_MODEL_OPTIONS.map(opt => (
                        <option key={opt.value} value={opt.value}>
                          {opt.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  {SHOW_STORYBOARD_BATCH_CONTROLS && (
                  <div className="relative inline-block ml-auto">
                    <button
                      onClick={() => handleGenerateAct(actNumber, allGenerated)}
                      disabled={isExecuting || !!actProgress[actNumber] || actHasServerGenerating}
                      className={`flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-medium transition disabled:opacity-50 ${
                        allGenerated
                          ? 'border border-stone-300 bg-white text-stone-700 hover:bg-stone-100'
                          : 'bg-stone-900 text-white hover:bg-stone-800'
                      }`}
                    >
                      {actProgress[actNumber] || actHasServerGenerating ? (
                        <>
                          <LoaderCircle className="h-3 w-3 animate-spin" />
                          {actProgress[actNumber] ? `${actProgress[actNumber].current}/${actProgress[actNumber].total}` : '生成中'}
                        </>
                      ) : allGenerated ? (
                        <><RefreshCw className="h-3 w-3" /> 重新生图</>
                      ) : (
                        <><ImageIcon className="h-3 w-3" /> 生图</>
                      )}
                    </button>
                    {!allGenerated && !actProgress[actNumber] && (
                      <CostBadge
                        cost={calculateBatchCost(
                          getImageGenerationCost(model, GENERATION_COSTS.STORYBOARD_ACT_IMAGE, 'medium'),
                          totalCount - generatedCount,
                        )}
                      />
                    )}
                  </div>
                  )}
                </div>
              )}
            </div>
          )
        })}

        {/* 底部操作 */}
        <div className="flex flex-wrap items-center gap-3 pt-2">
          <Link
            href={`/project/${projectId}/storyboard`}
            className="inline-flex items-center gap-2 rounded-lg border border-stone-200 bg-white px-4 py-2.5 text-sm font-medium text-stone-700 transition hover:bg-stone-50"
          >
            <ExternalLink className="h-4 w-4" />
            进入分镜编辑器
          </Link>

          {SHOW_STORYBOARD_BATCH_CONTROLS && (!showConfirmAll ? (
            <button
              onClick={() => setShowConfirmAll(true)}
              disabled={isExecuting}
              className="inline-flex items-center gap-2 rounded-lg border border-stone-200 bg-white px-4 py-2.5 text-sm font-medium text-stone-600 transition hover:bg-stone-50 hover:text-stone-800 disabled:opacity-50"
            >
              <RefreshCw className="h-4 w-4" />
              重新生成全部分镜
            </button>
          ) : (
            <div className="rounded-lg border border-amber-200 bg-amber-50 p-3">
              <p className="text-xs font-medium text-stone-800">确定重新生成全部分镜？</p>
              <div className="mt-2 flex gap-2">
                <button
                  onClick={() => setShowConfirmAll(false)}
                  className="rounded-md border border-stone-200 bg-white px-3 py-1 text-xs text-stone-600 transition hover:bg-stone-50"
                >取消</button>
                <div className="relative inline-block">
                  <button
                    onClick={() => { setShowConfirmAll(false); onExecute('STORYBOARD', { force: true }) }}
                    disabled={isExecuting}
                    className="flex items-center gap-1 rounded-md bg-amber-600 px-3 py-1 text-xs font-medium text-white transition hover:bg-amber-700 disabled:opacity-50"
                  >
                    {isExecuting ? (
                      <><LoaderCircle className="h-3 w-3 animate-spin" />生成中...</>
                    ) : '确认'}
                  </button>
                  <CostBadge cost={DEFAULT_GENERATE_COST} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  // 兜底：没有 shots 数据时的默认按钮
  return (
    <div className="space-y-4">
      <div className="flex justify-center py-8">
        <div className="relative inline-block">
          <button
            onClick={() => onExecute('STORYBOARD', { action: 'generate-prompts' })}
            disabled={isExecuting}
            className="flex items-center gap-2 rounded-lg bg-stone-900 px-6 py-3 text-sm font-medium text-white transition hover:bg-stone-800 disabled:opacity-50"
          >
            {isExecuting ? (
              <><LoaderCircle className="h-4 w-4 animate-spin" /> 生成中...</>
            ) : (
              <><Play className="h-4 w-4" /> 生成分镜设计</>
            )}
          </button>
          <CostBadge cost={DEFAULT_GENERATE_COST} />
        </div>
      </div>
    </div>
  )
}

import KeyframesTable from './_components/KeyframesTable'
import type { Shot as KeyframeShot } from '@/app/(dashboard)/project/[id]/storyboard/_components/StoryboardTable'
import StoryboardCanvas from '@/app/(dashboard)/project/[id]/storyboard/_components/StoryboardCanvas'
import { Table2, LayoutGrid } from 'lucide-react'

function KeyframesPanel({
  step,
  project,
  projectId,
  executing,
  onExecute,
  mutate,
  isAvailable,
  readOnly,
}: {
  step: any
  project: any
  projectId: string
  executing: string | null
  onExecute: (stepType: string, body?: any) => void
  mutate: () => Promise<any>
  isAvailable?: boolean
  readOnly?: boolean
}) {
  const isExecuting = executing === step.stepType

  // [KEYFRAMES-UI] 从 STORYBOARD 步骤读取数据（单一数据源）
  const { data: storyboardRes } = useSWR(
    `/api/projects/${projectId}/steps/storyboard`,
    fetcher
  )

  // 从 KEYFRAMES 步骤读取状态（用于 PROMPT_READY 检测），每 3 秒轮询
  const { data: keyframesRes, mutate: mutateKeyframes } = useSWR(
    `/api/projects/${projectId}/steps/keyframes`,
    fetcher,
    { refreshInterval: 10000 }
  )

  const [localShots, setLocalShots] = useState<KeyframeShot[]>([])
  const [hasSynced, setHasSynced] = useState(false)
  const [viewMode, setViewMode] = useState<'table' | 'canvas'>('table')
  const [exportProgress, setExportProgress] = useState<string | null>(null)

  // 从 storyboard outputData 读取 shots
  const storyboardShots: KeyframeShot[] = storyboardRes?.outputData?.shots || []
  const storyboardAssets = storyboardRes?.assets || []
  const exportCharacterMap = useMemo(() => {
    const chars = project?.framework?.characters || []
    const map: Record<string, string> = {}
    for (const c of chars) {
      if (c?.id && c?.name) map[c.id] = c.name
    }
    return map
  }, [project?.framework])

  // 从 KEYFRAMES outputData 读取 keyframes 数据（包含 lastFrameUrl 和 actionChange）
  const keyframesData = keyframesRes?.outputData?.keyframes || keyframesRes?.outputData?.results || []
  // 使用 composite key (actNumber|shotId) 避免跨幕同名镜头冲突
  const lastFrameMap: Record<string, string> = {}
  const actionChangeMap: Record<string, string> = {}
  for (const kf of keyframesData) {
    if (kf.shotId) {
      const key = `${kf.actNumber || 0}|${kf.shotId}`
      if (kf.lastFrameUrl) lastFrameMap[key] = kf.lastFrameUrl
      if (kf.actionChange) actionChangeMap[key] = kf.actionChange
    }
  }

  // SWR 数据首次到达时同步到本地状态（合并 lastFrameUrl 和 actionChange）
  useEffect(() => {
    if (storyboardShots.length > 0 && !hasSynced) {
      const shotsWithAction = storyboardShots.map((s) => {
        const key = `${s.actNumber || 0}|${s.shotId}`
        return {
          ...s,
          lastFrameUrl: lastFrameMap[key] || s.lastFrameUrl,
          actionChange: actionChangeMap[key] || '',
        }
      })
      setLocalShots(shotsWithAction)
      setHasSynced(true)
    }
  }, [storyboardShots.length, hasSynced, Object.keys(lastFrameMap).length])

  // 当 SWR 数据变化时（如从其他界面保存后），如果已同步则更新
  useEffect(() => {
    if (hasSynced && storyboardShots.length > 0) {
      const shotsWithAction = storyboardShots.map((s) => {
        const key = `${s.actNumber || 0}|${s.shotId}`
        return {
          ...s,
          lastFrameUrl: lastFrameMap[key] || s.lastFrameUrl,
          actionChange: actionChangeMap[key] || '',
        }
      })
      setLocalShots(shotsWithAction)
    }
  }, [storyboardShots.length, Object.keys(lastFrameMap).length])

  function handleShotsChange(next: KeyframeShot[]) {
    setLocalShots(next)
  }

  // 工作指令.txt（2026-05-24）：保存动作变化描述到 KEYFRAMES outputData
  async function handleActionChange(shotId: string, actionChange: string, actNumber = 0) {
    const shot = storyboardShots.find((s: any) => s.shotId === shotId && (s.actNumber || 0) === actNumber)
    let found = false
    const nextKeyframes = keyframesData.map((kf: any) => {
      const matched = kf.shotId === shotId && (kf.actNumber || 0) === actNumber
      if (matched) found = true
      return matched ? { ...kf, actionChange, actNumber } : kf
    })
    if (!found) {
      nextKeyframes.push({
        shotId,
        actNumber,
        firstFrameUrl: shot?.firstFrameUrl || shot?.referenceImageUrl || '',
        lastFrameUrl: shot?.lastFrameUrl || '',
        description: shot?.description || '',
        actionChange,
      })
    }
    try {
      const res = await fetch(`/api/projects/${projectId}/steps/keyframes`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ keyframes: nextKeyframes }),
      })
      if (!res.ok) throw new Error('保存失败')
      console.log(`[TEXT-EDIT-KEYFRAMES] 保存 actionChange 成功, shotId=${shotId}`)
      await mutate()
    } catch (e: any) {
      console.error('[TEXT-EDIT-KEYFRAMES] 保存 actionChange 失败:', e.message)
    }
  }

  // 导出分镜（与 storyboard/page.tsx 共用同一逻辑，支持 JSON / Excel 双格式）
  async function handleExport(format: 'json' | 'excel') {
    console.log('[KEYFRAMES-EXPORT] 导出分镜, format:', format)
    if (typeof window === 'undefined') return
    const projectName = storyboardRes?.project?.title || 'project'

    const data = {
      projectName,
      exportType: 'storyboard',
      mode: localShots[0]?.mode || 'keyframe',
      exportTime: new Date().toISOString(),
      totalShots: localShots.length,
      shots: localShots.map((shot, index) => ({
        镜头序号: index + 1,
        镜头描述: shot.description || '',
        运镜方式: shot.cameraMove || '',
        时长: shot.duration || '',
        角色: (shot.characters || []).join(', '),
        图片URL: shot.lastFrameUrl || shot.firstFrameUrl || shot.referenceImageUrl || '',
        尾帧URL: shot.lastFrameUrl || '',
      }))
    }

    if (format === 'json') {
      try {
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `${projectName}_分镜解读_${new Date().toISOString().slice(0, 10)}.json`
        document.body.appendChild(a)
        a.click()
        document.body.removeChild(a)
        URL.revokeObjectURL(url)
        console.log('[KEYFRAMES-EXPORT] JSON 下载触发成功')
      } catch (err: any) {
        console.error('[KEYFRAMES-EXPORT] JSON 导出失败:', err?.message || err)
      }
    } else if (format === 'excel') {
      try {
        await exportStoryboardExcel({
          exportKey: `project:${projectId}:storyboard:${localShots[0]?.mode || 'keyframe'}`,
          projectName,
          shots: localShots,
          characterMap: exportCharacterMap,
          mode: localShots[0]?.mode || 'keyframe',
          onProgress: (progress) => {
            setExportProgress(`${progress.message} (cached ${progress.reused}, fetched ${progress.fetched})`)
          },
        })
        setTimeout(() => setExportProgress(null), 5000)
        console.log('[KEYFRAMES-EXPORT] Excel 下载触发成功')
      } catch (err: any) {
        setExportProgress(`Excel export failed: ${err?.message || err}`)
        console.error('[KEYFRAMES-EXPORT] Excel 导出失败:', err?.message || err)
      }
    }
  }

  // PROCESSING 状态单独处理（显示加载状态）
  if (step.status === 'PROCESSING') {
    return <ProcessingBlock message="正在生成尾帧..." />
  }

  // 只要有 shots 数据就显示编辑器（不再要求 step.status === 'COMPLETED'）
  const hasShots = localShots.length > 0

  // PROMPT_READY：提示词预览（仅在没有 shots 时显示，作为引导）
  const kfPrompts = keyframesRes?.outputData?.prompts || step.outputData?.prompts || []
  const kfDefaultRatio = keyframesRes?.outputData?.aspectRatio || step.outputData?.aspectRatio || project.selectedAspectRatio || '16:9'
  const kfDefaultModel = IMAGE_MODELS.primary

  // 无 shots 时显示提示词预览（引导用户先生成分镜）
  if (!hasShots) {
    return (
      <div className="space-y-4">
        <PromptPreviewWithRatio
          prompts={kfPrompts}
          title="生成尾帧提示词预览"
          stepLabel="KEYFRAMES"
          defaultRatio={kfDefaultRatio}
          defaultModel={kfDefaultModel}
          onConfirm={(ratio, model) => onExecute('KEYFRAMES', { action: 'generate-images', aspectRatio: ratio, imageModel: model })}
          onRegeneratePrompts={() => onExecute('KEYFRAMES', { action: 'generate-prompts' })}
          isExecuting={isExecuting}
          editable={!readOnly}
          projectId={projectId}
          stepType="KEYFRAMES"
          onSaveSuccess={() => mutate()}
        />
      </div>
    )
  }

  // 有 shots 时显示纵向分镜卡片布局（每张卡片有独立状态和生成按钮）
  if (hasShots) {
    return (
      <div className="space-y-4">
        {/* 顶部工具栏 */}
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            {/* 模式标签 */}
            <div className="flex items-center rounded-lg border border-stone-200 bg-white px-3 py-1.5 shadow-sm">
              <span className="inline-flex items-center gap-1.5 text-sm font-medium text-amber-600">
                <Film className="h-3.5 w-3.5" />
                当前：生成尾帧
              </span>
            </div>

            {/* 导出按钮 — JSON + Excel 双格式 */}
            <div className="flex flex-col items-start gap-1">
              <div className="flex items-center gap-2">
              <button
                onClick={() => handleExport('json')}
                className="flex items-center gap-1.5 rounded-lg border border-stone-200 bg-white px-3 py-1.5 text-sm font-medium text-stone-700 transition hover:bg-stone-50"
              >
                <FileJson className="h-4 w-4" />
                JSON
              </button>
              <button
                onClick={() => handleExport('excel')}
                className="flex items-center gap-1.5 rounded-lg border border-stone-200 bg-white px-3 py-1.5 text-sm font-medium text-stone-700 transition hover:bg-stone-50"
              >
                <FileSpreadsheet className="h-4 w-4" />
                Excel
              </button>
              </div>
              {exportProgress && (
                <p className="max-w-[360px] truncate text-xs text-stone-500" title={exportProgress}>
                  {exportProgress}
                </p>
              )}
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* 视图切换 */}
            <div className="flex items-center rounded-lg border border-stone-200 bg-white p-1 shadow-sm">
              <button
                onClick={() => setViewMode('table')}
                className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition ${
                  viewMode === 'table'
                    ? 'bg-stone-900 text-white'
                    : 'text-stone-500 hover:bg-stone-50 hover:text-stone-700'
                }`}
              >
                <Table2 className="h-4 w-4" />
                表格
              </button>
              <button
                onClick={() => setViewMode('canvas')}
                className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition ${
                  viewMode === 'canvas'
                    ? 'bg-stone-900 text-white'
                    : 'text-stone-500 hover:bg-stone-50 hover:text-stone-700'
                }`}
              >
                <LayoutGrid className="h-4 w-4" />
                画布
              </button>
            </div>
          </div>
        </div>

        {/* 编辑器内容 */}
        <div className="rounded-lg border border-stone-200 bg-white p-4 shadow-sm sm:p-6">
          {viewMode === 'table' ? (
            <KeyframesTable
              shots={localShots}
              assets={storyboardAssets}
              characterMap={{}}
              projectId={projectId}
              onShotsChange={handleShotsChange}
              onActionChange={handleActionChange}
            />
          ) : (
            <StoryboardCanvas
              shots={localShots}
              assets={storyboardAssets}
              mode="keyframe"
            />
          )}
        </div>
      </div>
    )
  }

  if (step.status === 'PROCESSING') {
    return <ProcessingBlock message="正在生成尾帧..." />
  }

  // PENDING / FAILED 状态显示生成按钮 + 跳过按钮
  return (
    <div className="flex justify-center py-8">
      <div className="flex items-center gap-3">
        <div className="relative inline-block">
          <button
            onClick={() => onExecute('KEYFRAMES', { action: 'generate-prompts' })}
            disabled={isExecuting}
            className="flex items-center gap-2 rounded-lg bg-stone-900 px-6 py-3 text-sm font-medium text-white transition hover:bg-stone-800 disabled:opacity-50"
          >
            {isExecuting ? (
              <>
                <LoaderCircle className="h-4 w-4 animate-spin" />
                生成中...
              </>
            ) : (
              <>
                <Play className="h-4 w-4" />
                生成尾帧
              </>
            )}
          </button>
          <CostBadge cost={DEFAULT_GENERATE_COST} />
        </div>
      </div>
    </div>
  )
}

function PlaceholderPanel({ step, readOnly }: { step: any; readOnly?: boolean }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-stone-300 bg-stone-50 py-16">
      <FileText className="h-10 w-10 text-stone-300" />
      <p className="mt-4 text-sm font-medium text-stone-500">
        {STEP_LABELS[step.stepType]} — 开发中
      </p>
      <p className="mt-1 text-xs text-stone-400">该功能将在后续版本上线</p>
    </div>
  )
}

/* ============================================================
   通用子组件
   ============================================================ */

function ProcessingBlock({ message }: { message: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16">
      <LoaderCircle className="h-8 w-8 animate-spin text-stone-400" />
      <p className="mt-3 text-sm text-stone-500">{message}</p>
    </div>
  )
}

function CollapsibleSection({
  title,
  children,
  defaultOpen = false,
  headerAction,
}: {
  title: string
  children: React.ReactNode
  defaultOpen?: boolean
  headerAction?: React.ReactNode
}) {
  const [open, setOpen] = useState(defaultOpen)

  return (
    <div className="rounded-lg border border-stone-200">
      <button
        onClick={() => setOpen(!open)}
        className="flex w-full items-center justify-between px-4 py-3 text-left transition hover:bg-stone-50"
      >
        <span className="text-sm font-semibold text-stone-800">{title}</span>
        <div className="flex items-center gap-2">
          {headerAction}
          {open ? (
            <ChevronUp className="h-4 w-4 text-stone-400" />
          ) : (
            <ChevronDown className="h-4 w-4 text-stone-400" />
          )}
        </div>
      </button>
      {open && <div className="border-t border-stone-100 px-4 py-3">{children}</div>}
    </div>
  )
}

