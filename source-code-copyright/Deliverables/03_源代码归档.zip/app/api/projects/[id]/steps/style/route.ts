export const dynamic = 'force-dynamic'
export const maxDuration = 300 // Vercel max 300s, 给 after() 后台任务足够时间

import { NextResponse } from 'next/server'
import { waitUntil } from '@vercel/functions'
import { getCurrentUserId } from '@/lib/auth-helpers'
import { checkProjectPermission } from '@/lib/project-permission'
import { prisma } from '@/lib/prisma'
import { getTextClient } from '@/lib/api-clients'
import { getProjectReferences } from '@/lib/style-ref'
import { loadPromptTemplate, extractJsonFromMarkdown, assignModelNoFallback } from '@/lib/prompts'
import { claimStepForGeneration, completeStep, failStep, canExecuteStep } from '@/lib/workflow-executor'
import { createQueue } from '@/lib/queue'
import { processStyleGeneration } from '@/lib/style-processor'
import { checkPoints, deductPointsAndLog } from '@/lib/points'
import { GENERATION_COSTS, calculateBatchCost } from '@/lib/points-config'
import { logOperation } from '@/lib/operations'
import { getCurrentOperationId } from '@/lib/supplier-observability'

const styleQueue = createQueue('style-generation')

/**
 * 生成风格提示词（供 generate-prompts 和 generate-images 共用）
 * 成功返回 { prompts, styleOptions }，失败抛出异常（调用方需 catch 并 failStep）
 */
async function generateStylePrompts(
  project: any,
  frameworkStep: any,
  stepId: string,
  aspectRatio: string = '16:9'
): Promise<{ prompts: any[]; styleOptions: any[] }> {
  const framework = project.framework || (frameworkStep.outputData as any)
  const storyBrief = framework?.synopsis || framework?.storyBrief || ''
  const visualKeywords = framework?.visualStyle || framework?.styleGuide || framework?.visualKeywords || ''
  const mood = framework?.mood || framework?.atmosphere || ''
  const characters = framework?.characters || []
  const characterBlock = characters.length > 0
    ? `【角色设定】\n${characters.map((c: any) => `- ${c.name}（${c.role}）：${c.description || ''}`).join('\n')}`
    : '【角色设定】无具体角色'

  const refs = await getProjectReferences(project.id).catch(() => [])
  const refLabels = refs.filter((r: any) => r.labels?.length).flatMap((r: any) => r.labels)
  const hasRefs = refs.length > 0
  const visualRefBlock = hasRefs
    ? `【用户上传了 ${refs.length} 张视觉参考图${refLabels.length > 0 ? `，标签：${refLabels.join('、')}` : ''}】\n` +
      `请仔细分析这些参考图：如果图中包含角色/吉祥物/产品形象，在生成三种风格方案时，必须保留其核心视觉识别特征（颜色、体型、服装、头饰/发型、标志性配件），仅改变艺术媒介和渲染风格。三种风格方案应围绕同一组主体展开，方便用户对比不同风格下的同一角色/场景。`
    : '【无视觉参考图】请基于故事梗概、视觉关键词和角色设定生成三种风格方案。'

  const prompt = loadPromptTemplate('style-generation', {
    STORY_BRIEF: storyBrief,
    VISUAL_KEYWORDS: visualKeywords,
    MOOD: mood,
    CHARACTERS: characterBlock,
    VISUAL_REFERENCES: visualRefBlock,
    ASPECT_RATIO: aspectRatio,
  })

  const textClient = await getTextClient()
  let resultText: string
  if (hasRefs) {
    const refUrls = refs.filter(r => r.url).map(r => r.url)
    console.log(`[STYLE-PROMPT-VISION] 使用多模态生成风格提示词，参考图 ${refUrls.length} 张，比例 ${aspectRatio}`)
    resultText = await textClient.generateVision({
      prompt,
      imageUrls: refUrls,
      imageLabels: refLabels,
      temperature: 0.7,
      maxTokens: 4096,
    })
  } else {
    resultText = await textClient.generate(prompt, { temperature: 0.7, maxTokens: 4096 })
  }
  const parsed = extractJsonFromMarkdown(resultText)

  let styleOptions: any[] = []
  if (Array.isArray(parsed)) {
    styleOptions = parsed
  } else if (Array.isArray(parsed.styles)) {
    styleOptions = parsed.styles.map((s: any, i: number) => ({
      id: s.id || String(i + 1),
      styleName: s.styleName || s.label || `风格 ${i + 1}`,
      styleDescription: s.styleDescription || s.description || '',
      prompt: s.prompt || s.stylePrompt || '',
      modelNo: s.modelNo,
    }))
  } else if (Array.isArray(parsed.styleOptions)) {
    styleOptions = parsed.styleOptions
  }

  styleOptions = assignModelNoFallback(styleOptions)
  console.log('[STYLE-MODEL-ASSIGN] LLM 分配结果:', styleOptions.map((s: any) =>
    ({ name: s.styleName, modelNo: s.modelNo })
  ))

  const prompts = styleOptions.map((s, i) => ({
    id: `prompt_${i + 1}`,
    chineseDesc: s.styleDescription || s.description || '',
    englishPrompt: s.prompt || s.stylePrompt || '',
    target: `style_sample_${i + 1}`,
    styleName: s.styleName || `风格 ${i + 1}`,
    styleId: s.id || String(i + 1),
    modelNo: s.modelNo,
  }))

  const step = await prisma.workflowStep.findUnique({ where: { id: stepId } })
  await prisma.workflowStep.update({
    where: { id: stepId },
    data: {
      status: 'PENDING' as any,
      outputData: {
        ...(step?.outputData as any || {}),
        prompts,
        styleOptions: styleOptions.map((s, i) => ({
          ...s,
          id: s.id || String(i + 1),
          imageUrl: null,
        })),
        selectedStyleId: null,
        styleRefUrl: null,
        generatedCount: 0,
        aspectRatio,
      },
    },
  })

  console.log(`[STYLE-PROMPT] 生成 ${prompts.length} 条提示词`)
  return { prompts, styleOptions }
}

export async function POST(req: Request, props: { params: Promise<{ id: string }> }) {
  const params = await props.params;
  const userId = await getCurrentUserId()
  if (!userId) {
    return NextResponse.json({ error: 'AUTH_001' }, { status: 401 })
  }

  const project = await prisma.project.findUnique({ where: { id: params.id } })
  if (!project) {
    return NextResponse.json({ error: 'AUTH_002' }, { status: 404 })
  }
  const permission = await checkProjectPermission(project.id)
  if (!permission.allowed) {
    return permission.response
  }

  if (!(await canExecuteStep(params.id, 'STYLE'))) {
    return NextResponse.json({ error: 'WORKFLOW_002' }, { status: 400 })
  }

  const frameworkStep = await prisma.workflowStep.findUnique({
    where: { projectId_stepType: { projectId: params.id, stepType: 'FRAMEWORK' } }
  })
  if (!frameworkStep || frameworkStep.status !== 'COMPLETED') {
    return NextResponse.json({ error: 'WORKFLOW_003' }, { status: 400 })
  }

  const step = await prisma.workflowStep.findUnique({
    where: { projectId_stepType: { projectId: params.id, stepType: 'STYLE' } }
  })
  if (!step) {
    return NextResponse.json({ error: 'WORKFLOW_004' }, { status: 400 })
  }

  const body = await req.json().catch(() => ({}))
  const force = body?.force === true
  const action: 'generate-prompts' | 'generate-images' = body?.action || 'generate-images'

  // === generate-prompts: 只生成提示词，不生图 ===
  if (action === 'generate-prompts') {
    const promptPointsCheck = await checkPoints(GENERATION_COSTS.DEFAULT, params.id, 'generation.style_prompts', 'TEXT')
    if (!promptPointsCheck.ok) {
      return NextResponse.json({ error: 'POINTS_001', message: '点数不足，请联系管理员充值' }, { status: 403 })
    }

    try {
      console.log('[STYLE-PROMPT] 收到 generate-prompts 请求')
      const aspectRatio = body?.aspectRatio || '16:9'
      const { prompts } = await generateStylePrompts(project, frameworkStep, step.id, aspectRatio)
      await deductPointsAndLog(userId, promptPointsCheck.cost, 'generate', { projectId: params.id, workflowStepId: step.id, success: true })
      return NextResponse.json({
        success: true,
        status: 'PROMPT_READY',
        prompts,
      })
    } catch (e: any) {
      // 工作指令.txt（2026-06-04）：区分 AbortError（超时）与其他错误，给用户更友好的提示
      const isAbort = e?.name === 'AbortError' || /aborted|timeout|timed out/i.test(e?.message || '')
      const errorMessage = isAbort
        ? '提示词生成超时（模型响应较慢），请稍后重试'
        : e.message
      console.error(`[STYLE-PROMPT] 失败: ${errorMessage}`, e?.stack?.slice(0, 300))
      await failStep(step.id, errorMessage)
      await deductPointsAndLog(userId, promptPointsCheck.cost, 'error', { projectId: params.id, workflowStepId: step.id, success: false, errorMessage })
      return NextResponse.json({ error: 'API_001', message: errorMessage }, { status: 500 })
    }
  }

  // === generate-images: 读取已保存提示词，执行生图 ===
  if (action === 'generate-images') {
    const aspectRatio = body?.aspectRatio || '16:9'
    const imageModel = body?.imageModel
    console.log(`[ASPECT-RATIO] [STYLE-IMAGE] 用户选择比例: ${aspectRatio}`)
    console.log(`[MODEL-SELECT] [STYLE-IMAGE] 用户选择模型: ${imageModel || '默认'}`)

    const existingOutput = (step.outputData as any) || {}
    const prompts = existingOutput.prompts || []
    // 工作指令.txt（2026-06-04）：增加详细日志，帮助排查 prompts 数据流断裂
    console.log('[STYLE-IMAGE] existingOutput keys:', Object.keys(existingOutput))
    console.log('[STYLE-IMAGE] prompts count:', prompts.length)
    console.log('[STYLE-IMAGE] step.status:', step.status, 'step.id:', step.id)
    // 工作指令.txt（2026-06-07）：prompts 为空时自动触发提示词生成，不返回 400
    let resolvedPrompts = prompts
    let resolvedStyleOptions = existingOutput.styleOptions || []
    if (resolvedPrompts.length === 0) {
      console.warn('[STYLE-IMAGE] No prompts found, auto-triggering prompt generation')
      const promptPointsCheck = await checkPoints(GENERATION_COSTS.DEFAULT, params.id, 'generation.style_prompts', 'TEXT')
      if (!promptPointsCheck.ok) {
        return NextResponse.json({ error: 'POINTS_001', message: '点数不足，请联系管理员充值' }, { status: 403 })
      }
      try {
        const generated = await generateStylePrompts(project, frameworkStep, step.id, aspectRatio)
        resolvedPrompts = generated.prompts
        resolvedStyleOptions = generated.styleOptions
        console.log(`[STYLE-IMAGE] Auto-generated ${resolvedPrompts.length} prompts, continuing to image generation`)
        await deductPointsAndLog(userId, promptPointsCheck.cost, 'generate', { projectId: params.id, workflowStepId: step.id, success: true })
      } catch (promptErr: any) {
        const isAbort = promptErr?.name === 'AbortError' || /aborted|timeout|timed out/i.test(promptErr?.message || '')
        const errorMessage = isAbort
          ? '提示词生成超时（模型响应较慢），请稍后重试'
          : promptErr.message
        console.error(`[STYLE-IMAGE] Auto-prompt generation failed: ${errorMessage}`, promptErr?.stack?.slice(0, 300))
        await failStep(step.id, errorMessage)
        await deductPointsAndLog(userId, promptPointsCheck.cost, 'error', { projectId: params.id, workflowStepId: step.id, success: false, errorMessage })
        return NextResponse.json({ error: 'API_001', message: errorMessage }, { status: 500 })
      }
    }

    const imageCost = calculateBatchCost(GENERATION_COSTS.STYLE_UNIFY, resolvedPrompts.length)
    const pointsCheck = await checkPoints(imageCost, params.id, 'generation.style_unify', 'IMAGE')
    if (!pointsCheck.ok) {
      return NextResponse.json({ error: 'POINTS_001', message: '点数不足，请联系管理员充值' }, { status: 403 })
    }

    // force=true 时清空旧资产（必须重新读取最新 outputData，避免覆盖自动生成的 prompts）
    if (force) {
      console.log('[STYLE-IMAGE] force=true, clearing old assets')
      await prisma.asset.deleteMany({
        where: { projectId: params.id, step: { stepType: 'STYLE' } }
      })
      const latestStep = await prisma.workflowStep.findUnique({ where: { id: step.id } })
      const latestOutput = (latestStep?.outputData as any) || existingOutput
      await prisma.workflowStep.update({
        where: { id: step.id },
        data: { status: 'PENDING' as any, outputData: latestOutput, errorMessage: null },
      })
    }

    if (!(await claimStepForGeneration(step.id))) {
      return NextResponse.json(
        { success: true, status: 'PROCESSING', alreadyRunning: true, message: '该步骤的生成任务已在进行中，请等待当前任务完成' },
      )
    }

    // 构建 styleOptions 用于生图（携带 modelNo）
    const styleOptions = resolvedPrompts.map((p: any) => ({
      id: p.styleId || p.id,
      styleName: p.styleName,
      styleDescription: p.chineseDesc,
      prompt: p.englishPrompt,
      imageUrl: null,
      modelNo: p.modelNo,
    }))

    try {
      const useQueue = process.env.STYLE_USE_QUEUE === '1'
      let queued = false

      if (useQueue) {
        try {
          await styleQueue.add(
            'generate-style-images',
            { stepId: step.id, projectId: params.id, styleOptions, aspectRatio, imageModel, operationId: getCurrentOperationId(), operationUserId: userId, billing: { billingSource: pointsCheck.billingSource, billingGroupId: pointsCheck.billingGroupId, unitCost: GENERATION_COSTS.STYLE_UNIFY } },
            {
              // jobId 按 step 去重：attempts 重试 / 被 Vercel 杀掉后重投时不会并存
              // 第二个任务，避免重复上传资产与重复扣费
              jobId: `style:${step.id}`,
              attempts: 2,
              backoff: { type: 'exponential', delay: 3000 },
              removeOnComplete: 50,
              removeOnFail: 50,
            }
          )
          queued = true
          console.log('[STYLE-IMAGE] Job queued via BullMQ')
        } catch (queueErr: any) {
          console.warn('[STYLE-IMAGE] BullMQ queue failed, fallback to setImmediate:', queueErr.message)
        }
      }

      if (!queued) {
        console.log(`[STYLE-IMAGE] 启动 waitUntil 后台任务，stepId=${step.id}`)
        waitUntil(
          (async () => {
            console.log(`[STYLE-IMAGE] waitUntil 回调开始执行，stepId=${step.id}`)
            try {
              await processStyleGeneration(step.id, params.id, styleOptions, aspectRatio, imageModel, userId, {
                userId,
                billingSource: pointsCheck.billingSource,
                billingGroupId: pointsCheck.billingGroupId,
                unitCost: GENERATION_COSTS.STYLE_UNIFY,
              })
              console.log(`[STYLE-IMAGE] waitUntil 回调成功完成，stepId=${step.id}`)
            } catch (e: any) {
              // 工作指令.txt（2026-06-02 卡死修复）：后台处理失败必须标记状态为 FAILED
              const errMessage = e?.message || 'background style generation failed'
              const errDetail = (e?.stack || '').toString().slice(0, 500)
              console.error('[STYLE-IMAGE] Background processing failed:', errMessage, errDetail)
              try {
                await failStep(step.id, `${errMessage} | detail: ${errDetail}`)
              } catch (failErr: any) {
                console.error('[STYLE-IMAGE] failStep also failed:', failErr?.message)
                // 兜底：直接更新数据库
                try {
                  await prisma.workflowStep.update({
                    where: { id: step.id },
                    data: { status: 'FAILED' as any, errorMessage: errMessage.slice(0, 200) },
                  })
                } catch {}
              }
              // 记录失败日志
              try {
                await logOperation({
                  userId,
                  projectId: params.id,
                  workflowStepId: step.id,
                  actionType: 'error',
                  cost: 0,
                  status: 'failed',
                  metadata: { error: errMessage, detail: errDetail, phase: 'background-generation' },
                })
              } catch {}
            }
          })()
        )
      }

      await deductPointsAndLog(userId, pointsCheck.cost, 'generate', { projectId: params.id, workflowStepId: step.id, success: true })
      console.log(`[STYLE-IMAGE] 用户确认，开始生图，共 ${resolvedPrompts.length} 条，比例 ${aspectRatio}，模型 ${imageModel || '默认'}`)
      return NextResponse.json({
        success: true,
        message: queued ? '风格生成任务已入队' : '风格生成任务已在后台启动',
        status: 'PROCESSING',
      })
    } catch (e: any) {
      await failStep(step.id, e.message)
      await deductPointsAndLog(userId, pointsCheck.cost, 'error', { projectId: params.id, workflowStepId: step.id, success: false, errorMessage: e.message })
      return NextResponse.json({ error: 'API_001', message: e.message }, { status: 500 })
    }
  }

  // === 默认兼容：无 action 时走原有完整流程（向后兼容） ===
  const aspectRatioCompat = body?.aspectRatio || '16:9'

  if (!force && step.status === 'COMPLETED' && step.outputData) {
    console.log('[STYLE] step already completed, returning cached result')
    return NextResponse.json({ success: true, data: step.outputData, cached: true })
  }

  if (!force && step.status === 'PROCESSING') {
    return NextResponse.json({ success: true, message: '生成任务已在进行中，请等待当前任务完成', status: 'PROCESSING', alreadyRunning: true })
  }

  if (force) {
    console.log('[STYLE] force=true, clearing old assets')
    await prisma.asset.deleteMany({
      where: { projectId: params.id, step: { stepType: 'STYLE' } }
    })
    // 工作指令.txt（2026-06-04）：force=true 时不应清空 prompts，避免用户编辑的提示词丢失。
    // 仅清空图片相关字段，保留 prompts、styleOptions 的文本数据。
    const existingOutput = (step.outputData as any) || {}
    const preservedOutput = {
      prompts: existingOutput.prompts,
      styleOptions: existingOutput.styleOptions?.map((s: any) => ({
        ...s,
        imageUrl: null,
        assetId: undefined,
      })),
      selectedStyleId: null,
      styleRefUrl: null,
      generatedCount: 0,
    }
    console.log('[STYLE] force=true, preserved prompts count:', existingOutput.prompts?.length || 0)
    await prisma.workflowStep.update({
      where: { id: step.id },
      data: { status: 'PENDING' as any, outputData: preservedOutput, errorMessage: null },
    })
  }

  // The compatibility path always requests three style samples. STYLE_UNIFY is
  // the per-image price, not a flat price for all three supplier calls.
  const totalCost = GENERATION_COSTS.DEFAULT + calculateBatchCost(GENERATION_COSTS.STYLE_UNIFY, 3)
  const pointsCheck = await checkPoints(totalCost, params.id, 'generation.style_unify', 'IMAGE')
  if (!pointsCheck.ok) {
    return NextResponse.json({ error: 'POINTS_001', message: '点数不足，请联系管理员充值' }, { status: 403 })
  }

  if (!(await claimStepForGeneration(step.id))) {
    return NextResponse.json(
      { success: true, status: 'PROCESSING', alreadyRunning: true, message: '该步骤的生成任务已在进行中，请等待当前任务完成' },
    )
  }

  try {
    const framework = project.framework || (frameworkStep.outputData as any)
    const storyBrief = framework?.synopsis || framework?.storyBrief || ''
    const visualKeywords = framework?.visualStyle || framework?.styleGuide || framework?.visualKeywords || ''
    const mood = framework?.mood || framework?.atmosphere || ''

    const refsCompat = await getProjectReferences(params.id).catch(() => [])
    const refLabelsCompat = refsCompat.filter((r: any) => r.labels?.length).flatMap((r: any) => r.labels)
    const hasRefsCompat = refsCompat.length > 0
    const visualRefBlockCompat = hasRefsCompat
      ? `【用户上传了 ${refsCompat.length} 张视觉参考图${refLabelsCompat.length > 0 ? `，标签：${refLabelsCompat.join('、')}` : ''}】\n` +
        `请仔细分析这些参考图：如果图中包含角色/吉祥物/产品形象，在生成三种风格方案时，必须保留其核心视觉识别特征（颜色、体型、服装、头饰/发型、标志性配件），仅改变艺术媒介和渲染风格。`
      : '【无视觉参考图】请基于故事梗概、视觉关键词和角色设定生成三种风格方案。'

    const charactersCompat = framework?.characters || []
    const characterBlockCompat = charactersCompat.length > 0
      ? `【角色设定】\n${charactersCompat.map((c: any) => `- ${c.name}（${c.role}）：${c.description || ''}`).join('\n')}`
      : '【角色设定】无具体角色'

    // 1. 用文本模板生成 3 组风格提示词
    const prompt = loadPromptTemplate('style-generation', {
      STORY_BRIEF: storyBrief,
      VISUAL_KEYWORDS: visualKeywords,
      MOOD: mood,
      CHARACTERS: characterBlockCompat,
      VISUAL_REFERENCES: visualRefBlockCompat,
      ASPECT_RATIO: aspectRatioCompat,
    })
    const textClient = await getTextClient()
    let resultText: string
    if (hasRefsCompat) {
      const refUrlsCompat = refsCompat.filter(r => r.url).map(r => r.url)
      console.log(`[STYLE-PROMPT-VISION] 使用多模态生成风格提示词，参考图 ${refUrlsCompat.length} 张，比例 ${aspectRatioCompat}`)
      resultText = await textClient.generateVision({
        prompt,
        imageUrls: refUrlsCompat,
        imageLabels: refLabelsCompat,
        temperature: 0.7,
        maxTokens: 4096,
      })
    } else {
      resultText = await textClient.generate(prompt, { temperature: 0.7, maxTokens: 4096 })
    }
    const parsed = extractJsonFromMarkdown(resultText)

    // 解析风格选项
    let styleOptions: any[] = []
    if (Array.isArray(parsed)) {
      styleOptions = parsed
    } else if (Array.isArray(parsed.styles)) {
      styleOptions = parsed.styles.map((s: any, i: number) => ({
        id: s.id || String(i + 1),
        styleName: s.styleName || s.label || `风格 ${i + 1}`,
        styleDescription: s.styleDescription || s.description || '',
        prompt: s.prompt || s.stylePrompt || '',
      }))
    } else if (Array.isArray(parsed.styleOptions)) {
      styleOptions = parsed.styleOptions
    }

    styleOptions = styleOptions.map((s, i) => ({
      ...s,
      id: s.id || String(i + 1),
      imageUrl: null,
    }))

    if (styleOptions.length < 3) {
      throw new Error(`风格选项不足：期望 3 组，实际得到 ${styleOptions.length} 组`)
    }

    // 2. 将风格选项暂存到步骤输出中
    const outputData = {
      styleOptions,
      selectedStyleId: null,
      styleRefUrl: null,
      generatedCount: 0,
    }
    await prisma.workflowStep.update({
      where: { id: step.id },
      data: { outputData },
    })

    // 3. 任务派发：默认走 after() 后台处理（保证无 Redis/无独立 Worker 也能完成）。
    //    仅当显式开启 STYLE_USE_QUEUE=1 时才尝试 BullMQ，避免"入队成功但 Worker 未启动"导致卡 95%。
    const useQueue = process.env.STYLE_USE_QUEUE === '1'
    let queued = false

    if (useQueue) {
      try {
        await styleQueue.add(
          'generate-style-images',
          { stepId: step.id, projectId: params.id, styleOptions, operationId: getCurrentOperationId(), operationUserId: userId, billing: { billingSource: pointsCheck.billingSource, billingGroupId: pointsCheck.billingGroupId, unitCost: GENERATION_COSTS.STYLE_UNIFY } },
          {
            jobId: `style:${step.id}`,
            attempts: 2,
            backoff: { type: 'exponential', delay: 3000 },
            removeOnComplete: 50,
            removeOnFail: 50,
          }
        )
        queued = true
        console.log('[STYLE] Job queued via BullMQ')
      } catch (queueErr: any) {
        console.warn('[STYLE] BullMQ queue failed, fallback to after():', queueErr.message)
      }
    }

    if (!queued) {
      // 后台直接处理：HTTP 立即返回，生成在后台执行；processStyleGeneration 内部已有
      // try/catch + failStep，绝不会让 step 卡在 PROCESSING。
      console.log(`[STYLE] 启动 waitUntil 后台任务（compat），stepId=${step.id}`)
      waitUntil(
        (async () => {
          console.log(`[STYLE] waitUntil 回调开始执行（compat），stepId=${step.id}`)
          try {
            await processStyleGeneration(step.id, params.id, styleOptions, aspectRatioCompat, undefined, userId, {
              userId,
              billingSource: pointsCheck.billingSource,
              billingGroupId: pointsCheck.billingGroupId,
              unitCost: GENERATION_COSTS.STYLE_UNIFY,
            })
            console.log(`[STYLE] waitUntil 回调成功完成（compat），stepId=${step.id}`)
          } catch (e: any) {
            // 工作指令.txt（2026-06-02 卡死修复）：后台处理失败必须标记状态为 FAILED
            const errMessage = e?.message || 'background style generation failed'
            const errDetail = (e?.stack || '').toString().slice(0, 500)
            console.error('[STYLE] Background processing failed:', errMessage, errDetail)
            try {
              await failStep(step.id, `${errMessage} | detail: ${errDetail}`)
            } catch (failErr: any) {
              console.error('[STYLE] failStep also failed:', failErr?.message)
              try {
                await prisma.workflowStep.update({
                  where: { id: step.id },
                  data: { status: 'FAILED' as any, errorMessage: errMessage.slice(0, 200) },
                })
              } catch {}
            }
            try {
              await logOperation({
                userId,
                projectId: params.id,
                workflowStepId: step.id,
                actionType: 'error',
                cost: 0,
                status: 'failed',
                metadata: { error: errMessage, detail: errDetail, phase: 'background-generation-compat' },
              })
            } catch {}
          }
        })()
      )
    }

    await deductPointsAndLog(userId, pointsCheck.cost, 'generate', { projectId: params.id, workflowStepId: step.id, success: true })
    return NextResponse.json({
      success: true,
      message: queued ? '风格生成任务已入队' : '风格生成任务已在后台启动',
      status: 'PROCESSING',
      data: outputData,
    })
  } catch (e: any) {
    await failStep(step.id, e.message)
    await deductPointsAndLog(userId, pointsCheck.cost, 'error', { projectId: params.id, workflowStepId: step.id, success: false, errorMessage: e.message })
    return NextResponse.json({ error: 'API_001', message: e.message }, { status: 500 })
  }
}

export async function GET(_req: Request, props: { params: Promise<{ id: string }> }) {
  const params = await props.params;
  const access = await checkProjectPermission(params.id)
  if (!access.allowed) return access.response

  const step = await prisma.workflowStep.findUnique({
    where: { projectId_stepType: { projectId: params.id, stepType: 'STYLE' } },
    include: { resultAssets: true },
  })
  if (!step) return NextResponse.json({ status: 'not_found' })

  const outputData = step.outputData as any
  let styleOptions = outputData?.styleOptions || []
  const assets = step.resultAssets || []
  if (styleOptions.length > 0 && assets.length > 0) {
    styleOptions = styleOptions.map((opt: any, idx: number) => {
      const asset = assets.find((a: any) => (a.metadata as any)?.styleId === opt.id)
      return {
        ...opt,
        imageUrl: asset?.url || opt.imageUrl,
        assetId: asset?.id,
      }
    })
  }

  return NextResponse.json({
    status: step.status,
    outputData: {
      ...outputData,
      styleOptions,
    },
    assets: step.resultAssets,
    errorMessage: step.errorMessage,
  })
}

export async function PATCH(req: Request, props: { params: Promise<{ id: string }> }) {
  const params = await props.params;
  const userId = await getCurrentUserId()
  if (!userId) {
    return NextResponse.json({ error: 'AUTH_001' }, { status: 401 })
  }

  const project = await prisma.project.findUnique({ where: { id: params.id } })
  if (!project) {
    return NextResponse.json({ error: 'AUTH_002' }, { status: 404 })
  }
  const permission = await checkProjectPermission(project.id)
  if (!permission.allowed) {
    return permission.response
  }

  const body = await req.json()
  const { selectedStyleId, styleRefUrl, prompts } = body

  // 工作指令.txt（2026-05-24）：支持 prompts 文本编辑（与风格选择互斥分支）
  if (Array.isArray(prompts)) {
    const existing = await prisma.workflowStep.findUnique({
      where: { projectId_stepType: { projectId: params.id, stepType: 'STYLE' } },
    })
    if (!existing) {
      return NextResponse.json({ error: 'WORKFLOW_004' }, { status: 400 })
    }
    const existingOutput = (existing.outputData || {}) as any
    const newOutput = { ...existingOutput, prompts }
    await prisma.workflowStep.update({
      where: { id: existing.id },
      data: { outputData: newOutput },
    })
    console.log('[TEXT-EDIT-STYLE] 保存 prompts 成功, 数量:', prompts.length)
    return NextResponse.json({ success: true })
  }

  // 【强制日志1】确认收到什么
  console.log('[STYLE-PATCH-REQ] 收到 body:', JSON.stringify(body))
  console.log('[STYLE-PATCH-REQ] selectedStyleId:', selectedStyleId)
  console.log('[STYLE-PATCH-REQ] styleRefUrl:', styleRefUrl)
  console.log('[STYLE-PATCH-REQ] styleRefUrl 类型:', typeof styleRefUrl)
  console.log('[STYLE-PATCH-REQ] styleRefUrl 是否http开头:', styleRefUrl?.startsWith?.('http'))

  // 工作指令.txt（修复一-后端）：放宽校验。
  // R2 上传失败时，前端会拿到 data:image/png;base64,... 的 URL；
  // 浏览器能显示说明 URL 有效，后端不应再强制 http 前缀。
  if (
    !selectedStyleId ||
    !styleRefUrl ||
    typeof styleRefUrl !== 'string' ||
    styleRefUrl.trim() === ''
  ) {
    return NextResponse.json({ error: 'VALIDATION_001', message: '缺少有效参数' }, { status: 400 })
  }

  // 读取现有 output
  const existing = await prisma.workflowStep.findUnique({
    where: { projectId_stepType: { projectId: params.id, stepType: 'STYLE' } },
  })
  console.log('[STYLE-PATCH-DB] 更新前 outputData:', JSON.stringify(existing?.outputData).slice(0, 500))

  const existingOutput = (existing?.outputData || {}) as any
  // 记录用户最近一次选中的风格图比例，供后续步骤作为默认比例
  const selectedAspectRatio = existingOutput?.aspectRatio || '16:9'
  const newOutput = {
    ...existingOutput,
    selectedStyleId,
    styleRefUrl,
    selectedAspectRatio,
  }

  const selectedAsset = await prisma.asset.findFirst({
    where: {
      projectId: params.id,
      stepId: existing!.id,
      metadata: { path: ['styleId'], equals: selectedStyleId },
    },
    select: { id: true },
  })

  // 更新数据库（工作流、项目状态和采用结果同一事务提交）
  const updated = await prisma.$transaction(async (tx: any) => {
    const nextStep = await tx.workflowStep.update({
      where: { id: existing!.id },
      data: { outputData: newOutput, status: 'COMPLETED' },
    })
    await tx.project.update({
      where: { id: params.id },
      data: { selectedStyleId, stepStyleDone: true },
    })
    await tx.operationResult.updateMany({
      where: {
        operation: { projectId: params.id },
        targetType: 'STYLE',
        adoptionStatus: { in: ['ACTIVE', 'ADOPTED'] },
        ...(selectedAsset ? { assetId: { not: selectedAsset.id } } : {}),
      },
      data: { adoptionStatus: 'SUPERSEDED' },
    })
    if (selectedAsset) {
      await tx.operationResult.updateMany({
        where: { operation: { projectId: params.id }, assetId: selectedAsset.id },
        data: {
          targetType: 'STYLE',
          targetKey: `style:${selectedStyleId}`,
          targetLabel: selectedStyleId,
          adoptionStatus: 'ADOPTED',
          adoptedAt: new Date(),
          adoptedById: permission.user.id,
        },
      })
    }
    return nextStep
  })

  // 【强制日志3】确认写入成功
  console.log('[STYLE-PATCH-DB] 更新后 outputData:', JSON.stringify(updated.outputData).slice(0, 500))
  console.log('[STYLE-PATCH-DB] 更新后 styleRefUrl:', (updated.outputData as any)?.styleRefUrl)
  console.log('[STYLE-PATCH-DB] project.selectedStyleId 已同步:', selectedStyleId)

  return NextResponse.json({ success: true, data: updated.outputData })
}
