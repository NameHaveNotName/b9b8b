export const dynamic = 'force-dynamic'
export const maxDuration = 300

import { NextResponse } from 'next/server'
import { getCurrentUserId } from '@/lib/auth-helpers'
import { checkProjectPermission } from '@/lib/project-permission'
import { prisma } from '@/lib/prisma'
import { getTextClient, getImageClient } from '@/lib/api-clients'
import { loadPromptTemplate, extractJsonFromMarkdown } from '@/lib/prompts'
import { claimStepForGeneration, completeStep, failStep, canExecuteStep } from '@/lib/workflow-executor'
import { getProjectDefaultAspectRatio } from '@/lib/server/workflow-state'
import { getStyleRefUrl, getProjectReferences } from '@/lib/style-ref'
import { IMAGE_MODELS } from '@/lib/models-config'
import { checkPoints, deductPointsAndLog, refundPointsAndLog } from '@/lib/points'
import { GENERATION_COSTS, calculateBatchCost } from '@/lib/points-config'

/**
 * 生成概念图提示词（供 generate-prompts 和 generate-images 共用）
 * 成功返回 { prompts, totalScenes }，失败抛出异常（调用方需 catch 并 failStep）
 */
async function generateConceptPrompts(
  project: any,
  frameworkStep: any,
  stepId: string
): Promise<{ prompts: any[]; totalScenes: number }> {
  const framework = (project.framework || frameworkStep.outputData) as any
  const acts = Array.isArray(framework?.acts) ? framework.acts : []

  const refs = await getProjectReferences(project.id).catch(() => [])
  const refLabels = refs.filter((r: any) => r.labels?.length).flatMap((r: any) => r.labels)
  const refHint = refs.length > 0
    ? `\n\n【用户上传的人物/场景参考图】用户上传了 ${refs.length} 张参考图${refLabels.length > 0 ? `，标签：${refLabels.join('、')}` : ''}。在生成 imagePrompt 时：1) 如果角色匹配参考图中的人物，可以直接写'参考图1中的XXX'，无需重新描述外貌特征。2) 如果场景匹配参考图中的环境，可以直接写'类似参考图2中的场景氛围'。`
    : ''

  const prompt = loadPromptTemplate('concept', {
    USER_INPUT: JSON.stringify({ framework }) + refHint
  })
  const textClient = await getTextClient()
  const resultText = await textClient.generate(prompt, { temperature: 0.7, maxTokens: 4096 })
  const parsed = extractJsonFromMarkdown(resultText)
  const parsedScenes = parsed.scenes || []

  const prompts: any[] = []
  for (const act of acts) {
    const actNo = act.actNo || act.actNumber || 1
    const keyScenes = Array.isArray(act.keyScenes) ? act.keyScenes : (Array.isArray(act.scenes) ? act.scenes : [])
    const sceneCount = Math.max(1, Math.min(keyScenes.length || 1, 3))
    for (let i = 0; i < sceneCount; i++) {
      const sceneDesc = keyScenes[i] || `幕${actNo}场景${i + 1}`
      const llmScene = parsedScenes.find(
        (s: any) => s.actNumber === actNo && s.sceneNumber === i + 1
      )
      // 过滤空白，确保 englishPrompt 是有效的英文内容
        const rawPrompt = llmScene?.imagePrompt || ''
        const isValidEnglish = rawPrompt.trim().length > 5 && /[a-zA-Z]{3,}/.test(rawPrompt)
        const imagePrompt = isValidEnglish
          ? rawPrompt.trim()
          : `Cinematic scene, ${sceneDesc}. Film still, 35mm Kodak Portra 400, atmospheric depth, 8k, poetic realism.`
        prompts.push({
        id: `prompt_act${actNo}_scene${i + 1}`,
        chineseDesc: sceneDesc,
        englishPrompt: imagePrompt,
        target: `concept_act${actNo}_scene${i + 1}`,
        actNumber: actNo,
        sceneIndex: i,
      })
    }
  }

  const step = await prisma.workflowStep.findUnique({ where: { id: stepId } })
  await prisma.workflowStep.update({
    where: { id: stepId },
    data: {
      status: 'PENDING' as any,
      outputData: {
        ...(step?.outputData as any || {}),
        prompts,
        totalScenes: prompts.length,
      },
    },
  })

  console.log(`[CONCEPT-PROMPT] 生成 ${prompts.length} 条提示词`)
  return { prompts, totalScenes: prompts.length }
}

export async function POST(req: Request, props: { params: Promise<{ id: string }> }) {
  const params = await props.params;
  const userId = await getCurrentUserId()
  if (!userId) {
    return NextResponse.json({ error: 'AUTH_001' }, { status: 401 })
  }

  const permission = await checkProjectPermission(params.id)
  if (!permission.allowed) {
    return permission.response
  }
  
  // 获取完整的项目对象（包含 framework 等字段）
  const project = await prisma.project.findUnique({ where: { id: params.id } })
  if (!project) {
    return NextResponse.json({ error: 'AUTH_002' }, { status: 404 })
  }

  if (!(await canExecuteStep(params.id, 'CONCEPT'))) {
    return NextResponse.json({ error: 'WORKFLOW_002' }, { status: 400 })
  }

  const frameworkStep = await prisma.workflowStep.findUnique({
    where: { projectId_stepType: { projectId: params.id, stepType: 'FRAMEWORK' } }
  })
  if (!frameworkStep || frameworkStep.status !== 'COMPLETED') {
    return NextResponse.json({ error: 'WORKFLOW_003' }, { status: 400 })
  }

  const step = await prisma.workflowStep.findUnique({
    where: { projectId_stepType: { projectId: params.id, stepType: 'CONCEPT' } }
  })
  if (!step) {
    return NextResponse.json({ error: 'WORKFLOW_004' }, { status: 400 })
  }

  // 支持整体重做：force=true 时跳过缓存检查
  const body = await req.json().catch(() => ({}))
  const force = body?.force === true
  const action: 'generate-prompts' | 'generate-images' = body?.action || 'generate-images'

  // === generate-prompts: 只生成提示词，不生图 ===
  if (action === 'generate-prompts') {
    const promptPointsCheck = await checkPoints(GENERATION_COSTS.DEFAULT, params.id, 'generation.concept_prompts', 'TEXT')
    if (!promptPointsCheck.ok) {
      return NextResponse.json({ error: 'POINTS_001', message: '点数不足，请联系管理员充值' }, { status: 403 })
    }

    try {
      console.log('[CONCEPT-PROMPT] 收到 generate-prompts 请求')
      const { prompts } = await generateConceptPrompts(project, frameworkStep, step.id)
      await deductPointsAndLog(userId, promptPointsCheck.cost, 'generate', { projectId: params.id, workflowStepId: step.id, success: true })
      return NextResponse.json({ success: true, status: 'PROMPT_READY', prompts })
    } catch (e: any) {
      const isAbort = e?.name === 'AbortError' || /aborted|timeout|timed out/i.test(e?.message || '')
      const errorMessage = isAbort
        ? '提示词生成超时（模型响应较慢），请稍后重试'
        : e.message
      console.error(`[CONCEPT-PROMPT] 失败: ${errorMessage}`, e?.stack?.slice(0, 300))
      await failStep(step.id, errorMessage)
      await deductPointsAndLog(userId, promptPointsCheck.cost, 'error', { projectId: params.id, workflowStepId: step.id, success: false, errorMessage })
      return NextResponse.json({ error: 'API_001', message: errorMessage }, { status: 500 })
    }
  }

  // === generate-images: 读取已保存提示词，waitUntil 后台流式生成 ===
  if (action === 'generate-images') {
    const defaultAspectRatio = await getProjectDefaultAspectRatio(params.id)
    const aspectRatio = body?.aspectRatio || defaultAspectRatio
    const imageModel = body?.imageModel
    console.log(`[ASPECT-RATIO] [CONCEPT-IMAGE] 用户选择比例: ${aspectRatio}`)
    console.log(`[MODEL-SELECT] [CONCEPT-IMAGE] 用户选择模型: ${imageModel || '默认'}`)

    const existingOutput = (step.outputData as any) || {}
    const prompts = existingOutput.prompts || []
    console.log('[CONCEPT-IMAGE] existingOutput keys:', Object.keys(existingOutput))
    console.log('[CONCEPT-IMAGE] prompts count:', prompts.length)

    // 工作指令.txt（2026-06-07）：prompts 为空时自动触发提示词生成，不返回 400
    let resolvedPrompts = prompts
    let autoPromptCost = 0
    if (resolvedPrompts.length === 0) {
      console.warn('[CONCEPT-IMAGE] No prompts found, auto-triggering prompt generation')
      const promptPointsCheck = await checkPoints(GENERATION_COSTS.DEFAULT, params.id, 'generation.concept_prompts', 'TEXT')
      if (!promptPointsCheck.ok) {
        return NextResponse.json({ error: 'POINTS_001', message: '点数不足，请联系管理员充值' }, { status: 403 })
      }
      try {
        const generated = await generateConceptPrompts(project, frameworkStep, step.id)
        resolvedPrompts = generated.prompts
        console.log(`[CONCEPT-IMAGE] Auto-generated ${resolvedPrompts.length} prompts, continuing to image generation`)
        await deductPointsAndLog(userId, promptPointsCheck.cost, 'generate', { projectId: params.id, workflowStepId: step.id, success: true })
        autoPromptCost = promptPointsCheck.cost
      } catch (promptErr: any) {
        const isAbort = promptErr?.name === 'AbortError' || /aborted|timeout|timed out/i.test(promptErr?.message || '')
        const errorMessage = isAbort
          ? '提示词生成超时（模型响应较慢），请稍后重试'
          : promptErr.message
        console.error(`[CONCEPT-IMAGE] Auto-prompt generation failed: ${errorMessage}`, promptErr?.stack?.slice(0, 300))
        await failStep(step.id, errorMessage)
        await deductPointsAndLog(userId, promptPointsCheck.cost, 'error', { projectId: params.id, workflowStepId: step.id, success: false, errorMessage })
        return NextResponse.json({ error: 'API_001', message: errorMessage }, { status: 500 })
      }
    }

    const imageCost = calculateBatchCost(GENERATION_COSTS.CONCEPT_ART, resolvedPrompts.length)
    const pointsCheck = await checkPoints(imageCost, params.id, 'generation.concept_art', 'IMAGE')
    if (!pointsCheck.ok) {
      return NextResponse.json({ error: 'POINTS_001', message: '点数不足，请联系管理员充值' }, { status: 403 })
    }

    // force=true 时清空旧资产（必须重新读取最新 outputData，避免覆盖自动生成的 prompts）
    if (force) {
      console.log('[CONCEPT-IMAGE] force=true, clearing old assets')
      await prisma.asset.deleteMany({
        where: { projectId: params.id, step: { stepType: 'CONCEPT' } }
      })
      const latestStep = await prisma.workflowStep.findUnique({ where: { id: step.id } })
      const latestOutput = (latestStep?.outputData as any) || existingOutput
      await prisma.workflowStep.update({
        where: { id: step.id },
        data: { status: 'PENDING' as any, outputData: latestOutput, errorMessage: null },
      })
    }

    if (!(await claimStepForGeneration(step.id))) {
      return NextResponse.json(
        { success: true, status: 'PROCESSING', alreadyRunning: true, message: '该步骤的生成任务已在进行中，请等待当前任务完成' },
      )
    }

    try {
      let styleRefUrl: string
      let stylePrompt: string
      try {
        const ref = await getStyleRefUrl(params.id)
        styleRefUrl = ref.styleRefUrl
        stylePrompt = ref.stylePrompt
      } catch (refErr: any) {
        console.error('[CONCEPT-IMAGE] 风格图提取失败：', refErr?.message)
        return NextResponse.json(
          { error: 'STORAGE_001', message: refErr?.message || '未找到有效风格参考图 URL' },
          { status: 400 }
        )
      }

      const characterAssets = await prisma.asset.findMany({
        where: { projectId: params.id, step: { stepType: 'CHARACTER' } },
      })
      const characterImageUrls = characterAssets
        .map((a: any) => a.url)
        .filter((u: any) => typeof u === 'string' && u.length > 0) as string[]
      const characterDescs = characterAssets
        .map((a: any) => ({
          name: (a.metadata as any)?.characterName || '',
          description:
            (a.metadata as any)?.chineseDesc ||
            (a.metadata as any)?.llmPrompt ||
            '',
        }))
        .filter((c: any) => c.name) as Array<{ name: string; description: string }>

      const refs = await getProjectReferences(params.id).catch(() => [])
      const userRefUrls = refs.filter(r => r.url).map(r => r.url)

      const imageClient = await getImageClient()
      const scenes = []
      const failedScenes: string[] = []
      const mockScenes: string[] = []

      for (const promptItem of resolvedPrompts) {
        try {
          const result = await imageClient.generateConceptScene(
            params.id,
            promptItem.englishPrompt,
            styleRefUrl,
            stylePrompt,
            characterImageUrls,
            undefined,
            aspectRatio,
            imageModel,
            characterDescs,
            userRefUrls
          )
          const asset = await prisma.asset.create({
            data: {
              projectId: params.id,
              createdById: userId,
              stepId: step.id,
              type: 'IMAGE',
              mimeType: 'image/png',
              storageKey: result.storageKey,
              url: result.url,
              metadata: {
                ...result.metadata,
                actNumber: promptItem.actNumber,
                sceneIndex: promptItem.sceneIndex,
                llmPrompt: promptItem.englishPrompt,
                prompt: promptItem.englishPrompt,
                aspectRatio,
                imageModel: imageModel || 'gpt-image-1',
              },
            },
          })
          scenes.push({
            actNumber: promptItem.actNumber,
            sceneIndex: promptItem.sceneIndex,
            assetId: asset.id,
            url: result.url,
            prompt: promptItem.englishPrompt,
            aspectRatio,
            isMock: !!result.metadata?.isMock,
            mockReason: result.metadata?.mockReason || null,
          })
          if (result.metadata?.isMock) {
            mockScenes.push(`幕${promptItem.actNumber}-场景${promptItem.sceneIndex + 1}`)
          }
        } catch (imgErr: any) {
          const sceneLabel = `幕${promptItem.actNumber}-场景${promptItem.sceneIndex + 1}`
          console.error(`[CONCEPT-IMAGE] ${sceneLabel} 生图失败:`, imgErr?.message)
          failedScenes.push(sceneLabel)
        }
      }

      if (scenes.length === 0) {
        const errMsg = `所有概念图生图均失败${failedScenes.length > 0 ? '（' + failedScenes.join(', ') + '）' : ''}`
        await failStep(step.id, errMsg)
        await deductPointsAndLog(userId, pointsCheck.cost, 'error', { projectId: params.id, workflowStepId: step.id, success: false, errorMessage: errMsg })
        return NextResponse.json({ error: 'API_001', message: errMsg }, { status: 500 })
      }

      await completeStep(step.id, { scenes, totalScenes: scenes.length, imageModel: imageModel || 'gpt-image-1', aspectRatio })
      await deductPointsAndLog(userId, pointsCheck.cost, 'generate', { projectId: params.id, workflowStepId: step.id, success: true })
      // 失败与 Mock 占位都不算有效产出，按条退款
      const unbilledCount = failedScenes.length + mockScenes.length
      if (unbilledCount > 0) {
        await refundPointsAndLog(userId, calculateBatchCost(GENERATION_COSTS.CONCEPT_ART, unbilledCount), {
          projectId: params.id,
          workflowStepId: step.id,
          billingSource: pointsCheck.billingSource,
          billingGroupId: pointsCheck.billingGroupId,
          finalStatus: 'PARTIAL',
          errorMessage: `${unbilledCount}/${resolvedPrompts.length} 张概念图未使用 AI 模型生成（${failedScenes.length} 张失败、${mockScenes.length} 张回退为占位图），对应点数已退回`,
        })
      }
      console.log(`[CONCEPT-IMAGE] 完成: 成功 ${scenes.length}/${resolvedPrompts.length} 条，失败: ${failedScenes.join(', ') || '无'}，Mock: ${mockScenes.join(', ') || '无'}`)
      return NextResponse.json({ success: true, data: { scenes, totalScenes: scenes.length } })
    } catch (e: any) {
      await failStep(step.id, e.message)
      await deductPointsAndLog(userId, pointsCheck.cost, 'error', { projectId: params.id, workflowStepId: step.id, success: false, errorMessage: e.message })
      return NextResponse.json({ error: 'API_001', message: e.message }, { status: 500 })
    }
  }

  // === 默认兼容：无 action 时走原有完整流程 ===
  if (!force && step.status === 'COMPLETED' && step.outputData) {
    console.log('[CONCEPT] step already completed, returning cached result')
    return NextResponse.json({ success: true, data: step.outputData, cached: true })
  }

  // 整体重做：重置状态
  if (force) {
    console.log('[CONCEPT] force=true, clearing old assets')
    await prisma.asset.deleteMany({
      where: { projectId: params.id, step: { stepType: 'CONCEPT' } }
    })
    const existingOutput = (step.outputData as any) || {}
    const preservedOutput = {
      prompts: existingOutput.prompts,
      totalScenes: existingOutput.totalScenes,
    }
    console.log('[CONCEPT] force=true, preserved prompts count:', existingOutput.prompts?.length || 0)
    await prisma.workflowStep.update({
      where: { id: step.id },
      data: { status: 'PENDING' as any, outputData: preservedOutput, errorMessage: null },
    })
  }

  const framework = (project.framework || frameworkStep.outputData) as any
  const acts = Array.isArray(framework?.acts) ? framework.acts : []
  const estimatedImageCount = acts.reduce((sum: number, act: any) => {
    const keyScenes = Array.isArray(act.keyScenes) ? act.keyScenes : (Array.isArray(act.scenes) ? act.scenes : [])
    return sum + Math.max(1, Math.min(keyScenes.length || 1, 3))
  }, 0)
  const totalCost = GENERATION_COSTS.DEFAULT + calculateBatchCost(GENERATION_COSTS.CONCEPT_ART, estimatedImageCount)
  const pointsCheck = await checkPoints(totalCost, params.id, 'generation.concept_art', 'IMAGE')
  if (!pointsCheck.ok) {
    return NextResponse.json({ error: 'POINTS_001', message: '点数不足，请联系管理员充值' }, { status: 403 })
  }

  const defaultAspectRatio = await getProjectDefaultAspectRatio(params.id)
  if (!(await claimStepForGeneration(step.id))) {
    return NextResponse.json(
      { success: true, status: 'PROCESSING', alreadyRunning: true, message: '该步骤的生成任务已在进行中，请等待当前任务完成' },
    )
  }

  try {
    const synopsis: string = framework?.synopsis || ''

    // 获取风格参考图 URL + 风格提示词
    // 工作指令.txt（Round 5 修复 #3）：统一调用 getStyleRefUrl 公共函数；
    // 之前按 Asset.metadata.styleId 反查的逻辑与 PATCH 写入的 step.outputData 脱节，是概念图 STORAGE_001 的根因
    let styleRefUrl: string
    let stylePrompt: string
    try {
      const ref = await getStyleRefUrl(params.id)
      styleRefUrl = ref.styleRefUrl
      stylePrompt = ref.stylePrompt
      console.log('[CONCEPT-READ] 读取到 styleRefUrl 前80字符:', styleRefUrl.slice(0, 80))
    } catch (refErr: any) {
      console.error('[CONCEPT-READ] 校验失败：', refErr?.message)
      return NextResponse.json(
        { error: 'STORAGE_001', message: refErr?.message || '未找到有效风格参考图 URL' },
        { status: 400 }
      )
    }

    const characterAssets = await prisma.asset.findMany({
      where: { projectId: params.id, step: { stepType: 'CHARACTER' } },
    })
    const characterRefs = characterAssets
      .map((a: any) => (a.metadata as any)?.characterId)
      .filter(Boolean) as string[]

    // 工作指令.txt（Round 6 任务一）：收集所有角色图 URL，用于概念图多图参考。
    // openlux.ts 内部会过滤非 http(s)（data: URL 不能传给豆包多图模型）。
    const characterImageUrls = characterAssets
      .map((a: any) => a.url)
      .filter((u: any) => typeof u === 'string' && u.length > 0) as string[]
    console.log(
      `[CONCEPT-READ] 角色图数量: ${characterImageUrls.length}, http(s) 数量: ${characterImageUrls.filter((u: any) => /^https?:\/\//i.test(u)).length}`
    )

    const refs = await getProjectReferences(params.id).catch(() => [])
    const userRefUrls = refs.filter(r => r.url).map(r => r.url)
    const refLabelsDefault = refs.filter((r: any) => r.labels?.length).flatMap((r: any) => r.labels)
    const refHintDefault = refs.length > 0
      ? `\n\n【用户上传的参考图】用户上传了 ${refs.length} 张参考图${refLabelsDefault.length > 0 ? `，标签：${refLabelsDefault.join('、')}` : ''}。生成 imagePrompt 时可引用参考图中的人物/场景，无需重新描述。`
      : ''

    const prompt = loadPromptTemplate('concept', {
      USER_INPUT: JSON.stringify({ framework, selectedStyle: stylePrompt }) + refHintDefault
    })
    const textClient = await getTextClient()
    const resultText = await textClient.generate(prompt, { temperature: 0.7, maxTokens: 4096 })
    const parsed = extractJsonFromMarkdown(resultText)
    const parsedScenes = parsed.scenes || []

    // 2. 用图像 API 生成概念图
    const imageClient = await getImageClient()
    const scenes = []
    const failedScenes: string[] = []
    const mockScenes: string[] = []

    for (const act of acts) {
      const actNo = act.actNo || act.actNumber || 1
      const keyScenes = Array.isArray(act.keyScenes) ? act.keyScenes : (Array.isArray(act.scenes) ? act.scenes : [])
      // 每幕概念图数量：基于 keyScenes 数量，至少1张，最多3张
      const sceneCount = Math.max(1, Math.min(keyScenes.length || 1, 3))

      for (let i = 0; i < sceneCount; i++) {
        try {
          const sceneDesc = keyScenes[i] || `幕${actNo}场景${i + 1}`
          // 优先使用 LLM 生成的 imagePrompt
          const llmScene = parsedScenes.find(
            (s: any) => s.actNumber === actNo && s.sceneNumber === i + 1
          )
          const rawPrompt = llmScene?.imagePrompt || ''
          const isValidEnglish = rawPrompt.trim().length > 5 && /[a-zA-Z]{3,}/.test(rawPrompt)
          const finalPrompt = isValidEnglish
            ? rawPrompt.trim()
            : `Cinematic scene, ${sceneDesc}. Film still, 35mm Kodak Portra 400, atmospheric depth, 8k, poetic realism.`

          // 工作指令.txt（Round 6 任务一）：多图参考 — 风格图 + 全部角色图
          const result = await imageClient.generateConceptScene(
            params.id,
            finalPrompt,
            styleRefUrl,
            stylePrompt,
            characterImageUrls,
            undefined,
            defaultAspectRatio,
            undefined,
            undefined,
            userRefUrls
          )
          const asset = await prisma.asset.create({
            data: {
              projectId: params.id,
              createdById: userId,
              stepId: step.id,
              type: 'IMAGE',
              mimeType: 'image/png',
              storageKey: result.storageKey,
              url: result.url,
              metadata: {
                ...result.metadata,
                actNumber: actNo,
                sceneIndex: i,
                llmPrompt: llmScene?.imagePrompt,
                prompt: finalPrompt,
                size: '1024x576',
                aspectRatio: defaultAspectRatio,
                imageModel: IMAGE_MODELS.primary,
              },
            },
          })
          scenes.push({
            actNumber: actNo,
            sceneIndex: i,
            assetId: asset.id,
            url: result.url,
            prompt: finalPrompt,
            size: '1024x576',
            isMock: !!result.metadata?.isMock,
            mockReason: result.metadata?.mockReason || null,
          })
          if (result.metadata?.isMock) {
            mockScenes.push(`幕${actNo}-场景${i + 1}`)
          }
        } catch (imgErr: any) {
          const sceneLabel = `幕${actNo}-场景${i + 1}`
          console.error(`[CONCEPT] ${sceneLabel} 生图失败:`, imgErr?.message)
          failedScenes.push(sceneLabel)
        }
      }
    }

    if (scenes.length === 0) {
      const errMsg = `所有概念图生图均失败${failedScenes.length > 0 ? '（' + failedScenes.join(', ') + '）' : ''}`
      await failStep(step.id, errMsg)
      await deductPointsAndLog(userId, pointsCheck.cost, 'error', { projectId: params.id, workflowStepId: step.id, success: false, errorMessage: errMsg })
      return NextResponse.json({ error: 'API_001', message: errMsg }, { status: 500 })
    }

    await completeStep(step.id, { scenes, totalScenes: scenes.length, aspectRatio: defaultAspectRatio })
    await deductPointsAndLog(userId, pointsCheck.cost, 'generate', { projectId: params.id, workflowStepId: step.id, success: true })
    // 失败与 Mock 占位都不算有效产出，按条退款
    const unbilledCount = failedScenes.length + mockScenes.length
    if (unbilledCount > 0) {
      await refundPointsAndLog(userId, calculateBatchCost(GENERATION_COSTS.CONCEPT_ART, unbilledCount), {
        projectId: params.id,
        workflowStepId: step.id,
        billingSource: pointsCheck.billingSource,
        billingGroupId: pointsCheck.billingGroupId,
        finalStatus: 'PARTIAL',
        errorMessage: `${unbilledCount}/${scenes.length + unbilledCount} 张概念图未使用 AI 模型生成（${failedScenes.length} 张失败、${mockScenes.length} 张回退为占位图），对应点数已退回`,
      })
    }
    return NextResponse.json({ success: true, data: { scenes, totalScenes: scenes.length } })
  } catch (e: any) {
    await failStep(step.id, e.message)
    await deductPointsAndLog(userId, pointsCheck.cost, 'error', { projectId: params.id, workflowStepId: step.id, success: false, errorMessage: e.message })
    return NextResponse.json({ error: 'API_001', message: e.message }, { status: 500 })
  }
}

// 工作指令.txt（2026-05-24）：文本编辑 PATCH，保存用户编辑后的 prompts
export async function PATCH(req: Request, props: { params: Promise<{ id: string }> }) {
  const params = await props.params;
  const userId = await getCurrentUserId()
  if (!userId) {
    return NextResponse.json({ error: 'AUTH_001' }, { status: 401 })
  }

  const project = await prisma.project.findUnique({ where: { id: params.id } })
  if (!project) {
    return NextResponse.json({ error: 'AUTH_002' }, { status: 404 })
  }
  const permission = await checkProjectPermission(project.id)
  if (!permission.allowed) {
    return permission.response
  }

  const body = await req.json().catch(() => ({}))
  const { prompts } = body

  if (!Array.isArray(prompts)) {
    return NextResponse.json({ error: 'VALIDATION_001', message: 'prompts 必须是数组' }, { status: 400 })
  }

  const step = await prisma.workflowStep.findUnique({
    where: { projectId_stepType: { projectId: params.id, stepType: 'CONCEPT' } }
  })
  if (!step) {
    return NextResponse.json({ error: 'WORKFLOW_004' }, { status: 400 })
  }

  const existingOutput = (step.outputData as any) || {}
  const nextOutput = { ...existingOutput, prompts }

  await prisma.workflowStep.update({
    where: { id: step.id },
    data: { outputData: nextOutput }
  })

  console.log('[TEXT-EDIT-CONCEPT] 保存 prompts 成功, 数量:', prompts.length)
  return NextResponse.json({ success: true })
}
