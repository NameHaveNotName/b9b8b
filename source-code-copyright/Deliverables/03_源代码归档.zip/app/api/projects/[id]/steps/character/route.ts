export const dynamic = 'force-dynamic'
export const maxDuration = 300

import { NextResponse } from 'next/server'
import { waitUntil } from '@vercel/functions'
import { getCurrentUserId } from '@/lib/auth-helpers'
import { checkProjectPermission } from '@/lib/project-permission'
import { prisma } from '@/lib/prisma'
import { getTextClient, getImageClient } from '@/lib/api-clients'
import { IMAGE_MODELS } from '@/lib/models-config'
import { loadPromptTemplate, extractJsonFromMarkdown } from '@/lib/prompts'
import { claimStepForGeneration, completeStep, failStep, canExecuteStep } from '@/lib/workflow-executor'
import { getProjectDefaultAspectRatio } from '@/lib/server/workflow-state'
import { getStyleRefUrl, getProjectReferences } from '@/lib/style-ref'
import { checkPoints, deductPointsAndLog, refundPointsAndLog } from '@/lib/points'
import { GENERATION_COSTS, calculateBatchCost } from '@/lib/points-config'

/**
 * 生成角色提示词（供 generate-prompts 和 generate-images 共用）
 * 成功返回 { prompts, characterCount }，失败抛出异常（调用方需 catch 并 failStep）
 */
async function generateCharacterPrompts(
  project: any,
  frameworkStep: any,
  stepId: string
): Promise<{ prompts: any[]; characterCount: number }> {
  const framework = (project.framework || frameworkStep.outputData) as any
  const allCharacters: Array<{ id: string; name: string; role: string; description: string }> =
    framework?.characters || []
  const characters = allCharacters.slice(0, 5)

  const refs = await getProjectReferences(project.id).catch(() => [])
  const refLabels = refs.filter((r: any) => r.labels?.length).flatMap((r: any) => r.labels)
  const refInstructions = refs.length > 0
    ? `【用户上传了 ${refs.length} 张人物参考图${refLabels.length > 0 ? `，标签：${refLabels.join('、')}` : ''}】\n` +
      `1. 你必须仔细分析参考图中每个人物的：整体造型、头部装饰/发型、面部特征、服装颜色与款式、标志性配件、身材比例、材质质感。\n` +
      `2. 为每个角色生成 imagePrompt 时，必须用文字准确复现参考图中的核心视觉特征（例如：蓝色球形身体、白色面部、头顶三叉皇冠、红色领结；或黑色齐耳短发、蓝色针织开衫、白色百褶裙）。\n` +
      `3. 禁止在 imagePrompt 中写"参考图1""参考图2""类似参考图"等占位描述；必须用具体、可视觉化的英文形容词和名词。\n` +
      `4. 如果某个角色明显对应某张带标签的参考图（如角色名"海宝"对应标签"海宝"），必须优先保证该角色的颜色、体型、服装、头饰/发型与参考图一致，不能擅自改动。\n` +
      `5. 风格上需要在参考图形象的基础上，融合 framework.styleGuide/visualStyle 的全局视觉风格关键词，但不能为了风格化而丢失角色的核心识别特征。`
    : '【无人物参考图】请根据 framework.characters 中的 description 生成 imagePrompt，确保描述具体可视觉化。'

  const prompt = loadPromptTemplate('character', {
    USER_INPUT: JSON.stringify(framework),
    REFERENCE_INSTRUCTIONS: refInstructions,
  })
  const textClient = await getTextClient()
  const resultText = await textClient.generate(prompt, { temperature: 0.7, maxTokens: 4096 })
  const parsed = extractJsonFromMarkdown(resultText)
  const parsedChars = parsed.characters || []

  const prompts = characters.map((character, i) => {
    const charData = parsedChars.find((c: any) => c.characterId === character.id || c.name === character.name)
    const charDesc = charData?.description || character.description || `${character.name}（${character.role}）`
    // 过滤空白，确保 englishPrompt 是有效的英文内容
    const rawPrompt = charData?.imagePrompt || ''
    const isValidEnglishPrompt = rawPrompt.trim().length > 10 && /[a-zA-Z]{3,}/.test(rawPrompt)
    // 如果 LLM 返回了有效的英文提示词则使用；否则用 charDesc 构建完整英文描述
    const englishPrompt = isValidEnglishPrompt
      ? rawPrompt.trim()
      : `Cinematic character portrait of ${character.name}, ${charDesc}. Solo portrait, front-facing, complete full face clearly visible. Cinematic film still, 35mm Kodak Portra 400, atmospheric depth, 8k, poetic realism.`
    return {
      id: `prompt_${i + 1}`,
      chineseDesc: charDesc,
      englishPrompt,
      target: `character_${character.id}`,
      characterName: character.name,
      characterId: character.id,
      role: character.role,
    }
  })

  const step = await prisma.workflowStep.findUnique({ where: { id: stepId } })
  await prisma.workflowStep.update({
    where: { id: stepId },
    data: {
      status: 'PENDING' as any,
      outputData: {
        ...(step?.outputData as any || {}),
        prompts,
        characterCount: characters.length,
      },
    },
  })

  console.log(`[CHARACTER-PROMPT] 生成 ${prompts.length} 条提示词`)
  return { prompts, characterCount: characters.length }
}

export async function POST(_req: Request, props: { params: Promise<{ id: string }> }) {
  const params = await props.params;
  const userId = await getCurrentUserId()
  if (!userId) {
    return NextResponse.json({ error: 'AUTH_001' }, { status: 401 })
  }

  const project = await prisma.project.findUnique({ where: { id: params.id } })
  if (!project) {
    return NextResponse.json({ error: 'AUTH_002' }, { status: 404 })
  }
  const access = await checkProjectPermission(params.id)
  if (!access.allowed) {
    return access.response
  }

  if (!(await canExecuteStep(params.id, 'CHARACTER'))) {
    return NextResponse.json({ error: 'WORKFLOW_002' }, { status: 400 })
  }

  const frameworkStep = await prisma.workflowStep.findUnique({
    where: { projectId_stepType: { projectId: params.id, stepType: 'FRAMEWORK' } }
  })
  if (!frameworkStep || frameworkStep.status !== 'COMPLETED') {
    return NextResponse.json({ error: 'WORKFLOW_003' }, { status: 400 })
  }

  const step = await prisma.workflowStep.findUnique({
    where: { projectId_stepType: { projectId: params.id, stepType: 'CHARACTER' } }
  })
  if (!step) {
    return NextResponse.json({ error: 'WORKFLOW_004' }, { status: 400 })
  }

  const body = await _req.json().catch(() => ({}))
  const force = body?.force === true
  const action: 'generate-prompts' | 'generate-images' = body?.action || 'generate-images'

  // === generate-prompts: 只生成提示词，不生图 ===
  if (action === 'generate-prompts') {
    const promptPointsCheck = await checkPoints(GENERATION_COSTS.DEFAULT, params.id, 'generation.character_prompts', 'TEXT')
    if (!promptPointsCheck.ok) {
      return NextResponse.json({ error: 'POINTS_001', message: '点数不足，请联系管理员充值' }, { status: 403 })
    }

    try {
      console.log('[CHARACTER-PROMPT] 收到 generate-prompts 请求')
      const { prompts } = await generateCharacterPrompts(project, frameworkStep, step.id)
      await deductPointsAndLog(userId, promptPointsCheck.cost, 'generate', { projectId: params.id, workflowStepId: step.id, success: true })
      return NextResponse.json({ success: true, status: 'PROMPT_READY', prompts })
    } catch (e: any) {
      const isAbort = e?.name === 'AbortError' || /aborted|timeout|timed out/i.test(e?.message || '')
      const errorMessage = isAbort
        ? '提示词生成超时（模型响应较慢），请稍后重试'
        : e.message
      console.error(`[CHARACTER-PROMPT] 失败: ${errorMessage}`, e?.stack?.slice(0, 300))
      await failStep(step.id, errorMessage)
      await deductPointsAndLog(userId, promptPointsCheck.cost, 'error', { projectId: params.id, workflowStepId: step.id, success: false, errorMessage })
      return NextResponse.json({ error: 'API_001', message: errorMessage }, { status: 500 })
    }
  }

  // === generate-images: 读取已保存提示词，执行生图 ===
  if (action === 'generate-images') {
    const defaultAspectRatio = await getProjectDefaultAspectRatio(params.id)
    const aspectRatio = body?.aspectRatio || defaultAspectRatio
    const imageModel = body?.imageModel
    console.log(`[ASPECT-RATIO] [CHARACTER-IMAGE] 用户选择比例: ${aspectRatio}`)
    console.log(`[MODEL-SELECT] [CHARACTER-IMAGE] 用户选择模型: ${imageModel || '默认'}`)

    const existingOutput = (step.outputData as any) || {}
    const prompts = existingOutput.prompts || []
    console.log('[CHARACTER-IMAGE] existingOutput keys:', Object.keys(existingOutput))
    console.log('[CHARACTER-IMAGE] prompts count:', prompts.length)

    // 工作指令.txt（2026-06-07）：prompts 为空时自动触发提示词生成，不返回 400
    let resolvedPrompts = prompts
    if (resolvedPrompts.length === 0) {
      console.warn('[CHARACTER-IMAGE] No prompts found, auto-triggering prompt generation')
      const promptPointsCheck = await checkPoints(GENERATION_COSTS.DEFAULT, params.id, 'generation.character_prompts', 'TEXT')
      if (!promptPointsCheck.ok) {
        return NextResponse.json({ error: 'POINTS_001', message: '点数不足，请联系管理员充值' }, { status: 403 })
      }
      try {
        const generated = await generateCharacterPrompts(project, frameworkStep, step.id)
        resolvedPrompts = generated.prompts
        console.log(`[CHARACTER-IMAGE] Auto-generated ${resolvedPrompts.length} prompts, continuing to image generation`)
        await deductPointsAndLog(userId, promptPointsCheck.cost, 'generate', { projectId: params.id, workflowStepId: step.id, success: true })
      } catch (promptErr: any) {
        const isAbort = promptErr?.name === 'AbortError' || /aborted|timeout|timed out/i.test(promptErr?.message || '')
        const errorMessage = isAbort
          ? '提示词生成超时（模型响应较慢），请稍后重试'
          : promptErr.message
        console.error(`[CHARACTER-IMAGE] Auto-prompt generation failed: ${errorMessage}`, promptErr?.stack?.slice(0, 300))
        await failStep(step.id, errorMessage)
        await deductPointsAndLog(userId, promptPointsCheck.cost, 'error', { projectId: params.id, workflowStepId: step.id, success: false, errorMessage })
        return NextResponse.json({ error: 'API_001', message: errorMessage }, { status: 500 })
      }
    }

    const imageCost = calculateBatchCost(GENERATION_COSTS.CHARACTER_DESIGN, resolvedPrompts.length)
    const pointsCheck = await checkPoints(imageCost, params.id, 'generation.character_design', 'IMAGE')
    if (!pointsCheck.ok) {
      return NextResponse.json({ error: 'POINTS_001', message: '点数不足，请联系管理员充值' }, { status: 403 })
    }

    // force=true 时清空旧资产（必须重新读取最新 outputData，避免覆盖自动生成的 prompts）
    if (force) {
      console.log('[CHARACTER-IMAGE] force=true, clearing old assets')
      await prisma.asset.deleteMany({
        where: { projectId: params.id, step: { stepType: 'CHARACTER' } }
      })
      const latestStep = await prisma.workflowStep.findUnique({ where: { id: step.id } })
      const latestOutput = (latestStep?.outputData as any) || existingOutput
      await prisma.workflowStep.update({
        where: { id: step.id },
        data: { status: 'PENDING' as any, outputData: latestOutput, errorMessage: null },
      })
    }

    // 异步任务先原子预扣一次；后台全部失败时退回同一付款账户。
    await deductPointsAndLog(userId, pointsCheck.cost, 'generate', {
      projectId: params.id,
      workflowStepId: step.id,
      success: true,
    })
    if (!(await claimStepForGeneration(step.id))) {
      return NextResponse.json(
        { success: true, status: 'PROCESSING', alreadyRunning: true, message: '该步骤的生成任务已在进行中，请等待当前任务完成' },
      )
    }

    // 异步后台生成：HTTP 立即返回，避免前端因生图耗时而超时
    waitUntil(
      (async () => {
        try {
          await generateCharacterImagesBackground(
            params.id,
            step.id,
            resolvedPrompts,
            aspectRatio,
            imageModel,
            pointsCheck.cost,
            userId,
            pointsCheck.billingSource,
            pointsCheck.billingGroupId,
          )
        } catch (e: any) {
          console.error('[CHARACTER-IMAGE] 后台生成异常:', e?.message)
        }
      })()
    )

    return NextResponse.json({
      success: true,
      status: 'PROCESSING',
      message: '角色设计生成任务已在后台启动，请稍后刷新查看',
    })
  }

  // === 默认兼容：无 action 时走原有完整流程 ===
  if (!force && step.status === 'COMPLETED' && step.outputData) {
    console.log('[CHARACTER] step already completed, returning cached result')
    return NextResponse.json({ success: true, data: step.outputData, cached: true })
  }

  if (force) {
    console.log('[CHARACTER] force=true, clearing old assets')
    await prisma.asset.deleteMany({
      where: { projectId: params.id, step: { stepType: 'CHARACTER' } }
    })
    const existingOutput = (step.outputData as any) || {}
    const preservedOutput = {
      prompts: existingOutput.prompts,
      characterCount: existingOutput.characterCount,
    }
    console.log('[CHARACTER] force=true, preserved prompts count:', existingOutput.prompts?.length || 0)
    await prisma.workflowStep.update({
      where: { id: step.id },
      data: { status: 'PENDING' as any, outputData: preservedOutput, errorMessage: null },
    })
  }

  const frameworkForBilling = (project.framework || frameworkStep.outputData) as any
  const characterCountForBilling = Math.min(5, Array.isArray(frameworkForBilling?.characters) ? frameworkForBilling.characters.length : 0)
  const totalCost = GENERATION_COSTS.DEFAULT + calculateBatchCost(GENERATION_COSTS.CHARACTER_DESIGN, characterCountForBilling)
  const pointsCheck = await checkPoints(totalCost, params.id, 'generation.character_design', 'IMAGE')
  if (!pointsCheck.ok) {
    return NextResponse.json({ error: 'POINTS_001', message: '点数不足，请联系管理员充值' }, { status: 403 })
  }

  const defaultAspectRatio = await getProjectDefaultAspectRatio(params.id)
  // 默认兼容流程同样只预扣一次，避免请求返回和后台完成各扣一次。
  await deductPointsAndLog(userId, pointsCheck.cost, 'generate', {
    projectId: params.id,
    workflowStepId: step.id,
    success: true,
  })
  if (!(await claimStepForGeneration(step.id))) {
    return NextResponse.json(
      { success: true, status: 'PROCESSING', alreadyRunning: true, message: '该步骤的生成任务已在进行中，请等待当前任务完成' },
    )
  }

  // 异步后台生成：先生成 prompts，再串行生图
  waitUntil(
    (async () => {
      try {
        const framework = (project.framework || frameworkStep.outputData) as any
        const allCharacters: Array<{ id: string; name: string; role: string; description: string }> =
          framework?.characters || []
        const characters = allCharacters.slice(0, 5)

        const prompt = loadPromptTemplate('character', {
          USER_INPUT: JSON.stringify(framework),
          REFERENCE_INSTRUCTIONS: '',
        })
        const textClient = await getTextClient()
        const resultText = await textClient.generate(prompt, { temperature: 0.7, maxTokens: 4096 })
        const parsed = extractJsonFromMarkdown(resultText)
        const parsedChars = parsed.characters || []

        const prompts = characters.map((character, i) => {
          const charData = parsedChars.find((c: any) => c.characterId === character.id || c.name === character.name)
          const charDesc = charData?.description || character.description || `${character.name}（${character.role}）`
          const rawPrompt = charData?.imagePrompt || ''
          const isValidEnglishPrompt = rawPrompt.trim().length > 10 && /[a-zA-Z]{3,}/.test(rawPrompt)
          const englishPrompt = isValidEnglishPrompt
            ? rawPrompt.trim()
            : `Cinematic character portrait of ${character.name}, ${charDesc}. Solo portrait, front-facing, complete full face clearly visible. Cinematic film still, 35mm Kodak Portra 400, atmospheric depth, 8k, poetic realism.`
          return {
            id: `prompt_${i + 1}`,
            chineseDesc: charDesc,
            englishPrompt,
            target: `character_${character.id}`,
            characterName: character.name,
            characterId: character.id,
            role: character.role,
          }
        })

        await prisma.workflowStep.update({
          where: { id: step.id },
          data: {
            outputData: {
              ...(step.outputData as any || {}),
              prompts,
              characterCount: characters.length,
            },
          },
        })

        await generateCharacterImagesBackground(
          params.id,
          step.id,
          prompts,
          defaultAspectRatio,
          undefined,
          pointsCheck.cost,
          userId,
          pointsCheck.billingSource,
          pointsCheck.billingGroupId,
        )
      } catch (e: any) {
        console.error('[CHARACTER] 后台生成异常:', e?.message)
        await failStep(step.id, e.message)
        await refundPointsAndLog(userId, pointsCheck.cost, {
          projectId: params.id,
          workflowStepId: step.id,
          billingSource: pointsCheck.billingSource,
          billingGroupId: pointsCheck.billingGroupId,
          errorMessage: e.message,
        })
      }
    })()
  )

  return NextResponse.json({
    success: true,
    status: 'PROCESSING',
    message: '角色设计生成任务已在后台启动，请稍后刷新查看',
  })
}

/**
 * 后台实际执行角色生图。
 * 被 waitUntil 调用，HTTP 响应已经返回给前端。
 */
async function generateCharacterImagesBackground(
  projectId: string,
  stepId: string,
  resolvedPrompts: any[],
  aspectRatio: string,
  imageModel: string | undefined,
  cost: number,
  userId: string,
  billingSource: 'USER' | 'GROUP',
  billingGroupId: string | null,
) {
  try {
    const styleStep = await prisma.workflowStep.findFirst({
      where: { projectId, stepType: 'STYLE', status: 'COMPLETED' },
    })

    let styleRefUrl: string | undefined
    let stylePrompt: string | undefined
    if (styleStep) {
      try {
        const ref = await getStyleRefUrl(projectId)
        styleRefUrl = ref.styleRefUrl
        stylePrompt = ref.stylePrompt
        console.log(`[CHARACTER-BG] 注入风格图: ${styleRefUrl}`)
      } catch (refErr: any) {
        console.log(`[CHARACTER-BG] 风格图提取失败，回退到无风格模式`)
      }
    }

    const refs = await getProjectReferences(projectId).catch(() => [])
    const userRefUrls = refs.filter((r: any) => r.url).map((r: any) => r.url)

    const imageClient = await getImageClient()
    const portraits: any[] = []
    const failedCharacters: string[] = []
    const mockCharacters: string[] = []

    for (const promptItem of resolvedPrompts) {
      try {
        const enrichedCharacter = {
          id: promptItem.characterId,
          name: promptItem.characterName,
          role: promptItem.role || '',
          description: promptItem.englishPrompt || promptItem.chineseDesc,
        }

        const result = await imageClient.generateCharacterPortrait(
          projectId,
          enrichedCharacter,
          styleRefUrl,
          stylePrompt,
          aspectRatio,
          imageModel,
          userRefUrls
        )
        if (!result?.url || !result?.storageKey) {
          console.error(`[CHARACTER-BG] 角色 ${promptItem.characterName} 返回结果缺少 url/storageKey:`, JSON.stringify(result))
          failedCharacters.push(promptItem.characterName)
          continue
        }
        const asset = await prisma.asset.create({
          data: {
            projectId,
            createdById: userId,
            stepId,
            type: 'IMAGE',
            mimeType: 'image/png',
            storageKey: result.storageKey,
            url: result.url,
            metadata: {
              characterId: promptItem.characterId,
              characterName: promptItem.characterName,
              chineseDesc: promptItem.chineseDesc,
              styleRefUrl: styleRefUrl || null,
              llmPrompt: promptItem.englishPrompt,
              aspectRatio,
              imageModel: imageModel || IMAGE_MODELS.primary,
              quality: 'medium',
              isMock: !!result.isMock,
              ...(result.lastError ? { mockReason: result.lastError } : {}),
            },
          },
        })
        console.log(`[CHARACTER-BG] Asset 创建成功: assetId=${asset.id}, char=${promptItem.characterName}`)
        portraits.push({ character: enrichedCharacter, assetId: asset.id, url: result.url, llmPrompt: promptItem.englishPrompt })
        // 真实模型全失败时供应商回退到占位图，产出不可用，按未计费处理
        if (result.isMock) {
          mockCharacters.push(promptItem.characterName)
          console.warn(`[CHARACTER-BG] 角色 ${promptItem.characterName} 返回 Mock 占位图: ${result.lastError || '未知原因'}`)
        }
      } catch (imgErr: any) {
        console.error(`[CHARACTER-BG] 角色 ${promptItem.characterName} 生图失败:`, imgErr?.message)
        failedCharacters.push(promptItem.characterName)
      }
    }

    if (portraits.length === 0) {
      const errMsg = `所有角色生图均失败${failedCharacters.length > 0 ? '（' + failedCharacters.join(', ') + '）' : ''}`
      await failStep(stepId, errMsg)
      await refundPointsAndLog(userId, cost, {
        projectId,
        workflowStepId: stepId,
        billingSource,
        billingGroupId,
        errorMessage: errMsg,
      })
      return
    }

    await completeStep(stepId, { portraits, characterCount: portraits.length, imageModel: imageModel || IMAGE_MODELS.primary, aspectRatio })
    // 失败与 Mock 占位都不算有效产出，统一按条数退款
    const unbilledCount = failedCharacters.length + mockCharacters.length
    if (unbilledCount > 0) {
      await refundPointsAndLog(userId, calculateBatchCost(GENERATION_COSTS.CHARACTER_DESIGN, unbilledCount), {
        projectId,
        workflowStepId: stepId,
        billingSource,
        billingGroupId,
        finalStatus: 'PARTIAL',
        errorMessage: mockCharacters.length > 0
          ? `${unbilledCount}/${resolvedPrompts.length} 个角色未使用 AI 模型生成（${failedCharacters.length} 个失败、${mockCharacters.length} 个回退为占位图），对应点数已退回`
          : `${unbilledCount}/${resolvedPrompts.length} 个角色图片生成失败，失败部分点数已退回`,
      })
    }
    const dbAssetCount = await prisma.asset.count({ where: { stepId } })
    console.log(`[CHARACTER-BG] 完成: 成功 ${portraits.length}/${resolvedPrompts.length} 条，数据库 Asset 数: ${dbAssetCount}`)
  } catch (e: any) {
    console.error('[CHARACTER-BG] 异常:', e?.message)
    await failStep(stepId, e.message)
    await refundPointsAndLog(userId, cost, {
      projectId,
      workflowStepId: stepId,
      billingSource,
      billingGroupId,
      errorMessage: e.message,
    })
  }
}

// 工作指令.txt（2026-05-24）：文本编辑 PATCH，保存用户编辑后的 prompts
export async function PATCH(req: Request, props: { params: Promise<{ id: string }> }) {
  const params = await props.params;
  const userId = await getCurrentUserId()
  if (!userId) {
    return NextResponse.json({ error: 'AUTH_001' }, { status: 401 })
  }

  const project = await prisma.project.findUnique({ where: { id: params.id } })
  if (!project) {
    return NextResponse.json({ error: 'AUTH_002' }, { status: 404 })
  }
  const access = await checkProjectPermission(params.id)
  if (!access.allowed) {
    return access.response
  }

  const body = await req.json().catch(() => ({}))
  const { prompts } = body

  if (!Array.isArray(prompts)) {
    return NextResponse.json({ error: 'VALIDATION_001', message: 'prompts 必须是数组' }, { status: 400 })
  }

  const step = await prisma.workflowStep.findUnique({
    where: { projectId_stepType: { projectId: params.id, stepType: 'CHARACTER' } }
  })
  if (!step) {
    return NextResponse.json({ error: 'WORKFLOW_004' }, { status: 400 })
  }

  const existingOutput = (step.outputData as any) || {}
  const nextOutput = { ...existingOutput, prompts }

  await prisma.workflowStep.update({
    where: { id: step.id },
    data: { outputData: nextOutput }
  })

  console.log('[TEXT-EDIT-CHARACTER] 保存 prompts 成功, 数量:', prompts.length)
  return NextResponse.json({ success: true })
}
