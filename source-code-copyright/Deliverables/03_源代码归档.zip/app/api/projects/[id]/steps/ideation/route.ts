export const dynamic = 'force-dynamic'

import { NextResponse } from 'next/server'
import { getCurrentUserId } from '@/lib/auth-helpers'
import { claimStepForGeneration } from '@/lib/workflow-executor'
import { checkProjectPermission } from '@/lib/project-permission'
import { prisma } from '@/lib/prisma'
import { getTextClient } from '@/lib/api-clients'
import { getProjectReferences } from '@/lib/style-ref'
import { PROJECT_TAG_PROMPTS } from '@/lib/project-tags'
import { loadPromptTemplate, extractJsonFromMarkdown } from '@/lib/prompts'
import { createStep, completeStep, failStep, canExecuteStep } from '@/lib/workflow-executor'
import { checkPoints, deductPointsAndLog } from '@/lib/points'
import { GENERATION_COSTS } from '@/lib/points-config'

export async function POST(_req: Request, props: { params: Promise<{ id: string }> }) {
  const params = await props.params;
  const userId = await getCurrentUserId()
  if (!userId) {
    return NextResponse.json({ error: 'AUTH_001' }, { status: 401 })
  }

  const project = await prisma.project.findUnique({ where: { id: params.id } })
  if (!project) {
    return NextResponse.json({ error: 'AUTH_002' }, { status: 404 })
  }
  const permission = await checkProjectPermission(project.id)
  if (!permission.allowed) {
    return permission.response
  }

  if (!(await canExecuteStep(params.id, 'IDEATION'))) {
    return NextResponse.json({ error: 'WORKFLOW_002' }, { status: 400 })
  }

  let step = await prisma.workflowStep.findUnique({
    where: { projectId_stepType: { projectId: params.id, stepType: 'IDEATION' } }
  })
  if (!step) {
    step = await createStep(params.id, 'IDEATION', 0)
  }

  // 工作指令.txt（2026-06-02）：如果请求体传了 creativeInput，先保存到 project.rawIdea
  const body = await _req.json().catch(() => ({}))
  const creativeInput = body?.creativeInput

  // 强制重新生成：重置步骤状态并清除历史输出
  if (body?.force === true && step.status === 'COMPLETED') {
    console.log('[IDEATION] force regeneration requested, resetting step')
    await prisma.workflowStep.update({
      where: { id: step.id },
      data: { status: 'PENDING', outputData: {}, errorMessage: null },
    })
    step = await prisma.workflowStep.findUnique({ where: { id: step.id } })
    if (!step) {
      return NextResponse.json({ error: 'WORKFLOW_005', message: '步骤重置失败' }, { status: 500 })
    }
  }

  // 幂等保护：已完成则直接返回历史结果，避免重复消耗 API 配额并覆盖结果
  if (step!.status === 'COMPLETED' && step!.outputData) {
    console.log('[IDEATION] step already completed, returning cached result')
    return NextResponse.json({ success: true, data: step!.outputData, cached: true })
  }

  const pointsCheck = await checkPoints(GENERATION_COSTS.IDEA_DIFFUSION, params.id, 'generation.idea_diffusion', 'TEXT')
  if (!pointsCheck.ok) {
    return NextResponse.json({ error: 'POINTS_001', message: '点数不足，请联系管理员充值' }, { status: 403 })
  }

  if (creativeInput && typeof creativeInput === 'string' && creativeInput.trim().length > 0) {
    await prisma.project.update({
      where: { id: params.id },
      data: { rawIdea: creativeInput.trim() },
    })
    // 更新本地引用，后续生成使用新内容
    project.rawIdea = creativeInput.trim()
  }

  // 框架导入兼容：如果重新执行创意扩散，重置 framework_source 为 generated
  if (project.frameworkSource === 'imported' || project.frameworkSource === 'mixed') {
    await prisma.project.update({
      where: { id: params.id },
      data: { frameworkSource: 'generated' },
    })
  }

  if (!(await claimStepForGeneration(step.id))) {
    return NextResponse.json(
      { success: true, status: 'PROCESSING', alreadyRunning: true, message: '该步骤的生成任务已在进行中，请等待当前任务完成' },
    )
  }

  try {
    const textClient = await getTextClient()

    const references = await getProjectReferences(params.id).catch(() => [])
    const hasRefs = references.length > 0 && references.some(r => r.url)

    const projectTag = body.projectTag || ''
    const tagInstructions = projectTag && PROJECT_TAG_PROMPTS[projectTag as keyof typeof PROJECT_TAG_PROMPTS]
      ? PROJECT_TAG_PROMPTS[projectTag as keyof typeof PROJECT_TAG_PROMPTS].ideation
      : ''

    let resultText: string
    if (hasRefs) {
      const refUrls = references.filter(r => r.url).map(r => r.url)
      const refLabels = references.filter(r => r.labels?.length).flatMap(r => r.labels)
      console.log(`[IDEATION-VISION] Using multimodal with ${refUrls.length} reference images, labels:`, refLabels, 'tag:', projectTag || 'none')

      const visualRefBlock = refLabels.length > 0
        ? `【用户上传了 ${refUrls.length} 张视觉参考图。用户标注的标签：${refLabels.join('、')}。\n` +
          `【角色外观要求】\n` +
          `你必须在 characters[].description 中描述角色的实际外貌特征，包括：颜色、体型、着装/纹样、标志性视觉元素。\n` +
          `请根据图片内容或标签名称推断角色外观（例如标签含"宝"可推断为圆润可爱型，含"贝"可推断为贝壳/海洋元素），禁止只用"风格定位：..."替代外观描述。\n` +
          `对场景/风格元素，必须在 styleGuide 中体现参考图的视觉特征。`
        : `【用户上传了 ${refUrls.length} 张视觉参考图。\n` +
          `【角色外观要求】\n` +
          `你必须在 characters[].description 中描述角色的实际外貌特征（颜色、体型、标志性元素），禁止只用角色定位/性格来填充。\n` +
          `styleGuide 必须体现参考图中的视觉风格特征。`

      const prompt = loadPromptTemplate('ideation', {
        USER_INPUT: project.rawIdea,
        VISUAL_REFERENCES: visualRefBlock,
        PROJECT_TAG_INSTRUCTIONS: tagInstructions,
      })
      resultText = await textClient.generateVision({
        prompt,
        imageUrls: refUrls,
        imageLabels: refLabels,
        temperature: 0.8,
        maxTokens: 12000,
      })
    } else {
      const prompt = loadPromptTemplate('ideation', {
        USER_INPUT: project.rawIdea,
        VISUAL_REFERENCES: '',
        PROJECT_TAG_INSTRUCTIONS: tagInstructions,
      })
      resultText = await textClient.generate(prompt, { temperature: 0.8, maxTokens: 12000 })
    }

    // 调试日志
    console.log('[IDEATION] resultText length:', resultText.length)
    console.log('[IDEATION] resultText preview:', resultText.slice(0, 200))

    const parsed = extractJsonFromMarkdown(resultText)
    const directions = parsed.directions || []
    const framework = parsed.framework || {}
    const storyLength = parsed.storyLength || 'short'
    const storyLengthLabel = parsed.storyLengthLabel || '短篇 · 3-5分钟'
    const storyLengthDesc = parsed.storyLengthDesc || ''

    console.log('[IDEATION] parsed directions:', JSON.stringify(directions).slice(0, 500))
    console.log('[IDEATION-DEBUG] 解析出的方向数量:', Array.isArray(directions) ? directions.length : '非数组')
    console.log('[IDEATION-DEBUG] 第一个方向:', directions?.[0])
    console.log('[IDEATION-DEBUG] 推荐分档:', storyLength, storyLengthLabel)

    // 防止 LLM 不遵守 prompt 只输出 1 个方向(2026-05-04 用户报告问题)
    if (!Array.isArray(directions) || directions.length < 3) {
      throw new Error(
        `IDEATION_INSUFFICIENT_DIRECTIONS: LLM 返回方向数量不足。期望>=3,实际=${
          Array.isArray(directions) ? directions.length : '非数组'
        }。请重试或检查 prompts/ideation.txt。`
      )
    }

    const result = { directions, framework, storyLength, storyLengthLabel, storyLengthDesc, projectTag: projectTag || undefined, rawText: resultText.slice(0, 3000) }
    await completeStep(step.id, result)
    await deductPointsAndLog(userId, pointsCheck.cost, 'generate', { projectId: params.id, workflowStepId: step.id, success: true })

    // 文本类步骤也应保存 outputData 到 Asset，确保资产库能展示
    const existingAsset = await prisma.asset.findFirst({
      where: { projectId: params.id, stepId: step.id, type: 'TEXT' }
    })
    if (existingAsset) {
      await prisma.asset.update({
        where: { id: existingAsset.id },
        data: {
          metadata: { content: resultText, directions, framework, storyLength, storyLengthLabel, storyLengthDesc, stepType: 'IDEATION' },
        },
      })
    } else {
      await prisma.asset.create({
        data: {
          projectId: params.id,
          createdById: userId,
          stepId: step.id,
          type: 'TEXT',
          mimeType: 'application/json',
          storageKey: `projects/${params.id}/texts/ideation-data.json`,
          url: '',
          metadata: { content: resultText, directions, framework, storyLength, storyLengthLabel, storyLengthDesc, stepType: 'IDEATION' },
        },
      })
    }

    return NextResponse.json({ success: true, data: result })
  } catch (e: any) {
    console.error('[IDEATION] Error:', e.message)
    await failStep(step.id, e.message)
    await deductPointsAndLog(userId, pointsCheck.cost, 'error', { projectId: params.id, workflowStepId: step.id, success: false, errorMessage: e.message })
    return NextResponse.json({ error: 'API_001', message: e.message }, { status: 500 })
  }
}

// 工作指令.txt（2026-05-24）：文本编辑 PATCH，保存用户编辑后的 directions
export async function PATCH(req: Request, props: { params: Promise<{ id: string }> }) {
  const params = await props.params;
  const userId = await getCurrentUserId()
  if (!userId) {
    return NextResponse.json({ error: 'AUTH_001' }, { status: 401 })
  }

  const project = await prisma.project.findUnique({ where: { id: params.id } })
  if (!project) {
    return NextResponse.json({ error: 'AUTH_002' }, { status: 404 })
  }
  const permission = await checkProjectPermission(project.id)
  if (!permission.allowed) {
    return permission.response
  }

  const body = await req.json().catch(() => ({}))
  const { directions, storyLength, storyLengthLabel, storyLengthDesc, projectTag } = body

  const step = await prisma.workflowStep.findUnique({
    where: { projectId_stepType: { projectId: params.id, stepType: 'IDEATION' } }
  })
  if (!step) {
    return NextResponse.json({ error: 'WORKFLOW_004' }, { status: 400 })
  }

  const existingOutput = (step.outputData as any) || {}
  const nextOutput: any = { ...existingOutput }

  if (Array.isArray(directions)) {
    nextOutput.directions = directions
  }
  if (storyLength !== undefined) {
    nextOutput.storyLength = storyLength
  }
  if (storyLengthLabel !== undefined) {
    nextOutput.storyLengthLabel = storyLengthLabel
  }
  if (storyLengthDesc !== undefined) {
    nextOutput.storyLengthDesc = storyLengthDesc
  }
  if (projectTag !== undefined) {
    nextOutput.projectTag = projectTag || ''
  }

  await prisma.workflowStep.update({
    where: { id: step.id },
    data: { outputData: nextOutput }
  })

  console.log('[TEXT-EDIT-IDEATION] 保存成功, directions:', directions?.length, 'storyLength:', nextOutput.storyLength)
  return NextResponse.json({ success: true })
}
