export const dynamic = 'force-dynamic'

import { NextResponse } from 'next/server'
import { getCurrentUserId } from '@/lib/auth-helpers'
import { checkProjectPermission } from '@/lib/project-permission'
import { prisma } from '@/lib/prisma'
import { getTextClient, getImageClient } from '@/lib/api-clients'
import { loadPromptTemplate } from '@/lib/prompts'
import { claimStepForGeneration, mergeStepOutputData, canExecuteStep } from '@/lib/workflow-executor'
import { getStyleRefUrl } from '@/lib/style-ref'
import { checkPoints, deductPointsAndLog, refundPointsAndLog } from '@/lib/points'
import { GENERATION_COSTS, calculateBatchCost } from '@/lib/points-config'

export async function POST(_req: Request, props: { params: Promise<{ id: string }> }) {
  const params = await props.params;
  const userId = await getCurrentUserId()
  if (!userId) {
    return NextResponse.json({ error: 'AUTH_001' }, { status: 401 })
  }

  const project = await prisma.project.findUnique({ where: { id: params.id } })
  if (!project) {
    return NextResponse.json({ error: 'AUTH_002' }, { status: 404 })
  }
  const permission = await checkProjectPermission(project.id)
  if (!permission.allowed) {
    return permission.response
  }

  if (!(await canExecuteStep(params.id, 'TRAILER'))) {
    return NextResponse.json({ error: 'WORKFLOW_002' }, { status: 400 })
  }

  const storyboardStep = await prisma.workflowStep.findUnique({
    where: { projectId_stepType: { projectId: params.id, stepType: 'STORYBOARD' } }
  })
  if (!storyboardStep || storyboardStep.status !== 'COMPLETED') {
    return NextResponse.json({ error: 'WORKFLOW_003' }, { status: 400 })
  }

  const step = await prisma.workflowStep.findUnique({
    where: { projectId_stepType: { projectId: params.id, stepType: 'TRAILER' } }
  })
  if (!step) {
    return NextResponse.json({ error: 'WORKFLOW_004' }, { status: 400 })
  }

  const shots = (storyboardStep.outputData as any)?.shots || []
  const batchCost = calculateBatchCost(GENERATION_COSTS.KEYFRAME, shots.length)
  const pointsCheck = await checkPoints(batchCost, params.id, 'generation.representative', 'IMAGE')
  if (!pointsCheck.ok) {
    return NextResponse.json({ error: 'POINTS_001', message: '点数不足，请联系管理员充值' }, { status: 403 })
  }

  // 代表帧存放在 TRAILER 步骤行上（资产需要一个 stepId 外键），但绝不能把
  // TRAILER 步骤本身标记为 COMPLETED：trailer 路由见到 COMPLETED 会直接返回缓存，
  // 用户就再也生成不了宣传片了。结果也要放在独立的 representativeFrames 键下，
  // 避免和 trailer 自己的 results/segments/videoUrl 撞车。
  const trailerStatusBefore = step.status as string
  if (!(await claimStepForGeneration(step.id))) {
    return NextResponse.json(
      { success: true, status: 'PROCESSING', alreadyRunning: true, message: '该步骤的生成任务已在进行中，请等待当前任务完成' },
    )
  }

  // 生成结束后把 TRAILER 步骤恢复成原来的状态
  const restoreTrailerStatus = async () => {
    await prisma.workflowStep
      .updateMany({
        where: { id: step.id, status: 'PROCESSING' },
        data: { status: trailerStatusBefore as any, errorMessage: null },
      })
      .catch((e: any) => console.error('[REPRESENTATIVE] 恢复 TRAILER 步骤状态失败:', e?.message))
  }


  try {
    const framework = project.framework as any
    const characters = framework?.characters || []
    const imageClient = await getImageClient()
    const textClient = await getTextClient()

    // 获取风格参考图 URL（与 CONCEPT/KEYFRAMES 一致）
    let styleRefUrl: string
    let selectedStylePrompt: string
    try {
      const ref = await getStyleRefUrl(params.id)
      styleRefUrl = ref.styleRefUrl
      selectedStylePrompt = ref.stylePrompt ||
        'cinematic film still, 35mm Kodak Portra 400, soft grain, atmospheric depth, 8K'
    } catch (refErr: any) {
      console.error('[REPRESENTATIVE] 风格图提取失败：', refErr?.message)
      return NextResponse.json(
        { error: 'STORAGE_001', message: refErr?.message || '未找到有效风格参考图 URL' },
        { status: 400 }
      )
    }

    // 收集角色参考图（用于多图参考）
    const characterAssets = await prisma.asset.findMany({
      where: { projectId: params.id, step: { stepType: 'CHARACTER' } },
    })
    const characterImageUrls = characterAssets
      .map((a: any) => a.url)
      .filter((u: any): u is string => typeof u === 'string' && u.length > 0)
    const characterDescs = characterAssets
      .map((a: any) => ({
        name: (a.metadata as any)?.characterName || '',
        description: (a.metadata as any)?.chineseDesc || '',
      }))
      .filter((c: any) => c.name)

    const results: any[] = []
    let mockCount = 0

    for (const shot of shots) {
      const charNames = shot.characters
        .map((cid: string) => characters.find((c: any) => c.id === cid)?.name || '未知角色')
        .join(',')

      // 用 concept 模板生成代表画面提示词
      const prompt = loadPromptTemplate('concept', {
        USER_INPUT: JSON.stringify({
          framework,
          selectedStyle: selectedStylePrompt,
          shotDescription: shot.description,
          keyAction: shot.keyAction,
          characters: charNames,
        })
      })
      const promptText = await textClient.generate(prompt, { temperature: 0.7, maxTokens: 2048 })

      const label = `${shot.shotId} 高潮瞬间 - ${charNames} ${shot.keyAction || '关键动作'}`
      const result = await imageClient.generateConceptScene(
        params.id,
        label,
        styleRefUrl,
        selectedStylePrompt,
        characterImageUrls.length > 0 ? characterImageUrls : undefined,
        undefined,
        undefined,
        'gpt-image-1',
        characterDescs.length > 0 ? characterDescs : undefined
      )

      const asset = await prisma.asset.create({
        data: {
          projectId: params.id,
          createdById: userId,
          type: 'IMAGE',
          mimeType: 'image/png',
          storageKey: `projects/${params.id}/representative/${shot.shotId}.png`,
          url: result.url,
          metadata: {
            shotId: shot.shotId,
            type: 'representative',
            sceneDesc: label,
            llmPrompt: promptText,
            isMock: !!result.metadata?.isMock,
          },
        }
      })
      if (result.metadata?.isMock) {
        mockCount += 1
        console.warn(`[REPRESENTATIVE] ${shot.shotId} 返回 Mock 占位图: ${result.metadata?.mockReason || '未知原因'}`)
      }
      results.push({ shotId: shot.shotId, assetId: asset.id, url: result.url, isMock: !!result.metadata?.isMock })
    }

    // 局部合并，不动 trailer 自己的 results/segments/videoUrl
    await mergeStepOutputData(step.id, (fresh) => ({
      ...fresh,
      representativeFrames: { results, count: results.length, generatedAt: new Date().toISOString() },
    }))
    await restoreTrailerStatus()

    const actualCost = calculateBatchCost(GENERATION_COSTS.KEYFRAME, results.length - mockCount)
    await deductPointsAndLog(userId, actualCost, 'generate', { projectId: params.id, success: true })
    // Mock 占位不是有效产出，不计费
    if (mockCount > 0) {
      await refundPointsAndLog(userId, calculateBatchCost(GENERATION_COSTS.KEYFRAME, mockCount), {
        projectId: params.id,
        billingSource: pointsCheck.billingSource,
        billingGroupId: pointsCheck.billingGroupId,
        finalStatus: mockCount < results.length ? 'PARTIAL' : 'FAILED',
        errorMessage: `${mockCount}/${results.length} 张代表帧未使用 AI 模型生成（回退为占位图），对应点数已退回`,
      })
    }
    return NextResponse.json({ success: true, data: { results, count: results.length } })
  } catch (e: any) {
    await restoreTrailerStatus()
    await deductPointsAndLog(userId, pointsCheck.cost, 'error', { projectId: params.id, success: false, errorMessage: e.message })
    return NextResponse.json({ error: 'API_001', message: e.message }, { status: 500 })
  }
}

export async function GET(_req: Request, props: { params: Promise<{ id: string }> }) {
  const params = await props.params;
  const access = await checkProjectPermission(params.id)
  if (!access.allowed) return access.response

  const step = await prisma.workflowStep.findUnique({
    where: { projectId_stepType: { projectId: params.id, stepType: 'TRAILER' } },
    include: { resultAssets: true }
  })
  if (!step) return NextResponse.json({ status: 'not_found' })
  return NextResponse.json({ status: step.status, outputData: step.outputData, assets: step.resultAssets })
}
