export const dynamic = 'force-dynamic'
// 尾帧生成 = 一次文本调用 + 一次生图 + 落库，生图上游超时是 180s，
// 不声明 maxDuration 会走平台默认值被提前切断
export const maxDuration = 300

import { NextResponse } from 'next/server'
import { getCurrentUserId } from '@/lib/auth-helpers'
import { checkProjectPermission } from '@/lib/project-permission'
import { prisma } from '@/lib/prisma'
import { getTextClient, getImageClient } from '@/lib/api-clients'
import { loadPromptTemplate, extractJsonFromMarkdown } from '@/lib/prompts'
import { getStyleRefUrl, getProjectReferences } from '@/lib/style-ref'
import { getProjectDefaultAspectRatio } from '@/lib/server/workflow-state'
import { checkPoints, deductPointsAndLog } from '@/lib/points'
import { mergeStepOutputData } from '@/lib/workflow-executor'
import { GENERATION_COSTS } from '@/lib/points-config'
import { refreshShotsUrls } from '@/lib/resolve-media-url'

/**
 * 单条尾帧生成 API
 * POST /api/projects/[id]/steps/keyframes/generate-last
 * Body: { shotId: string }
 *
 * 从 STORYBOARD 步骤读取对应 shot 的 firstFrameUrl/description，
 * 调用尾帧生成，然后将 lastFrameUrl 写回 STORYBOARD.outputData.shots
 */
export async function POST(_req: Request, props: { params: Promise<{ id: string }> }) {
  const params = await props.params;
  const userId = await getCurrentUserId()
  if (!userId) {
    return NextResponse.json({ error: 'AUTH_001' }, { status: 401 })
  }

  const project = await prisma.project.findUnique({ where: { id: params.id } })
  if (!project) {
    return NextResponse.json({ error: 'AUTH_002' }, { status: 404 })
  }
  const permission = await checkProjectPermission(project.id)
  if (!permission.allowed) {
    return permission.response
  }

  const body = await _req.json().catch(() => null)
  if (!body?.shotId) {
    return NextResponse.json({ error: '需要 shotId' }, { status: 400 })
  }
  const actNumber = typeof body.actNumber === 'number' ? body.actNumber : null

  // 从 STORYBOARD 步骤读取 shots
  // 判据是「分镜表里有没有可用首帧」，不是步骤 status === 'COMPLETED'：
  // xlsx 导入的项目步骤可能是 PENDING，但图片已经在了，不该把用户挡住。
  const storyboardStep = await prisma.workflowStep.findUnique({
    where: { projectId_stepType: { projectId: params.id, stepType: 'STORYBOARD' } }
  })
  if (!storyboardStep) {
    return NextResponse.json({ error: '请先完成分镜设计或导入分镜表' }, { status: 400 })
  }

  const rawStoryboardShots = (storyboardStep.outputData as any)?.shots || []
  const refreshed = await refreshShotsUrls(rawStoryboardShots)
  const storyboardShots = refreshed.shots
  // 使用 composite key (actNumber, shotId) 查找对应镜头
  const shot = storyboardShots.find((s: any) =>
    s.shotId === body.shotId && (actNumber == null || s.actNumber === actNumber)
  )
  if (!shot) {
    return NextResponse.json({ error: `未找到 shot: ${body.shotId} (act ${actNumber})` }, { status: 404 })
  }
  if (!shot.firstFrameUrl && !shot.referenceImageUrl) {
    return NextResponse.json(
      { error: '该镜头还没有可用首帧，请先生成或导入分镜图' },
      { status: 400 }
    )
  }

  // 获取 KEYFRAMES 步骤（用于创建 Asset 记录）
  let keyframesStep = await prisma.workflowStep.findUnique({
    where: { projectId_stepType: { projectId: params.id, stepType: 'KEYFRAMES' } }
  })
  if (!keyframesStep) {
    // 按工作流定义取 order，避免硬编码 8 与规范顺序不一致而产生错序/重复步骤行
    const { getStepOrder } = await import('@/lib/workflow')
    keyframesStep = await prisma.workflowStep.create({
      data: {
        projectId: params.id,
        stepType: 'KEYFRAMES',
        status: 'PENDING',
        order: getStepOrder('KEYFRAMES'),
        outputData: {},
      }
    })
  }

  console.log('[KEYFRAMES-GENERATE-LAST] shotId:', shot.shotId, 'description:', shot.description?.slice(0, 60))

  const pointsCheck = await checkPoints(GENERATION_COSTS.KEYFRAME, params.id, 'generation.keyframe', 'IMAGE')
  if (!pointsCheck.ok) {
    return NextResponse.json({ error: 'POINTS_001', message: '点数不足，请联系管理员充值' }, { status: 403 })
  }

  try {
    // 获取风格参考
    let styleRefUrl: string
    let stylePrompt: string
    try {
      const ref = await getStyleRefUrl(params.id)
      styleRefUrl = ref.styleRefUrl
      stylePrompt = ref.stylePrompt || 'cinematic film still, 35mm Kodak Portra 400, soft grain, atmospheric depth, 8K'
    } catch (refErr: any) {
      console.error('[KEYFRAMES-GENERATE-LAST] 风格参考获取失败:', refErr?.message)
      return NextResponse.json(
        { error: '未找到有效风格参考图' },
        { status: 400 }
      )
    }

    // 生成尾帧图像提示词
    const textClient = await getTextClient()
    const glRefs = await getProjectReferences(params.id).catch(() => [])
    const glRefLabels = glRefs.filter((r: any) => r.labels?.length).flatMap((r: any) => r.labels)
    const glRefHint = glRefs.length > 0
      ? `\n【参考图】${glRefs.length} 张用户参考图${glRefLabels.length > 0 ? `（标签：${glRefLabels.join('、')}）` : ''}。生成 imagePrompt 时可直接引用参考图中的人物。`
      : ''

    const promptTemplate = loadPromptTemplate('keyframe-last', {
      STYLE_REF: stylePrompt,
      USER_INPUT: (shot.description || `${shot.shotId} - ${shot.sceneName || ''}`) + glRefHint,
    })
    const generatedPrompt = await textClient.generate(promptTemplate, { temperature: 0.7, maxTokens: 1024 })
    const parsed = extractJsonFromMarkdown(generatedPrompt)
    const imagePrompt = parsed.keyframe?.imagePrompt || generatedPrompt

    console.log('[KEYFRAMES-GENERATE-LAST] 尾帧图像提示词生成完成')

    const refs = await getProjectReferences(params.id).catch(() => [])
    const userRefUrls = refs.filter(r => r.url).map(r => r.url)

    // 尾帧以当前镜头的首帧为参考，保持同一镜头内画面连贯
    const currentFirstFrameUrl: string | undefined = shot.firstFrameUrl || shot.referenceImageUrl || undefined
    const defaultAspectRatio = await getProjectDefaultAspectRatio(params.id)
    const aspectRatio = shot.metadata?.aspectRatio || defaultAspectRatio

    console.log(`[KEYFRAMES-GENERATE-LAST] 首帧: ${currentFirstFrameUrl?.slice(0, 80)}, 比例: ${aspectRatio}`)

    // 调用图像生成
    const imageClient = await getImageClient()
    const result = await imageClient.generateKeyframe(
      params.id,
      imagePrompt,
      styleRefUrl,
      'last',
      aspectRatio,
      undefined,
      undefined,
      userRefUrls,
      currentFirstFrameUrl
    )

    // 创建 Asset 记录
    const asset = await prisma.asset.create({
      data: {
        projectId: params.id,
        createdById: userId,
        stepId: keyframesStep.id,
        type: 'IMAGE',
        mimeType: 'image/png',
        storageKey: result.storageKey,
        url: result.url,
        metadata: {
          pairId: shot.shotId,
          frameType: 'last',
          quality: 'medium',
          sceneDesc: shot.description,
          llmPrompt: generatedPrompt,
          isMock: !!result.isMock,
          ...(result.lastError ? { mockReason: result.lastError } : {}),
        },
      }
    })

    // 将 lastFrameUrl 写回 STORYBOARD 步骤的 shots 数组（使用 composite key）
    // 必须乐观锁局部合并：storyboardStep.outputData 是请求开始时的快照，
    // 整块写回会抹掉并发生成完成的其他镜头结果
    await mergeStepOutputData(storyboardStep.id, (fresh) => {
      const freshShots: any[] = Array.isArray(fresh.shots) ? fresh.shots : storyboardShots
      return {
        ...fresh,
        shots: freshShots.map((s: any) =>
          s.shotId === body.shotId && (actNumber == null || s.actNumber === actNumber)
            ? { ...s, lastFrameUrl: result.url, lastFrameStorageKey: result.storageKey }
            : s
        ),
      }
    })

    // 同步更新 KEYFRAMES 步骤的 outputData（使用 composite key）
    await mergeStepOutputData(keyframesStep.id, (kfFresh) => {
      const kfResults: any[] = (kfFresh.results || kfFresh.keyframes || []).filter(
        (r: any) => !(r.shotId === body.shotId && (actNumber == null || r.actNumber === actNumber))
      )
      kfResults.push({
        shotId: body.shotId,
        actNumber: shot.actNumber,
        firstFrameUrl: shot.firstFrameUrl || shot.referenceImageUrl || '',
        firstFrameStorageKey: shot.firstFrameStorageKey || null,
        lastFrameUrl: result.url,
        lastFrameStorageKey: result.storageKey,
        description: shot.description,
        actionChange: '',
        isMock: !!result.isMock,
      })
      return { ...kfFresh, results: kfResults, keyframes: kfResults }
    })

    console.log('[KEYFRAMES-GENERATE-LAST] 尾帧生成完成, lastFrameUrl:', result.url?.slice(0, 80))

    // 真实模型全失败时回退到占位图，不按正常产出收费
    if (result.isMock) {
      await deductPointsAndLog(userId, pointsCheck.cost, 'error', {
        projectId: params.id,
        workflowStepId: keyframesStep.id,
        success: false,
        errorMessage: `AI 生图模型全部失败，已回退为占位预览图：${result.lastError || '未知原因'}`,
      })
      return NextResponse.json({
        success: true,
        isMock: true,
        lastFrameUrl: result.url,
        assetId: asset.id,
        warning: '当前生图服务不可用，返回的是占位预览图，点数未扣除，请稍后重试',
      })
    }

    await deductPointsAndLog(userId, pointsCheck.cost, 'generate', { projectId: params.id, workflowStepId: keyframesStep.id, success: true })
    return NextResponse.json({
      success: true,
      lastFrameUrl: result.url,
      assetId: asset.id,
    })
  } catch (e: any) {
    await deductPointsAndLog(userId, pointsCheck.cost, 'error', { projectId: params.id, workflowStepId: keyframesStep.id, success: false, errorMessage: e.message })
    console.error('[KEYFRAMES-GENERATE-LAST] 生成失败:', e.message)
    return NextResponse.json({ error: 'KEYFRAMES_001', message: e.message }, { status: 500 })
  }
}
