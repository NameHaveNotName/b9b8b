export const dynamic = 'force-dynamic'

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { revalidatePath } from 'next/cache';
import { getCurrentUser, getCurrentUserId } from '@/lib/auth-helpers';
import { projectDashboardSelect, projectCoreSelect } from '@/lib/db/project-select';

export async function GET() {
  try {
    const userId = await getCurrentUserId();
    if (!userId) {
      return NextResponse.json({ error: 'AUTH_001' }, { status: 401 });
    }

    console.log('[GET /api/projects] userId:', userId)

    const projects = await prisma.project.findMany({
      where: { userId, status: 'ACTIVE' },
      orderBy: { createdAt: 'desc' },
      select: projectDashboardSelect,
    });

    console.log('[GET /api/projects] found projects:', projects.length)
    return NextResponse.json({ projects });
  } catch (error: any) {
    console.error('[GET /api/projects] error:', error)
    return NextResponse.json(
      { error: 'SERVER_001', message: error?.message || '服务器内部错误' },
      { status: 500 }
    )
  }
}

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: 'AUTH_001' }, { status: 401 });
    }

    console.log('[POST /api/projects] userId:', user.id)

    const body = await req.json().catch(() => ({}));

    const title = body?.title || body?.rawIdea;
    if (!title || typeof title !== 'string' || title.trim().length === 0) {
      return NextResponse.json({ error: 'VALID_001', message: '项目标题不能为空' }, { status: 400 });
    }

    const trimmedTitle = title.trim();

    const project = await prisma.project.create({
      data: {
        userId: user.id,
        title: trimmedTitle,
        rawIdea: body?.rawIdea && typeof body.rawIdea === 'string' ? body.rawIdea : '',
        status: 'ACTIVE',
      },
      select: projectCoreSelect,
    });

    console.log('[POST /api/projects] created project:', project.id, 'with userId:', user.id)

    // 自动初始化 12 步 WorkflowStep 记录（全部 PENDING）
    const stepTypes: string[] = [
      'IDEATION',
      'FRAMEWORK',
      'STYLE',
      'CHARACTER',
      'CONCEPT',
      'TRAILER',
      'STORYBOARD',
      'KEYFRAMES',
      'VIDEO_DIRECT',
      'VIDEO_RENDER',
      'CAMERA',
      'REVIEW',
    ];

    const existingSteps = await prisma.workflowStep.findMany({
      where: { projectId: project.id },
      select: { stepType: true },
    });
    const existingTypes = new Set(existingSteps.map((s: any) => s.stepType));
    const stepsToCreate = stepTypes
      .map((type: string, idx: number) => ({ projectId: project.id, stepType: type as any, order: idx, status: 'PENDING' as const }))
      .filter((s: any) => !existingTypes.has(s.stepType));

    if (stepsToCreate.length > 0) {
      await prisma.workflowStep.createMany({ data: stepsToCreate });
    }

    revalidatePath('/dashboard')
    return NextResponse.json({ project })
  } catch (error: any) {
    console.error('[POST /api/projects] error:', error)
    return NextResponse.json(
      { error: 'SERVER_001', message: error?.message || '服务器内部错误' },
      { status: 500 }
    )
  }
}
